#include "BodyQueryPolicy.h"
#include <cassert>
#include <iostream>
#include <string>
#include <vector>

int main() {
    using namespace psq::body;
    unsigned assertions{};
    auto check = [&](bool value) { assert(value); ++assertions; };
    for (auto path : {"!UBE\\Body\\female.nif", "!ube\\body\\female.nif", "!uBe\\bOdY\\female.nif", "!UBE/Body/female.nif", "!ube/body/female.nif"}) {
        check(Matches(path, true)); check(Matches(path, false));
    }
    for (auto path : {"", "Body\\!UBE\\body\\female.nif", "meshes\\!UBE\\Body\\female.nif", " !UBE\\Body\\female.nif", "!UBEX\\Body\\female.nif", "!UBEBody\\female.nif"}) {
        check(!Matches(path, true)); check(!Matches(path, false));
    }
    for (auto path : {"!UBE\\Body/female.nif", "!UBE/Body\\female.nif", "!UBE\\Bodies\\female.nif", "!UBE\\Clothes\\boots.nif"}) {
        check(!Matches(path, true)); check(Matches(path, false));
    }
    // Every position through index 15 is recognized; index 16 and later is
    // deliberately ignored to match the existing Papyrus safety bound.
    for (std::size_t match{}; match < 20; ++match) {
        std::vector<std::string> models(20);
        models[match] = "!uBe\\bOdY\\test.nif";
        auto get = [&](std::size_t i) -> std::string_view { return models[i]; };
        check(HasModel(models.size(), get, true) == (match < 16));
        check(HasModel(models.size(), get, false) == (match < 16));
        check(!HasModel(0, get, false));
    }
    // Null ARMA entries are represented by empty model paths. Male/first-person
    // paths are not passed to the query; only female third-person paths are.
    struct Skin { bool ube; } racePlain{false}, raceUBE{true}, baseUBE{true}, knownPlain{false};
    auto uses = [](const Skin* skin) { return skin && skin->ube; };
    const Skin* skins[]{nullptr, &racePlain, &raceUBE, &baseUBE, &knownPlain};
    for (auto race : skins) for (auto known : skins) for (auto base : skins) {
        const bool expected = (known && race == known) || uses(race) || (base != race && uses(base));
        check(FromSkins(race, known, base, uses) == expected);
    }
    check(FromSkins(&knownPlain, &knownPlain, static_cast<Skin*>(nullptr), uses));
    check(!FromSkins(static_cast<Skin*>(nullptr), static_cast<Skin*>(nullptr), static_cast<Skin*>(nullptr), uses));
    std::cout << "Body query policy assertions: " << assertions << " passed\n";
}

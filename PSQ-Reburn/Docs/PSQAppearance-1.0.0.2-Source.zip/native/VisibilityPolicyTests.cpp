#include "VisibilityPolicy.h"
#include <memory>
#include <iostream>
#include <stdexcept>
struct Node {bool culled{};int writes{};bool GetAppCulled()const{return culled;}void SetAppCulled(bool value){culled=value;++writes;}};
int main(){
 int count{};auto check=[&](bool value){++count;if(!value)throw std::runtime_error("visibility check failed");};
 using namespace psq::visibility;
 for(unsigned slot{};slot<32U;++slot)for(unsigned flags{};flags<16U;++flags){
  auto mask=std::uint32_t{1}<<slot;bool original=flags&1U,selected=flags&2U,protectedItem=flags&4U,skin=flags&8U;
  check(Eligible(mask,original,selected,protectedItem,skin)==(!(mask&keepEquipRules)&&original&&!selected&&!protectedItem&&!skin));
 }
 Ownership<std::shared_ptr<Node>> owner;auto a=std::make_shared<Node>(),b=std::make_shared<Node>(),prior=std::make_shared<Node>();prior->culled=true;
 owner.Reconcile({a,a,b,prior},{b.get()});check(a->culled&&!b->culled&&prior->culled&&owner.Count()==1);check(a->writes==1);
 owner.Reconcile({a,a,prior},{});check(a->writes==1&&owner.Count()==1);
 auto rebuilt=std::make_shared<Node>();owner.Reconcile({rebuilt},{});check(!a->culled&&rebuilt->culled&&owner.Count()==1);check(a->writes==2);
 owner.Reconcile({rebuilt},{rebuilt.get()});check(!rebuilt->culled&&owner.Count()==0);
 owner.Reconcile({a,b},{});check(owner.Count()==2);owner.Reset();check(!a->culled&&!b->culled&&prior->culled&&owner.Count()==0);
 for(unsigned i{};i<100U;++i){owner.Reconcile({a,b},{});owner.Reset();check(!a->culled&&!b->culled&&owner.Count()==0);}
 owner.Reconcile({a},{});std::weak_ptr<Node> old=a;a.reset();owner.Reconcile({},{});check(old.expired());
 check(Current(7,7)&&!Current(6,7));check(!Eligible(0,true,false,false,false));
 std::cout<<"PASS "<<count<<" production visibility ownership and slot checks\n";
}

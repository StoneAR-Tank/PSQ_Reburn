#pragma once
#include <algorithm>
#include <cstddef>
#include <string_view>

namespace psq::body {
// SKSE StringUtil.Find folds case before searching. Only ASCII characters in
// these fixed path prefixes matter; do not normalize slashes or trim paths.
constexpr char Fold(char value) {
    return value >= 'a' && value <= 'z' ? static_cast<char>(value - ('a' - 'A')) : value;
}
constexpr bool StartsWith(std::string_view path, std::string_view prefix) {
    if (path.size() < prefix.size()) return false;
    for (std::size_t i{}; i < prefix.size(); ++i)
        if (Fold(path[i]) != Fold(prefix[i])) return false;
    return true;
}
constexpr bool Matches(std::string_view path, bool skin) {
    return skin ? StartsWith(path, "!UBE\\Body\\") || StartsWith(path, "!UBE/Body/")
                : StartsWith(path, "!UBE\\") || StartsWith(path, "!UBE/");
}
template<class GetPath>
bool HasModel(std::size_t count, GetPath getPath, bool skin) {
    const auto limit = (std::min)(count, std::size_t{16});
    for (std::size_t i{}; i < limit; ++i)
        if (Matches(getPath(i), skin)) return true;
    return false;
}
template<class Skin, class UsesUBE>
bool FromSkins(Skin raceSkin, Skin knownUBESkin, Skin baseSkin, UsesUBE usesUBE) {
    if (knownUBESkin && raceSkin == knownUBESkin) return true;
    if (usesUBE(raceSkin)) return true;
    return baseSkin != raceSkin && usesUBE(baseSkin);
}
}

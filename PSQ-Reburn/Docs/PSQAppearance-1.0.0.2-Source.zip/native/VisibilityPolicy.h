#pragma once
#include <cstdint>
#include <algorithm>
#include <unordered_set>
#include <utility>
#include <vector>
namespace psq::visibility {
// Body/hands/feet may contain the actor's visible skin. Headgear can control
// hair suppression independently of its visible mesh. Keep their equip rules.
constexpr std::uint32_t keepEquipRules = 6147U | 4U | 8U | 128U;
constexpr bool Eligible(std::uint32_t slots, bool original, bool selected, bool protectedItem, bool skin) {
 return slots && !(slots & keepEquipRules) && original && !selected && !protectedItem && !skin;
}
constexpr bool OwnCull(bool alreadyCulled) {return !alreadyCulled;}
constexpr bool Current(std::uint64_t captured,std::uint64_t current) {return captured==current;}
template<class Ptr> class Ownership {
 using Raw=decltype(std::declval<Ptr>().get());
 std::vector<Ptr> owned;
public:
 void Reset() {
  for(auto& node:owned)if(node && node->GetAppCulled())node->SetAppCulled(false);
  owned.clear();
 }
 void Reconcile(const std::vector<Ptr>& candidates,const std::unordered_set<Raw>& blocked) {
  std::unordered_set<Raw> wanted;
  for(const auto& node:candidates)if(node && !blocked.contains(node.get()))wanted.insert(node.get());
  std::erase_if(owned,[&](const Ptr& node){
   if(wanted.contains(node.get()))return false;
   if(node && node->GetAppCulled())node->SetAppCulled(false);
   return true;
  });
  for(const auto& node:candidates) {
   if(!node || !wanted.erase(node.get()))continue;
   const bool ours=std::any_of(owned.begin(),owned.end(),[&](const Ptr& existing){return existing.get()==node.get();});
   if(!ours){if(!OwnCull(node->GetAppCulled()))continue;owned.push_back(node);}
   if(!node->GetAppCulled())node->SetAppCulled(true);
  }
 }
 std::size_t Count() const{return owned.size();}
};
}

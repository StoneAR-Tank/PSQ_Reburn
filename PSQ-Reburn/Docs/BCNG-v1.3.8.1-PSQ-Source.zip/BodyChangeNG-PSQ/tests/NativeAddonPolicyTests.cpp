#include "BodyChangeNG/NativeAddonPolicy.h"
#include "BodyChangeNG/NativeAddonRuntime.h"
#include "BodyChangeNG/NativeAddonPatterns.h"
#include <iostream>
#include <optional>
#include <utility>
#include <stdexcept>
#include <thread>

namespace
{
    void Check(bool ok, const char* message) { if (!ok) throw std::runtime_error(message); }

    struct ReferenceProbe
    {
        int refs{ 1 }, destructions{};
        void IncRefCount() { Check(refs > 0, "acquired a dead TXST"); ++refs; }
        void DecRefCount() { Check(refs > 0, "double TXST release"); if (--refs == 0) ++destructions; }
    };
    struct ProbeLease
    {
        ReferenceProbe* pointer{};
        explicit ProbeLease(ReferenceProbe* p) : pointer(p) { if (pointer) pointer->IncRefCount(); }
        ProbeLease(const ProbeLease& other) : ProbeLease(other.pointer) {}
        ProbeLease(ProbeLease&& other) noexcept : pointer(std::exchange(other.pointer, nullptr)) {}
        ~ProbeLease() { if (pointer) pointer->DecRefCount(); }
    };
}

int main()
{
    using namespace bcn::native_addon;
    try {
        constexpr std::uintptr_t image = 0x140000000ULL;
        // Captured TuLED layout: IAT 0x1509000..0x150A1B8 spans one
        // PAGE_EXECUTE_READWRITE page followed by a PAGE_READONLY region.
        std::array regions{
            ImageMemoryRegion{ image + 0x1509000, image, 0x1000, true, true },
            ImageMemoryRegion{ image + 0x150A000, image, 0x14B000, true, true }
        };
        unsigned queries{};
        const auto query = [&](std::uintptr_t address) -> std::optional<ImageMemoryRegion> {
            ++queries;
            for (const auto& region : regions) {
                if (address >= region.begin && address - region.begin < region.size) return region;
            }
            return {};
        };
        Check(IsReadableImageRange(image, 0x4000000, image + 0x1509000, 0x11B8, query) && queries == 2U,
            "readable IAT split across protection regions was rejected");
        for (unsigned failure{}; failure < 5U; ++failure) {
            auto bad = regions[1];
            if (failure == 0) bad.readable = false;
            if (failure == 1) bad.committed = false;
            if (failure == 2) bad.allocation += 0x1000;
            if (failure == 3) bad.begin += 1;
            if (failure == 4) bad.size = 0;
            Check(!IsReadableImageRange(image, 0x4000000, image + 0x1509000, 0x11B8,
                    [&](std::uintptr_t address) -> std::optional<ImageMemoryRegion> {
                        return address < image + 0x150A000 ? regions[0] : bad;
                    }), "unreadable, foreign or incomplete IAT tail was accepted");
        }
        Check(!IsReadableImageRange(image, 0x150A000, image + 0x1509000, 0x11B8, query) &&
            !IsReadableImageRange(image, 0x4000000, image - 1, 8, query) &&
            !IsReadableImageRange(UINTPTR_MAX - 4, 8, UINTPTR_MAX - 3, 2, query) &&
            !IsReadableImageRange(image, 0x4000000, image, 0, query),
            "overflowing or out-of-image IAT accepted");
        std::array<std::uint8_t, 32> imports{};
        std::uint64_t sleepPointer = 0x7FFB12345678;
        std::memcpy(imports.data()+8, &sleepPointer, 8);
        Check(FindUniqueImport(imports, 0x1000, sleepPointer) == 0x1008U,
            "import identity did not resolve without an Address Library data ID");
        Check(!FindUniqueImport(imports, 0x1000, sleepPointer+1) &&
            !FindUniqueImport(imports, UINT32_MAX-8, sleepPointer) &&
            !FindUniqueImport(std::span{imports}.first(31), 0x1000, sleepPointer),
            "invalid or overflowing IAT accepted");
        std::memcpy(imports.data()+24, &sleepPointer, 8);
        Check(!FindUniqueImport(imports, 0x1000, sleepPointer), "ambiguous OS import accepted");
        // Synthetic rebasing exercises the production matcher, not uncaptured
        // game executables. Only externally relocated operands may move.
        for (const auto group : { std::span{patterns::se}, std::span{patterns::ae} }) {
            for (const auto& pattern : group) {
                for (const std::uint32_t base : { 0x1000U, 0x40000U, 0x2100000U }) {
                    std::vector<std::uint8_t> code(pattern.bytes.begin(), pattern.bytes.end());
                    const auto resolve = [](std::uint64_t id) -> std::optional<std::uint32_t> {
                        return static_cast<std::uint32_t>(id * 16U + 0x300000U);
                    };
                    for (const auto& operand : pattern.operands) {
                        const auto delta = static_cast<std::int32_t>(std::int64_t{*resolve(operand.targetID)} +
                            operand.addend - base - operand.instructionEnd);
                        std::memcpy(code.data() + operand.offset, &delta, 4);
                    }
                    Check(MatchRelocatedCode(pattern, code, base, resolve), "relocated reference rejected");
                    Check(!MatchRelocatedCode(pattern, std::span{code}.first(code.size()-1), base, resolve),
                        "truncated native ownership code accepted");
                    for (std::size_t i{}; i < code.size(); ++i) {
                        code[i] ^= 1U;
                        Check(!MatchRelocatedCode(pattern, code, base, resolve),
                            "changed opcode/field/constant/callee accepted");
                        code[i] ^= 1U;
                    }
                    if (!pattern.operands.empty()) {
                        Check(!MatchRelocatedCode(pattern, code, base,
                            [](std::uint64_t) -> std::optional<std::uint32_t> { return {}; }),
                            "unresolved native dependency accepted");
                    }
                }
            }
        }
        for (const auto prefix : { directVisitorPrefix, seRecursiveVisitorPrefix, aeRecursiveVisitorPrefix }) {
            for (std::uint8_t opcode : { std::uint8_t{0xE8}, std::uint8_t{0xE9} }) {
                std::vector<std::uint8_t> caller(0x600, 0xCC);
                const std::size_t offset = 0x17F;
                std::memcpy(caller.data()+offset, prefix.data(), prefix.size());
                const auto site = offset + prefix.size();
                caller[site] = opcode;
                auto delta = static_cast<std::int32_t>(0x7000 - (0x4000 + site + 5));
                std::memcpy(caller.data()+site+1, &delta, 4);
                Check(FindVisitorBranch(caller, 0x4000, prefix, opcode, 0x7000) == 0x4000+site,
                    "bounded visitor callsite rejected");
                Check(!FindVisitorBranch(caller, 0x4000, prefix, opcode, 0x7001),
                    "foreign visitor hook accepted");
                const std::size_t duplicate = 0x350;
                std::memcpy(caller.data()+duplicate, prefix.data(), prefix.size());
                caller[duplicate+prefix.size()] = opcode;
                delta = static_cast<std::int32_t>(0x7000 - (0x4000 + duplicate + prefix.size() + 5));
                std::memcpy(caller.data()+duplicate+prefix.size()+1, &delta, 4);
                Check(!FindVisitorBranch(caller, 0x4000, prefix, opcode, 0x7000),
                    "ambiguous visitor callsite accepted");
            }
        }
        Check(AcceptSlot(22, 1U << 22), "slot52 rejected");
        Check(!AcceptSlot(2, 1U << 22) && !AcceptSlot(22, 4), "body slot admitted");
        using Kind = bcn::futanari::AddonKind;
        constexpr auto slot52 = bcn::futanari::kSlot52;
        constexpr auto slot53 = 1U << 23U;
        constexpr auto slot54 = bcn::futanari::kSlot54;
        for (const auto kind : {Kind::ube, Kind::ubeTrx, Kind::trx, Kind::erf, Kind::none}) {
            const bool ube = bcn::futanari::IsUbeAddon(kind);
            // Exact installed UBE_SOS_Addon / TRX UBE BOD2 masks.
            const auto slots = bcn::futanari::GenitalSlots(kind, slot52 | slot54, slot53 | slot54);
            Check(slots == (ube ? slot54 : 0U), "UBE slot ownership leaked to another addon family");
            Check(bcn::futanari::GenitalSlots(kind, slot52, slot52) == slot52,
                "existing SOS/TNG slot52 route regressed");
            Check(bcn::futanari::GenitalSlots(kind, slot53, slot53) == 0U &&
                bcn::futanari::GenitalSlots(kind, slot52, slot53 | slot54) == 0U,
                "ordinary UBE body or disjoint equipment slots admitted");
            for (const auto channel : {Channel::maleGenitals, Channel::futanari}) {
                for (int index = -1; index <= 42; ++index) {
                    const bool expected = index == 24 && channel == Channel::futanari && ube;
                    Check(AcceptGenitalSlot(index, slots, channel, kind) == expected,
                        "native visitor admitted a body, male or foreign UBE slot");
                    Check(AcceptGenitalSlot(index, slot52, channel, kind) == (index == 22),
                        "legacy slot52 admission changed");
                    Check(IsCandidateSlotIndex(index) == (index == 22 || index == 24),
                        "native visitor can index an unverified biped slot");
                }
            }
        }
        std::array<std::byte, 0x78 * 42> parts{};
        for (std::size_t index{}; index < 42U; ++index) {
            std::fill_n(parts.begin() + index * 0x78U, 0x78U, static_cast<std::byte>(index));
        }
        const auto before = parts;
        VisitorContext original{ 22, 0, parts.data(), 123, 0 };
        int texture{};
        for (const int index : {22, 24}) {
            original.index = index;
            ScopedSupply supplied(original, &texture);
            const void* read{};
            std::memcpy(&read, supplied.context.parts + 0x18, sizeof(read));
            Check(read == &texture, "private TXST not supplied");
            Check(supplied.part.front() == static_cast<std::byte>(index) &&
                supplied.part.back() == static_cast<std::byte>(index),
                "private supply copied the wrong engine biped slot");
            Check(supplied.context.index == 0 && supplied.context.actorHandle == 123,
                "visitor identity changed");
            Check(parts == before && original.index == index && original.parts == parts.data(),
                "engine-owned BIPOBJECT was modified");
        }
        Check(parts == before, "borrowed pointer escaped into engine data");

        const Paths provider{ "default_d.dds", "default_n.dds", "default_s.dds" };
        Paths skinA{}, skinB{};
        skinA[0] = "A_d.dds";
        skinA[1] = "A_n.dds";
        skinB[0] = "B_d.dds";
        const auto a = ResolvePaths(provider, skinA);
        const auto b = ResolvePaths(provider, skinB);
        Check(a[0] == "A_d.dds" && a[1] == "A_n.dds" && a[2] == provider[2],
            "partial genital pack replaced an unrelated channel");
        Check(b[0] == "B_d.dds" && b[1] == provider[1],
            "switching skin retained a missing channel from previous pack");
        Check(ResolvePaths(provider, {}) == provider, "Default did not select provider paths");

        Baselines baselines;
        const BaselineIdentity erfA{ 100, 0x10, 0x20, Channel::futanari, "CBBE Schlong" };
        const BaselineIdentity erfB{ 200, 0x10, 0x20, Channel::futanari, "CBBE Schlong" };
        Check(baselines.Put(erfA, provider), "first baseline was not stored");
        Check(!baselines.Put(erfA, provider), "same baseline caused duplicate mutation");
        auto erfCase = erfA;
        Check(!bcn::asset_identity::NameEqual{}("A/B", "a\\b") &&
                bcn::asset_identity::NameEqual{}("A/B", "a/b"),
            "node identity applied path normalization to a distinct geometry name");
        erfCase.node = "cbbe SCHLONG";
        auto providerCase = provider;
        providerCase[0] = "DEFAULT_D.DDS";
        Check(erfCase == erfA && BaselineIdentityHash{}(erfCase) == BaselineIdentityHash{}(erfA),
            "case-insensitive addon identity has inconsistent hash");
        Check(!baselines.Put(erfCase, providerCase) && baselines.Diffuse(erfCase) == provider[0],
            "case-only addon change duplicated or replaced the original baseline");
        baselines.Retain(100, Channel::futanari, { Target{ 0x10, 0x20, { "cbbe SCHLONG" } } });
        Check(baselines.Diffuse(erfA) == provider[0],
            "case-only target refresh discarded the original addon baseline");
        Check(baselines.Diffuse(erfA) == "default_d.dds", "baseline diffuse was lost");
        Check(baselines.Diffuse(erfB).empty(), "baseline leaked to another actor");
        auto providerB = provider;
        providerB[0] = "other_default_d.dds";
        baselines.Put(erfB, providerB);
        baselines.Retain(200, Channel::futanari,
            { Target{ 0x30, 0x40, { "TRX Schlong" } } });
        Check(baselines.Diffuse(erfB).empty(),
            "replaced addon baseline accumulated after target change");
        baselines.Put(erfB, providerB);
        baselines.Forget(100);
        Check(baselines.Diffuse(erfA).empty() && baselines.Diffuse(erfB) == providerB[0],
            "actor baseline cleanup affected another actor");
        baselines.Reset();
        Check(baselines.Diffuse(erfB).empty(), "baseline reset leaked a value snapshot");

        // Uses the same adoption helper as the real backend. The native
        // material/renderer retain independent intrusive references; releasing
        // the visitor's lease alone cannot invalidate either one.
        for (int repeat{}; repeat < 1000; ++repeat) {
            ReferenceProbe form;
            std::optional<ProbeLease> material, renderer;
            {
                auto visitor = AdoptFactoryTexture<ReferenceProbe, ProbeLease>(&form);
                Check(form.refs == 1, "factory's initial reference leaked during adoption");
                material.emplace(visitor);
                renderer.emplace(visitor);
            }
            Check(form.refs == 2 && form.destructions == 0, "visitor freed retained TXST");
            material.reset(); // selection change / unequip / 3D replacement
            Check(form.refs == 1 && form.destructions == 0, "renderer retained a dead TXST");
            renderer.reset();
            Check(form.refs == 0 && form.destructions == 1, "old TXST leaked or was deleted twice");
        }

        Selections store;
        Selection first{ Channel::maleGenitals, {{123, 456, {"Genitals"}}}, {} };
        first.overrides[0] = "skin_A.dds";
        Selection second = first;
        second.overrides[0] = "skin_B.dds";
        store.Publish(100, first);
        Check(!store.Publish(100, first), "same source/selection requested duplicate native refresh");
        auto firstCase = first;
        firstCase.targets.front().nodes.front() = "gENITALS";
        firstCase.overrides[0] = "SKIN_a.DDS";
        Check(!store.Publish(100, firstCase), "case-only addon selection requested duplicate refresh");
        store.Publish(200, second); // same ARMO/ARMA, different actor and skin
        auto lease = store.Get(100);
        std::weak_ptr<const Selection> previous = lease;
        store.Publish(100, second);
        Check(lease->overrides[0] == "skin_A.dds", "publication mutated active reader");
        Check(store.Get(100)->overrides[0] == "skin_B.dds", "repeat choice ignored");
        Check(store.Get(200)->overrides[0] == "skin_B.dds", "shared ARMO propagated selection");
        lease.reset();
        Check(previous.expired(), "old selection leaked after last reader");

        store.Publish(100, first);
        std::jthread writer([&] {
            for (int i{}; i < 2000; ++i) store.Publish(100, i % 2 ? first : second);
        });
        for (int i{}; i < 2000; ++i) {
            auto value = store.Get(100);
            Check(value && (value->overrides[0] == "skin_A.dds" ||
                           value->overrides[0] == "skin_B.dds"), "partial snapshot observed");
        }
        writer.join();
        lease = store.Get(100);
        previous = lease;
        store.Forget(100); // unload/forget does not mutate persistent ActorState
        Check(!store.Get(100) && store.Get(200), "actor removal affected another actor");
        store.Reset();
        Check(!store.Get(200) && !previous.expired(), "reset invalidated an in-flight lease");
        lease.reset();
        Check(previous.expired(), "reset retained obsolete snapshot");
        std::cout << "Native addon policy tests passed (not engine/render tests)\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}

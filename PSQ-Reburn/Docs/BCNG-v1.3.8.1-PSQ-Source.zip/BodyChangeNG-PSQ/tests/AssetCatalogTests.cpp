#include "BodyChangeNG/PlayerTint.h"
#include "BodyChangeNG/PlayerTintSerialization.h"
#include "BodyChangeNG/DistributionOverlayColors.h"
#include "BodyChangeNG/AppearanceColorDrafts.h"
#include "BodyChangeNG/SkinProfiles.h"
#include "BodyChangeNG/SkinGeometryRouting.h"
#include "BodyChangeNG/FutanariRouting.h"
#include "BodyChangeNG/CatalogRoots.h"
#include "BodyChangeNG/PathText.h"
#include "BodyChangeNG/Settings.h"
#include "BodyChangeNG/RuntimeAssetCache.h"
#include "BodyChangeNG/SkinApplicationPlan.h"
#include "BodyChangeNG/FaceSkinPolicy.h"
#include "BodyChangeNG/SlaveTatsCatalog.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <array>
#include <cctype>
#include <chrono>
#include <ranges>
#include <unordered_set>
#include <cstring>

// This read-only catalog executable has no engine face backend. The real
// preview journal is exercised by FacePreviewTransactionTests instead.
namespace bcn::face_preview {
    void OwnerChanged() {}
    void Reset() {}
}

namespace
{
    bool Require(const bool condition, const char* message)
    {
        if (condition) return true;
        std::cerr << message << '\n';
        return false;
    }

    void Touch(const std::filesystem::path& path)
    {
        std::filesystem::create_directories(path.parent_path());
        std::ofstream(path, std::ios::binary).put('\0');
    }

    void WriteText(const std::filesystem::path& path, const std::string_view text)
    {
        std::filesystem::create_directories(path.parent_path());
        std::ofstream stream(path, std::ios::binary);
        stream.write(text.data(), static_cast<std::streamsize>(text.size()));
    }

    bool TextEquals(const std::filesystem::path& path, const std::string_view expected)
    {
        std::ifstream stream(path, std::ios::binary);
        return stream && std::string{ std::istreambuf_iterator<char>{ stream },
            std::istreambuf_iterator<char>{} } == expected;
    }

    std::string Lower(std::string value)
    {
        std::ranges::transform(value, value.begin(), [](const unsigned char character) {
            return static_cast<char>(std::tolower(character));
        });
        return value;
    }

    std::string Filename(const std::string_view path)
    {
        const auto separator = path.find_last_of("\\/");
        return std::string{ separator == std::string_view::npos ? path : path.substr(separator + 1U) };
    }

    bool IsStandardSkinTexture(const std::string_view filename)
    {
        constexpr std::array stems{
            std::string_view{ "femalebody_1" }, std::string_view{ "femalebody_etc_v2_1" },
            std::string_view{ "vaginalanalcanal2" },
            std::string_view{ "femalehands_1" },
            std::string_view{ "femalefeet_1" }, std::string_view{ "femalehead" },
            std::string_view{ "femaleheadvampire" }, std::string_view{ "malebody_1" },
            std::string_view{ "malehands_1" }, std::string_view{ "malefeet_1" },
            std::string_view{ "malehead" }, std::string_view{ "maleheadvampire" },
            std::string_view{ "argonianfemalebody" }, std::string_view{ "argonianfemalehands" },
            std::string_view{ "argonianfemalefeet" }, std::string_view{ "argonianfemalehead" },
            std::string_view{ "argonianmalebody" }, std::string_view{ "argonianmalehands" },
            std::string_view{ "argonianmalefeet" }, std::string_view{ "argonianmalehead" },
            std::string_view{ "femalebody" }, std::string_view{ "femalehands" },
            std::string_view{ "femalefeet" }, std::string_view{ "bodymale" },
            std::string_view{ "handsmale" }, std::string_view{ "feetmale" },
            std::string_view{ "headmale" }
        };
        // blankdetailmap.dds is deliberately sex-ambiguous and may be shipped
        // in an opposite-sex helper directory without belonging to a profile.
        // Its positive mapping is covered by the synthetic catalog test below.
        if (filename.starts_with("femaleheaddetail_") ||
            filename.starts_with("maleheaddetail_")) return filename.ends_with(".dds");
        for (const auto stem : stems) {
            if (filename == std::string{ stem } + ".dds" ||
                filename == std::string{ stem } + "_msn.dds" ||
                filename == std::string{ stem } + "_sk.dds" ||
                filename == std::string{ stem } + "_s.dds") return true;
        }
        if (filename == "femalebody_1_d.dds" || filename == "femalebody_1_n.dds" ||
            filename == "femalehead_d.dds" || filename == "femalehead_n.dds") return true;
        return false;
    }

    bool HasExactMaterialChannels(
        const std::vector<bcn::SkinTextureLayer>& layers, const std::string_view stem)
    {
        const std::array expected{
            std::pair{ 0U, std::string{ stem } + ".dds" },
            std::pair{ 1U, std::string{ stem } + "_msn.dds" },
            std::pair{ 2U, std::string{ stem } + "_sk.dds" },
            std::pair{ 7U, std::string{ stem } + "_s.dds" }
        };
        return layers.size() == expected.size() &&
            std::ranges::all_of(expected, [&](const auto& item) {
                const auto& [index, filename] = item;
                return std::ranges::any_of(layers, [&](const auto& layer) {
                    return layer.shaderTextureIndex == index &&
                        Filename(Lower(layer.path)) == filename;
                });
            });
    }

    bool HasExactUbeMaterialChannels(
        const std::vector<bcn::SkinTextureLayer>& layers, const std::string_view stem)
    {
        const std::array expected{
            std::pair{ 0U, std::string{ stem } + "_d.dds" },
            std::pair{ 1U, std::string{ stem } + "_n.dds" }
        };
        return layers.size() == expected.size() &&
            std::ranges::all_of(expected, [&](const auto& item) {
                const auto& [index, filename] = item;
                return std::ranges::any_of(layers, [&](const auto& layer) {
                    return layer.shaderTextureIndex == index &&
                        Filename(Lower(layer.path)) == filename;
                });
            });
    }
}

int main(const int argc, char** argv)
{
    using namespace bcn::player_tint;
    PersistedState tintState{ .pack = "Tint pack A" };
    for (std::uint8_t i{}; i < 15U; ++i) {
        tintState.layers.push_back({ .layer = static_cast<Layer>(i), .restored = i == 14U,
            .assetID = "Tint pack A/asset" + std::to_string(i),
            .color = { 0.1F, 0.5F, 0.9F, static_cast<float>(i) / 14.0F } });
        tintState.backups.push_back({ .type = i, .texturePath = "Actors/OriginalA/" + std::to_string(i) + ".dds",
            .color = { i, 127U, 255U }, .alpha = 0.25F });
    }
    std::vector<std::uint8_t> tintBytes;
    const auto writeTint = [&](const auto& value) {
        const auto* bytes = reinterpret_cast<const std::uint8_t*>(&value);
        tintBytes.insert(tintBytes.end(), bytes, bytes + sizeof(value));
        return true;
    };
    const auto writeTintString = [&](const std::string& value) {
        writeTint(static_cast<std::uint32_t>(value.size()));
        tintBytes.insert(tintBytes.end(), value.begin(), value.end());
        return true;
    };
    if (!Require(WriteState(tintState, writeTint, writeTintString), "tint state failed to encode")) return 1;
    const auto readTint = [&](const std::uint32_t version, const std::size_t length) {
        std::size_t cursor{};
        const auto read = [&](auto& value) {
            if (cursor > length || sizeof(value) > length - cursor) return false;
            std::memcpy(&value, tintBytes.data() + cursor, sizeof(value));
            cursor += sizeof(value);
            return true;
        };
        const auto string = [&](std::string& value) {
            std::uint32_t size{};
            if (!read(size) || size > 1024U || size > length - cursor) return false;
            value.assign(reinterpret_cast<const char*>(tintBytes.data() + cursor), size);
            cursor += size;
            return true;
        };
        return ReadState(version, read, string);
    };
    const auto restoredTint = readTint(2U, tintBytes.size());
    if (!Require(restoredTint && restoredTint->pack == tintState.pack && restoredTint->layers.size() == 15U &&
            restoredTint->backups.size() == 15U && restoredTint->layers[0].color.alpha == 0.0F &&
            restoredTint->layers[13].color.alpha == tintState.layers[13].color.alpha &&
            restoredTint->layers[14].restored && restoredTint->backups[7].texturePath == tintState.backups[7].texturePath &&
            restoredTint->backups[7].color == tintState.backups[7].color && restoredTint->backups[7].alpha == 0.25F,
            "tint pack, per-layer RGBA, restore intent or original masks failed round trip")) return 1;
    const auto legacyTintRecord = readTint(1U, tintBytes.size());
    if (!Require(legacyTintRecord && legacyTintRecord->layers.size() == 15U && legacyTintRecord->backups.empty(),
            "v1 tint selection was rejected or borrowed unrelated global backups")) return 1;
    for (std::size_t length{}; length < tintBytes.size(); ++length) {
        if (!Require(!readTint(2U, length), "truncated tint record was partially published")) return 1;
    }
    RestorePersistedState(*restoredTint);
    BeginPreview();
    if (!Require(SnapshotPersistedState().backups[0].texturePath == tintState.backups[0].texturePath,
            "pinning a preview discarded original tint backups")) return 1;
    auto otherSave = tintState;
    otherSave.pack = "Tint pack B";
    otherSave.backups[0].texturePath = "Actors/OriginalB/lips.dds";
    RestorePersistedState(otherSave);
    if (!Require(SnapshotPersistedState().pack == otherSave.pack &&
            SnapshotPersistedState().backups[0].texturePath == otherSave.backups[0].texturePath,
            "loading save B retained save A's tint baseline")) return 1;
    ResetPersistedState();
    if (!Require(!SnapshotPersistedState().pack && SnapshotPersistedState().backups.empty(),
            "new game retained tint state from the previous save")) return 1;
    bcn::DistributionRule coloredRule;
    bcn::ui::AppearanceColorDrafts<std::uint32_t> batchDrafts;
    batchDrafts.Set(0x14U, 0U, "A", 0x80123456U);
    batchDrafts.Set(0x14U, 0U, "B", 0x40010203U);
    batchDrafts.Set(0x14U, 1U, "A", 0xFF112233U);
    batchDrafts.Set(0x14U, 0U, "unchecked", 0xFFFFFFFFU);
    coloredRule.overlayIds[0] = { "A", "B", "new" };
    coloredRule.overlayIds[1] = { "A" };
    unsigned fallbackReads{};
    for (std::size_t area{}; area < coloredRule.overlayIds.size(); ++area) {
        coloredRule.overlayColors[area] = batchDrafts.CopySelection(0x14U,
            static_cast<std::uint8_t>(area), coloredRule.overlayIds[area],
            [&](const auto&) { ++fallbackReads; return 0xFFFFFFFFU; });
    }
    const nlohmann::json batchJson = coloredRule.overlayColors;
    batchDrafts.Clear(); // UI close must not invalidate an explicitly saved rule.
    coloredRule.overlayColors = bcn::ReadDistributionOverlayColors(
        nlohmann::json::parse(batchJson.dump()), coloredRule.overlayIds);
    if (!Require(fallbackReads == 1U && coloredRule.overlayColors[0].size() == 3U &&
            bcn::DistributionOverlayColor(coloredRule, bcn::overlay::Area::face, "A") == 0x80123456U &&
            bcn::DistributionOverlayColor(coloredRule, bcn::overlay::Area::face, "B") == 0x40010203U &&
            bcn::DistributionOverlayColor(coloredRule, bcn::overlay::Area::body, "A") == 0xFF112233U &&
            bcn::DistributionOverlayColor(coloredRule, bcn::overlay::Area::face, "new") == 0xFFFFFFFFU,
            "batch color selection, rule serialization, or NPC color lookup lost per-entry RGBA")) return 1;

    auto mixedColorIds = coloredRule.overlayIds;
    mixedColorIds[0][0] = "a";
    const auto mixedColors = bcn::ReadDistributionOverlayColors(batchJson, mixedColorIds);
    if (!Require(mixedColors[0].at("A") == 0x80123456U &&
            bcn::DistributionOverlayColor(coloredRule, bcn::overlay::Area::face, "a") == 0x80123456U,
            "case-only saved overlay IDs lost distribution colors")) return 1;

    coloredRule.overlayIds[0] = { "A", "B", "zero", "negative", "overflow", "float", "text" };
    coloredRule.overlayIds[1] = { "A" };
    coloredRule.overlayColors[0] = { { "A", 0x80123456U }, { "B", 0xFFFFFFFFU }, { "zero", 0U } };
    coloredRule.overlayColors[1] = { { "A", 0x40654321U } };
    const nlohmann::json colors = coloredRule.overlayColors;
    auto decoded = bcn::ReadDistributionOverlayColors(nlohmann::json::parse(colors.dump()), coloredRule.overlayIds);
    if (!Require(decoded == coloredRule.overlayColors, "distribution RGBA JSON round trip changed colors")) return 1;
    auto malformed = colors;
    malformed[0]["negative"] = -1;
    malformed[0]["overflow"] = 0x100000000ULL;
    malformed[0]["float"] = 0.5;
    malformed[0]["text"] = "red";
    malformed[0]["unselected"] = 123U;
    decoded = bcn::ReadDistributionOverlayColors(malformed, coloredRule.overlayIds);
    if (!Require(decoded == coloredRule.overlayColors &&
            bcn::ReadDistributionOverlayColors(nullptr, coloredRule.overlayIds)[0].empty(),
            "bad optional colors rejected good values or legacy rules")) return 1;
    if (argc == 3 && std::string_view(argv[1]) == "--verify-bnp") {
        const auto profiles = bcn::SkinProfiles::ScanDirectory(std::filesystem::path{argv[2]});
        const std::array names{
            "BnP female skin 4k (CBBE Player and Replacer)",
            "BnP female skin 4k (UNP Player and Replacer)",
            "BnP male skin 4k (SOS full Player Replacer)" };
        std::size_t combinations{};
        for (std::size_t pack{}; pack < names.size(); ++pack) {
            const auto found = std::ranges::find(profiles, names[pack], &bcn::SkinProfile::name);
            if (!Require(found != profiles.end(), "requested BnP pack missing")) return 1;
            const auto& profile = *found;
            const bool male = pack == 2;
            if (!Require(profile.sex == (male ? bcn::SkinSex::male : bcn::SkinSex::female) &&
                    profile.id == std::string("auto:") + names[pack] + (male ? ":male" : ":female") &&
                    HasExactMaterialChannels(profile.face, male ? "malehead" : "femalehead"),
                    "BnP sex, stable ID, or four generic face channels changed")) return 1;
            const auto family = male ? bcn::body_family::Family::himbo : pack == 0 ?
                bcn::body_family::Family::cbbe : bcn::body_family::Family::unp;
            if (!Require(HasExactMaterialChannels(profile.body,
                        male ? "malebody_1" : "femalebody_1") &&
                    HasExactMaterialChannels(profile.hands,
                        male ? "malehands_1" : "femalehands_1"),
                    "BnP body or hands DDS channels do not match the Legacy NIF layout")) return 1;
            if (!male && !Require(
                    pack == 0 ? HasExactMaterialChannels(profile.cbbeGenitalAnal,
                                      "femalebody_etc_v2_1") && profile.unpGenitalAnal.empty() :
                                HasExactMaterialChannels(profile.unpGenitalAnal,
                                      "vaginalanalcanal2") && profile.cbbeGenitalAnal.empty(),
                    "BnP female genital/anal DDS channels crossed CBBE and UNP layouts")) return 1;
            if (male && !Require(profile.maleGenitals.size() == 3U &&
                    std::ranges::all_of(profile.maleGenitals, [](const auto& variant) {
                        return HasExactMaterialChannels(variant.humanoid, "malegenitals_1");
                    }), "BnP SOS genital DDS channels do not match the installed Legacy SOS NIFs")) return 1;
            const std::string prefix = std::string("BodySkin\\") + names[pack] + "\\";
            const auto pathFor = [](const auto& layers, unsigned index) {
                for (const auto& layer : layers) if (layer.shaderTextureIndex == index) return layer.path;
                return std::string{};
            };
            const auto safeLayers = [&](const auto& layers) {
                for (const auto& layer : layers) {
                    const auto path = Lower(layer.path);
                    if (!layer.path.starts_with(prefix) || path.contains("tintmasks") ||
                        path.contains("facetint") || layer.shaderTextureIndex == 6U) return false;
                }
                return true;
            };
            for (bool elder : {false, true}) for (bool vampire : {false, true}) {
                for (unsigned race = 1; race < static_cast<unsigned>(bcn::HumanoidSkinRace::count); ++race) {
                    const auto plan = bcn::skin_plan::Build(profile, {
                        .elder=elder, .vampire=vampire,
                        .humanoidRace=static_cast<bcn::HumanoidSkinRace>(race),
                        .faceDetailFilename=male ? "maleheaddetail_age40.dds" : "femaleheaddetail_age40.dds",
                        .bodyFamily=bcn::body_family::Bit(family) });
                    auto expected = pathFor(profile.face, 1);
                    if (auto specific = pathFor(profile.raceFace[race], 1); !specific.empty()) expected = specific;
                    if (auto specific = pathFor(profile.vampireFace, 1); vampire && !specific.empty()) expected = specific;
                    if (auto specific = pathFor(profile.elderFace, 1); elder && !specific.empty()) expected = specific;
                    if (!Require(pathFor(plan.face, 1) == expected && safeLayers(plan.face) &&
                            safeLayers(plan.body) && safeLayers(plan.hands) && safeLayers(plan.feet) &&
                            pathFor(plan.feet, 0) == pathFor(plan.body, 0),
                            "BnP conditional role/fallback, pack isolation, or tint exclusion failed")) return 1;
                    for (const auto& layer : plan.face) {
                        if (!Require(std::ranges::find(bcn::face_skin::kChannels, layer.shaderTextureIndex) !=
                                bcn::face_skin::kChannels.end(), "unsupported face channel")) return 1;
                    }
                    ++combinations;
                }
            }
            std::cout << "VERIFIED_BNP " << profile.name << " face=" << profile.face.size()
                << " vampire=" << profile.vampireFace.size() << " details=" << profile.faceDetails.size() << '\n';
        }
        std::cout << "BnP real-folder catalog/plan verification passed: " << combinations
            << " combinations; tint masks excluded; no game writes\n";
        return 0;
    }
    // Read-only diagnostic mode: inspect real packs through the same
    // production catalog, without copying assets or changing game settings.
    if (argc == 3 && (std::string_view(argv[1]) == "--inspect-skin-root" ||
            std::string_view(argv[1]) == "--inspect-installed-pack")) {
        auto root = std::filesystem::path{argv[2]};
        if (std::string_view(argv[1]) == "--inspect-installed-pack") {
            // Catalog-only mirror: preserve actual relative filenames, not
            // DDS contents. No game-file writes or rendering/load attempts.
            const auto source = std::filesystem::absolute(root);
            root = std::filesystem::current_path() / "build" / "diagnostics" /
                ("male-pack-audit-" + std::to_string(
                    std::chrono::steady_clock::now().time_since_epoch().count()));
            std::filesystem::create_directories(root.parent_path());
            if (!std::filesystem::create_directory(root)) return 1;
            root /= "BodySkin";
            for (const auto& entry : std::filesystem::recursive_directory_iterator(source)) {
                if (!entry.is_regular_file() || Lower(entry.path().extension().string()) != ".dds") continue;
                Touch(root / "Pack" / std::filesystem::relative(entry.path(),source));
            }
            std::cout << "CATALOG_ONLY_MIRROR " << root.string() << '\n';
        }
        const auto profiles = bcn::SkinProfiles::ScanDirectory(root);
        std::size_t males{};
        for (const auto& profile : profiles) {
            if (profile.sex == bcn::SkinSex::male) ++males;
            std::cout << (profile.sex == bcn::SkinSex::male ? "MALE_PROFILE " : "FEMALE_PROFILE ") << profile.id << '\n';
            const auto dump = [](std::string_view role, const auto& layers) {
                for (const auto& layer : layers)
                    std::cout << role << '[' << unsigned(layer.shaderTextureIndex) << "] " << layer.path << '\n';
            };
            dump("body", profile.body); dump("hands", profile.hands);
            dump("feet", profile.feet); dump("face", profile.face);
            dump("elderBody", profile.elderBody); dump("elderHands", profile.elderHands);
            dump("elderFace", profile.elderFace); dump("vampire", profile.vampireFace);
            for (std::size_t i{};i<profile.raceFace.size();++i)
                dump("raceFace"+std::to_string(i),profile.raceFace[i]);
            for (const auto& variant : profile.maleGenitals) {
                std::cout << "GENITAL_VARIANT " << variant.addonDirectory << '\n';
                dump("genital",variant.humanoid); dump("genitalElder",variant.elder);
            }
        }
        std::cout << "PROFILE_COUNTS total=" << profiles.size() << " male=" << males << '\n';
        return 0;
    }
    if (!Require(!bcn::AllowsBroadSkinSlotFallback(bcn::SkinLayout::legacy),
            "part-specific CBBE/BHUNP atlases were routed through RaceMenu's broad skin-slot apply")) return 1;
    if (!Require(bcn::AllowsBroadSkinSlotFallback(bcn::SkinLayout::ube),
            "UBE's shared body atlas lost its broad skin-slot fallback")) return 1;

    if (argc == 3 && std::string_view{ argv[1] } == "--futanari") {
        const auto profiles = bcn::FutanariSkinProfiles::ScanDirectory(std::filesystem::path{ argv[2] });
        for (const auto& profile : profiles) {
            std::cout << profile.id << " | " << bcn::FutanariSkinTypeLabel(profile.type)
                      << " | layers=" << profile.layers.size() << '\n';
        }
        std::cout << "futanari=" << profiles.size() << '\n';
        return profiles.empty() ? 1 : 0;
    }
    if (argc == 3 || argc == 4) {
        std::cout << "scanning real skin root\n" << std::flush;
        const auto skins = bcn::SkinProfiles::ScanDirectory(std::filesystem::path{ argv[1] });
        std::cout << "scanning real tint root\n" << std::flush;
        const auto tints = bcn::player_tint::Catalog::ScanDirectory(std::filesystem::path{ argv[2] });
        if (!Require(!skins.empty(), "real skin root produced no profiles")) return 1;
        if (!Require(!tints.empty(), "real tint root produced no assets")) return 1;
        for (const auto& tint : tints) {
            if (!Require(!tint.pack.empty() && tint.pack != ".." && !tint.id.starts_with(".."),
                    "real tint root produced an escaped pack or id")) return 1;
        }
        std::unordered_set<std::string> mapped;
        const auto normalizePath = [](std::string value) {
            std::ranges::replace(value, '/', '\\');
            return Lower(std::move(value));
        };
        const auto collect = [&mapped, &normalizePath](const auto& layers) {
            for (const auto& layer : layers) mapped.insert(normalizePath(layer.path));
        };
        for (const auto& skin : skins) {
            std::cout << "verifying " << skin.name << '\n' << std::flush;
            collect(skin.body);
            collect(skin.cbbeGenitalAnal);
            collect(skin.unpGenitalAnal);
            collect(skin.hands);
            collect(skin.feet);
            collect(skin.face);
            collect(skin.vampireFace);
            collect(skin.elderBody);
            collect(skin.elderHands);
            collect(skin.elderFace);
            for (const auto& raceFace : skin.raceFace) collect(raceFace);
            collect(skin.faceDetails);
            for (const auto& variant : skin.maleGenitals) {
                collect(variant.humanoid);
                collect(variant.argonian);
                collect(variant.khajiit);
                collect(variant.elder);
            }
        }
        // Validate the complete real BodySkin tree by its full game-relative
        // path. Filename-only checks miss nested race/elder directories and
        // can accidentally accept a same-named DDS mapped from another pack.
        std::size_t verifiedSkinTextures{};
        std::size_t unrelatedDdsFiles{};
        std::size_t omittedSkinTextures{};
        std::error_code error;
        const auto skinRoot = std::filesystem::path{ argv[1] };
        for (std::filesystem::recursive_directory_iterator it(skinRoot,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (!it->is_regular_file(statusError) || statusError) continue;
            const auto filename = Lower(bcn::path_text::Utf8(it->path().filename()));
            if (!filename.ends_with(".dds")) continue;
            if (!IsStandardSkinTexture(filename)) {
                ++unrelatedDdsFiles;
                continue;
            }
            const auto relative = std::filesystem::relative(
                it->path(), skinRoot.parent_path(), error);
            if (error) {
                error.clear();
                return 1;
            }
            const auto gamePath = normalizePath(bcn::path_text::GenericUtf8(relative));
            if (!mapped.contains(gamePath)) {
                std::cerr << "omitted standard skin DDS: " << gamePath << '\n';
                ++omittedSkinTextures;
                continue;
            }
            ++verifiedSkinTextures;
        }
        if (!Require(omittedSkinTextures == 0U,
                "a standard nested skin DDS was omitted from the generated profile")) return 1;
        if (!Require(verifiedSkinTextures != 0U, "real skin packs exposed no standard DDS channels")) return 1;
        std::size_t futanariSkins{};
        if (argc == 4) {
            const auto profiles = bcn::FutanariSkinProfiles::ScanDirectory(
                std::filesystem::path{ argv[3] });
            if (!Require(!profiles.empty(), "real futanari root produced no profiles")) return 1;
            futanariSkins = profiles.size();
        }
        std::cout << "skins=" << skins.size() << " mapped-skin-dds=" << verifiedSkinTextures
                  << " unrelated-dds=" << unrelatedDdsFiles << " tints=" << tints.size()
                  << " futanari=" << futanariSkins << '\n';
        return 0;
    }

    const bcn::SettingsData defaults;
    if (!Require(!defaults.keepSkinDuringVampireLord && !defaults.keepSkinDuringWerewolf,
            "transformations must default to native creature skin")) return 1;
    if (!Require(!defaults.orefitEnabled && !defaults.orefitNippleMorphing &&
            !defaults.nippleRandomization && !defaults.genitalRandomization,
            "all four correction/randomization settings must default off")) return 1;
    if (!Require(defaults.preserveOtherMorphs && !defaults.pauseGameWhenOpen && !defaults.performanceMode && !defaults.removalMode &&
            defaults.characterPosition == bcn::CharacterPosition::left,
            "new settings must preserve foreign morphs, place actor left and disable pause/performance modes")) return 1;
    const auto sandbox = std::filesystem::temp_directory_path() / "BodyChangeNGAssetCatalogTests";
    std::filesystem::remove_all(sandbox);

    const auto originalCurrentPath = std::filesystem::current_path();
    const auto legacySettings = sandbox / "Data" / "SKSE" / "Plugins" /
        "BodyChangerNG" / "settings.json";
    std::filesystem::create_directories(legacySettings.parent_path());
    {
        std::ofstream stream(legacySettings);
        stream << R"({"schemaVersion":1,"openHotkey":{"key":66,"ctrl":true,"shift":false,"alt":false},"language":2,"characterPosition":1,"textScale":1.25})";
    }
    std::filesystem::current_path(sandbox);
    bcn::Settings::Get().Load();
    std::filesystem::current_path(originalCurrentPath);
    const auto migratedSettings = sandbox / "Data" / "SKSE" / "Plugins" /
        "BodyChangeNG" / "settings.json";
    const auto migratedSnapshot = bcn::Settings::Get().Snapshot();
    if (!Require(!migratedSnapshot.orefitEnabled && !migratedSnapshot.orefitNippleMorphing &&
            !migratedSnapshot.nippleRandomization && !migratedSnapshot.genitalRandomization,
            "missing legacy correction/randomization settings must remain off")) return 1;
    if (!Require(migratedSnapshot.preserveOtherMorphs && !migratedSnapshot.performanceMode &&
            bcn::Settings::Get().MorphOptions().preserveOtherMorphs &&
            migratedSnapshot.characterPosition == bcn::CharacterPosition::right,
            "missing preserve option must default on without replacing an explicit character position")) return 1;
    if (!Require(std::filesystem::is_regular_file(migratedSettings),
            "legacy settings were not copied to the BodyChangeNG path")) return 1;
    if (!Require(migratedSnapshot.openHotkey.key == 66U && migratedSnapshot.openHotkey.ctrl,
            "legacy settings values were not preserved during migration")) return 1;
    if (!Require(migratedSnapshot.favoriteFutanariSkins.empty(),
            "settings without futanari favorites must default to an empty list")) return 1;
    if (!Require(migratedSnapshot.femaleNpcBodyType == bcn::FemaleNpcBodyType::cbbe3ba &&
            migratedSnapshot.maleNpcBodyType == bcn::MaleNpcBodyType::himbo,
            "legacy settings migration did not preserve the new CBBE 3BA/HIMBO defaults")) return 1;

    // New defaults must not override any combination explicitly saved by a
    // user, including nipple correction ON while the parent switch is OFF.
    std::filesystem::current_path(sandbox);
    for (unsigned mask{}; mask < 16U; ++mask) {
        auto appearance = migratedSnapshot;
        appearance.orefitEnabled = (mask & 1U) != 0U;
        appearance.orefitNippleMorphing = (mask & 2U) != 0U;
        appearance.nippleRandomization = (mask & 4U) != 0U;
        appearance.genitalRandomization = (mask & 8U) != 0U;
        bcn::Settings::Get().Update(appearance);
        if (!Require(bcn::Settings::Get().Save(), "appearance option save failed")) return 1;
        bcn::Settings::Get().Load();
        const auto loaded = bcn::Settings::Get().MorphOptions();
        if (!Require(loaded.outfitCorrection == appearance.orefitEnabled &&
                loaded.outfitNippleCorrection == appearance.orefitNippleMorphing &&
                loaded.nippleRandomization == appearance.nippleRandomization &&
                loaded.genitalRandomization == appearance.genitalRandomization,
                "explicit appearance options replaced by new defaults")) return 1;
    }
    bcn::Settings::Get().Update(migratedSnapshot);
    if (!Require(bcn::Settings::Get().Save(), "appearance option fixture restore failed")) return 1;
    std::filesystem::current_path(originalCurrentPath);

    const std::string skinPackName{ "피부팩 简体" };
    // Popup positions survive restart independently, including the four NPC
    // distribution editors, without changing any appearance/distribution data.
    using PopupKind = bcn::popup_placement::Kind;
    auto& popupSettings = bcn::Settings::Get();
    auto nonPreserving = popupSettings.Snapshot();
    nonPreserving.preserveOtherMorphs = false;
    nonPreserving.pauseGameWhenOpen = true;
    nonPreserving.performanceMode = true;
    nonPreserving.removalMode = true;
    nonPreserving.keepSkinDuringVampireLord = true;
    nonPreserving.keepSkinDuringWerewolf = false;
    nonPreserving.favoriteBodyPresets = { "body-preset" };
    nonPreserving.favoriteSkinProfiles = { "auto:skin-pack:female" };
    nonPreserving.favoriteTintPacks = { "tint-pack" };
    nonPreserving.favoriteOverlays = { "overlay-entry" };
    const std::vector<std::string> futanariFavorites{
        "futanari:후타팩 简体:erf", "futanari:후타팩 简体:cbbe-trx", "futanari:후타팩 简体:ube-trx"
    };
    nonPreserving.favoriteFutanariSkins = futanariFavorites;
    nonPreserving.favoriteFutanariSkins.push_back(futanariFavorites.front());
    popupSettings.Update(nonPreserving);
    for (std::size_t index{}; index < bcn::popup_placement::keys.size(); ++index) {
        const auto kind = static_cast<PopupKind>(index);
        if (!Require(!popupSettings.PopupPosition(kind).set,
                "old settings must open previously unseen popups at center")) return 1;
        const auto x = 100.0F + static_cast<float>(index) * 20.0F;
        if (!Require(popupSettings.RememberPopupPosition(kind, x, 220.0F), "popup position not remembered")) return 1;
        if (!Require(!popupSettings.RememberPopupPosition(kind, x, 220.0F), "unchanged popup causes repeated saves")) return 1;
    }
    std::filesystem::current_path(sandbox);
    if (!Require(popupSettings.Save(), "popup settings save failed")) return 1;
    popupSettings.Load();
    if (!Require(popupSettings.Snapshot().keepSkinDuringVampireLord &&
            !popupSettings.Snapshot().keepSkinDuringWerewolf,
            "separate transformation settings did not survive save/load")) return 1;
    if (!Require(popupSettings.Snapshot().favoriteFutanariSkins == futanariFavorites,
            "futanari favorites must survive restart, deduplicate and preserve pack/type/UTF-8 IDs")) return 1;
    if (!Require(!popupSettings.Snapshot().preserveOtherMorphs &&
            !popupSettings.MorphOptions().preserveOtherMorphs &&
            popupSettings.Snapshot().pauseGameWhenOpen &&
            popupSettings.Snapshot().performanceMode &&
            popupSettings.RemovalMode() &&
            popupSettings.Snapshot().characterPosition == bcn::CharacterPosition::right,
            "explicit morph/pause/position settings did not survive reload")) return 1;
    const auto offSignature = popupSettings.BodyApplicationOptions();
    auto preserving = popupSettings.Snapshot();
    preserving.preserveOtherMorphs = true;
    preserving.removalMode = false;
    popupSettings.Update(preserving);
    if (!Require(popupSettings.Save(), "preserving settings save failed")) return 1;
    popupSettings.Load();
    if (!Require(popupSettings.MorphOptions().preserveOtherMorphs &&
            !popupSettings.RemovalMode() &&
            popupSettings.BodyApplicationOptions() != offSignature,
            "preserve option reload/signature did not change application policy")) return 1;
    auto unfavorited = popupSettings.Snapshot();
    std::erase(unfavorited.favoriteFutanariSkins, futanariFavorites.front());
    popupSettings.Update(unfavorited);
    if (!Require(popupSettings.Save(), "futanari unfavorite save failed")) return 1;
    popupSettings.Load();
    if (!Require(popupSettings.Snapshot().favoriteFutanariSkins ==
            std::vector<std::string>(futanariFavorites.begin() + 1, futanariFavorites.end()),
            "unfavoriting one addon type must not remove the same pack's other types")) return 1;
    {
        nlohmann::json saved;
        {
            std::ifstream stream(migratedSettings);
            stream >> saved;
        }
        saved["favoriteFutanariSkins"].push_back(42);
        saved["favoriteFutanariSkins"].push_back(nullptr);
        saved["favoriteFutanariSkins"].push_back(std::string(1025U, 'x'));
        WriteText(migratedSettings, saved.dump());
    }
    popupSettings.Load();
    const auto favoritesReloaded = popupSettings.Snapshot();
    if (!Require(favoritesReloaded.favoriteFutanariSkins == unfavorited.favoriteFutanariSkins &&
            favoritesReloaded.favoriteBodyPresets == nonPreserving.favoriteBodyPresets &&
            favoritesReloaded.favoriteSkinProfiles == nonPreserving.favoriteSkinProfiles &&
            favoritesReloaded.favoriteTintPacks == nonPreserving.favoriteTintPacks &&
            favoritesReloaded.favoriteOverlays == nonPreserving.favoriteOverlays,
            "malformed futanari favorites must not discard valid entries or other tabs' favorites")) return 1;
    std::filesystem::current_path(originalCurrentPath);
    for (std::size_t index{}; index < bcn::popup_placement::keys.size(); ++index) {
        const auto position = popupSettings.PopupPosition(static_cast<PopupKind>(index));
        if (!Require(position.set && position.x == 100.0F + static_cast<float>(index) * 20.0F &&
                position.y == 220.0F, "popup position did not survive settings reload")) return 1;
    }
    if (!Require(popupSettings.Snapshot().openHotkey.key == 66U,
            "saving popup positions overwrote unrelated settings")) return 1;

    const auto female = sandbox / "BodySkin" / std::filesystem::path{ L"피부팩 简体" } /
        "Textures" / "actors" / "character" / "female";
    for (const auto* file : {
             "femalebody_1.dds", "femalebody_1_msn.dds", "femalebody_1_sk.dds", "femalebody_1_s.dds",
             "femalebody_etc_v2_1.dds", "femalebody_etc_v2_1_msn.dds",
             "femalebody_etc_v2_1_sk.dds", "femalebody_etc_v2_1_s.dds",
             "femalehands_1.dds", "femalehead.dds", "femalehead_msn.dds", "femalehead_s.dds",
             "blankdetailmap.dds", "femaleheaddetail_frekles.DDS" }) {
        Touch(female / file);
    }
    for (const auto* file : {
             "astridbody.dds", "astridhands_msn.dds", "astridhead_s.dds",
             "femalebodyafflicted.dds", "femalehandsafflicted.dds", "femaleheadafflicted.dds" }) {
        Touch(female / file);
    }
    const auto femaleOld = female.parent_path() / "femaleold";
    Touch(femaleOld / "FemaleBody_1_msn.dds");
    Touch(femaleOld / "FemaleHands_1_msn.dds");
    Touch(femaleOld / "FemaleHead_msn.dds");
    const std::array raceFaceDirectories{
        std::pair{ "nordfemale", "femalehead_msn.dds" },
        std::pair{ "bretonfemale", "femalehead_msn.dds" },
        std::pair{ "darkelffemale", "femalehead_msn.dds" },
        std::pair{ "highelffemale", "femalehead_msn.dds" },
        std::pair{ "imperialfemale", "femalehead_msn.dds" },
        std::pair{ "femaleorc", "femaleheadorc_msn.dds" },
        std::pair{ "redguardfemale", "femalehead_msn.dds" },
        std::pair{ "woodelffemale", "femalehead_msn.dds" }
    };
    for (const auto& [directory, filename] : raceFaceDirectories) {
        Touch(female.parent_path() / directory / filename);
    }
    const auto embeddedTint = female.parent_path() / "character assets" / "tintmasks";
    Touch(embeddedTint / "femalehead_lips.dds");

    const std::string unpSkinPackName{ "BnP BHUNP UNP" };
    const auto unpFemale = sandbox / "BodySkin" / unpSkinPackName /
        "Textures" / "actors" / "character" / "female";
    for (const auto* file : {
             "femalebody_1.dds", "femalebody_1_msn.dds", "femalebody_1_sk.dds", "femalebody_1_s.dds",
             "femalehands_1.dds", "femalehands_1_msn.dds", "femalehands_1_sk.dds", "femalehands_1_s.dds",
             "femalefeet_1.dds", "femalefeet_1_msn.dds", "femalefeet_1_sk.dds", "femalefeet_1_s.dds",
             "femalehead.dds", "femalehead_msn.dds", "femalehead_sk.dds", "femalehead_s.dds" }) {
        Touch(unpFemale / file);
    }
    for (const auto* file : {
             "VaginalAnalCanal2.dds", "VaginalAnalCanal2_msn.dds",
             "VaginalAnalCanal2_sk.dds", "VaginalAnalCanal2_s.dds" }) {
        Touch(unpFemale / "BakaUNP" / file);
    }

    // Mirrors the seven conventional Toolred pack folder names which exposed
    // the 1.2 regression: no metadata and no CBBE/UNP token is required.
    const std::array<std::string_view, 7> toolredLegacyPackNames{
        "니블A",
        "다이아 (뷰지스 기본)",
        "다이아 보추",
        "다이아 Ni 밝은톤",
        "다이아+지젠+툴리소스+리얼걸+NI+다렌",
        "린아 ver2",
        "DiamondZhizhenGlass"
    };
    for (const auto packName : toolredLegacyPackNames) {
        const auto directory = sandbox / "BodySkin" /
            bcn::path_text::FromUtf8(packName) / "Textures" /
            "actors" / "character" / "female";
        Touch(directory / "femalebody_1.dds");
        Touch(directory / "femalehands_1.dds");
        Touch(directory / "femalehead.dds");
    }
    // A leftover schema-1 manifest must not override automatic identity or
    // turn a conventional female texture tree into UBE.
    WriteText(sandbox / "BodySkin" /
        bcn::path_text::FromUtf8(toolredLegacyPackNames.front()) / "profile.json",
        R"json({"schemaVersion":1,"id":"must-not-load","sex":"female","uvLayout":"ube"})json");

    const auto ubeBody = sandbox / "BodySkin" / "UBE 2.0 Momo Skin" /
        "Textures" / "!UBE" / "Body";
    const auto ubeHead = sandbox / "BodySkin" / "UBE 2.0 Momo Skin" /
        "Textures" / "!UBE" / "Head";
    for (const auto* file : { "femalebody_1_d.dds", "femalebody_1_n.dds", "femalebody_1_sk.dds" }) {
        Touch(ubeBody / file);
    }
    for (const auto* file : { "femalehead_d.dds", "femalehead_n.dds", "femalehead_sk.dds" }) {
        Touch(ubeHead / file);
    }
    // Selected packs must not replace the installed CS effect maps or add
    // specular/environment/multilayer channels to the six base skin maps.
    for (const auto* suffix : { "_RFAOS.dds", "_wet.dds", "_s.dds" }) {
        WriteText(ubeBody / (std::string{ "femalebody_1" } + suffix), "pack-body-effect");
        WriteText(ubeHead / (std::string{ "femalehead" } + suffix), "pack-head-effect");
    }

    const auto malePartial = sandbox / "BodySkin" / "Male Partial" /
        "Textures" / "actors" / "character" / "male";
    Touch(malePartial / "malebody_1.dds");
    Touch(malePartial / "malebody_1_s.dds");
    Touch(malePartial / "malehead_msn.dds");

    const auto explicitHimbo = sandbox / "BodySkin" / "Explicit HIMBO";
    Touch(explicitHimbo / "Textures" / "actors" / "character" / "male" / "malebody_1.dds");
    WriteText(explicitHimbo / "profile.json", R"json({
  "schemaVersion": 1,
  "id": "explicit-himbo",
  "name": "Explicit HIMBO",
  "sex": "male",
  "race": "humanoid",
  "uvLayout": "himbo",
  "body": [
    { "index": 0, "path": "Textures\\actors\\character\\male\\malebody_1.dds" }
  ]
})json");

    const auto ambiguousExplicit = sandbox / "BodySkin" / "Ambiguous Explicit Male";
    Touch(ambiguousExplicit / "Textures" / "actors" / "character" / "male" / "malebody_1.dds");
    WriteText(ambiguousExplicit / "profile.json", R"json({
  "schemaVersion": 1,
  "id": "ambiguous-explicit-male",
  "name": "Ambiguous Explicit Male",
  "sex": "male",
  "body": [
    { "index": 0, "path": "Textures\\actors\\character\\male\\malebody_1.dds" }
  ]
})json");
    const auto sosRegular = malePartial.parent_path() / "SOS" / "VectorPlexus Regular";
    for (const auto* file : { "malegenitals_1.dds", "malegenitals_1_msn.dds",
             "malegenitals_1_sk.dds", "malegenitals_1_s.dds" }) {
        Touch(sosRegular / file);
    }
    Touch(sosRegular / "malegenitals_argonian_1.dds");
    Touch(sosRegular / "malegenitals_argonian_1_msn.dds");
    Touch(sosRegular / "malegenitals_khajiit_1.dds");
    Touch(sosRegular / "malegenitals_old_1_msn.dds");
    const auto sosMuscular = malePartial.parent_path() / "SOS" / "VectorPlexus Muscular";
    Touch(sosMuscular / "malegenitals_1_msn.dds");
    Touch(sosMuscular / "malegenitals_argonian_1_msn.dds");
    const auto sosSmurfRaceOnly = malePartial.parent_path() / "SOS" / "Smurf Average";
    Touch(sosSmurfRaceOnly / "malegenitals_khajiit_1_s.dds");

    const auto handsOnly = sandbox / "BodySkin" / "Hands Only" /
        "Textures" / "actors" / "character" / "male";
    Touch(handsOnly / "malehands_1_msn.dds");

    for (const auto* packName : { "HIMBO Skin SOS", "SAM Skin SOS" }) {
        const auto male = sandbox / "BodySkin" / packName /
            "Textures" / "actors" / "character" / "male";
        Touch(male / "malebody_1.dds");
        const auto sos = male.parent_path() / "SOS" / "VectorPlexus Regular";
        Touch(sos / "malegenitals_1.dds");
        Touch(sos / "malegenitals_1_msn.dds");
    }

    const auto ubeHeadOnly = sandbox / "BodySkin" / "UBE Head Only" /
        "Textures" / "!UBE" / "Head";
    Touch(ubeHeadOnly / "femalehead_d.dds");

    const auto argonianFemale = sandbox / "BodySkin" / "Argonian Complete" /
        "Textures" / "actors" / "character" / "argonianfemale";
    Touch(argonianFemale / "argonianfemalebody.dds");
    Touch(argonianFemale / "argonianfemalebody_msn.dds");
    Touch(argonianFemale / "argonianfemalehands_sk.dds");
    Touch(argonianFemale / "argonianfemalehead_s.dds");
    const auto argonianMale = sandbox / "BodySkin" / "Argonian Complete" /
        "Textures" / "actors" / "character" / "argonianmale";
    Touch(argonianMale / "argonianmalebody.dds");
    Touch(argonianMale / "argonianmalehands_msn.dds");
    Touch(argonianMale / "argonianmalehead.dds");

    const auto khajiitFemale = sandbox / "BodySkin" / "Khajiit Complete" /
        "Textures" / "actors" / "character" / "khajiitfemale";
    Touch(khajiitFemale / "femalebody.dds");
    Touch(khajiitFemale / "femalehands_s.dds");
    Touch(khajiitFemale / "femalehead_msn.dds");
    const auto khajiitMale = sandbox / "BodySkin" / "Khajiit Complete" /
        "Textures" / "actors" / "character" / "khajiitmale";
    Touch(khajiitMale / "bodymale.dds");
    Touch(khajiitMale / "handsmale_msn.dds");
    Touch(khajiitMale / "headmale_s.dds");

    const auto skins = bcn::SkinProfiles::ScanDirectory(sandbox / "BodySkin");
    if (!Require(
            bcn::SkinFamilyLabel(bcn::SkinLayout::legacy, bcn::SkinSex::female) == "CBBE or UNP" &&
            bcn::SkinFamilyLabel(bcn::SkinLayout::legacy, bcn::SkinSex::male) == "HIMBO or SAM" &&
            bcn::SkinFamilyLabel(bcn::SkinLayout::ube, bcn::SkinSex::female) == "UBE",
            "skin-list labels exposed the internal Legacy classification or mixed sex families")) return 1;
    const auto discoveredSkinRoots = bcn::catalog_roots::Discover(sandbox / "BodySkin");
    std::error_code equivalentError;
    if (!Require(!discoveredSkinRoots.empty() &&
            std::filesystem::equivalent(discoveredSkinRoots.front(), sandbox / "BodySkin", equivalentError) &&
            !equivalentError,
            "catalog root discovery climbed above the physical BodySkin provider")) return 1;
    if (!Require(skins.size() == 21U, "skin scanner did not preserve valid humanoid and beast-race skin rows")) return 1;
    const auto cbbeFamily = bcn::body_family::Bit(bcn::body_family::Family::cbbe);
    const auto unpFamilyForLegacy = bcn::body_family::Bit(bcn::body_family::Family::unp);
    const auto ubeFamilyForLegacy = bcn::body_family::Bit(bcn::body_family::Family::ube);
    for (const auto packName : toolredLegacyPackNames) {
        const auto expectedId = "auto:" + std::string{ packName } + ":female";
        const auto found = std::ranges::find(skins, expectedId, &bcn::SkinProfile::id);
        if (!Require(found != skins.end() && found->layout == bcn::SkinLayout::legacy &&
                bcn::SkinLayoutMatchesActor(found->layout, cbbeFamily) &&
                bcn::SkinLayoutMatchesActor(found->layout, unpFamilyForLegacy) &&
                !bcn::SkinLayoutMatchesActor(found->layout, ubeFamilyForLegacy),
                "a Toolred-style metadata-free female pack was not restored as a stable Legacy row")) return 1;
    }
    const auto explicitHimboSkin = std::ranges::find(
        skins, "auto:Explicit HIMBO:male", &bcn::SkinProfile::id);
    const auto metadataOnlyId = std::ranges::find(
        skins, "explicit-himbo", &bcn::SkinProfile::id);
    const auto formerlyAmbiguousMale = std::ranges::find(
        skins, "auto:Ambiguous Explicit Male:male", &bcn::SkinProfile::id);
    if (!Require(explicitHimboSkin != skins.end() &&
            explicitHimboSkin->layout == bcn::SkinLayout::legacy &&
            formerlyAmbiguousMale != skins.end() &&
            formerlyAmbiguousMale->layout == bcn::SkinLayout::legacy &&
            metadataOnlyId == skins.end() &&
            std::ranges::find(skins, "must-not-load",
                &bcn::SkinProfile::id) == skins.end() &&
            std::ranges::find(skins, "ambiguous-explicit-male",
                &bcn::SkinProfile::id) == skins.end(),
            "skin metadata JSON changed automatic identity or Legacy classification")) return 1;
    std::size_t argonianRows{};
    std::size_t khajiitRows{};
    for (const auto& skin : skins) {
        if (skin.name == "Argonian Complete") {
            ++argonianRows;
            if (!Require(skin.race == bcn::SkinRace::argonian &&
                    skin.id.ends_with(skin.sex == bcn::SkinSex::female ? ":female:argonian" : ":male:argonian"),
                    "Argonian skin row lost its race, sex, or stable id")) return 1;
            if (!Require(!skin.body.empty() && !skin.hands.empty() && !skin.face.empty() && skin.feet.empty(),
                    "Argonian partial parts were omitted or copied into feet")) return 1;
            const auto expectedBody = skin.sex == bcn::SkinSex::female ? "argonianfemalebody" : "argonianmalebody";
            if (!Require(std::ranges::all_of(skin.body, [expectedBody](const auto& layer) {
                    return Filename(Lower(layer.path)).starts_with(expectedBody);
                }), "Argonian body channels crossed into another part or sex")) return 1;
            continue;
        }
        if (skin.name == "Khajiit Complete") {
            ++khajiitRows;
            if (!Require(skin.race == bcn::SkinRace::khajiit &&
                    skin.id.ends_with(skin.sex == bcn::SkinSex::female ? ":female:khajiit" : ":male:khajiit"),
                    "Khajiit skin row lost its race, sex, or stable id")) return 1;
            if (!Require(!skin.body.empty() && !skin.hands.empty() && !skin.face.empty() && skin.feet.empty(),
                    "Khajiit partial parts were omitted or copied into feet")) return 1;
            const auto expectedBody = skin.sex == bcn::SkinSex::female ? "femalebody" : "bodymale";
            if (!Require(std::ranges::all_of(skin.body, [expectedBody](const auto& layer) {
                    return Filename(Lower(layer.path)).starts_with(expectedBody);
                }), "Khajiit body channels crossed into another part or sex")) return 1;
            continue;
        }
        if (skin.name == unpSkinPackName) {
            if (!Require(skin.sex == bcn::SkinSex::female &&
                    skin.layout == bcn::SkinLayout::legacy,
                    "BHUNP/UNP skin was not classified as Legacy")) return 1;
            if (!Require(HasExactMaterialChannels(skin.body, "femalebody_1") &&
                    HasExactMaterialChannels(skin.hands, "femalehands_1") &&
                    HasExactMaterialChannels(skin.feet, "femalefeet_1") &&
                    HasExactMaterialChannels(skin.face, "femalehead"),
                    "BHUNP/UNP body, hands, feet, or face channels crossed parts or material slots")) return 1;
            if (!Require(skin.cbbeGenitalAnal.empty() &&
                    HasExactMaterialChannels(skin.unpGenitalAnal, "vaginalanalcanal2"),
                    "BHUNP/UNP genital/anal/canal atlas was omitted or routed as CBBE")) return 1;
            if (!Require(skin.id.ends_with(":female"),
                    "BHUNP/UNP conventional profile lost its stable id")) return 1;
            continue;
        }
        if (skin.name == "UBE 2.0 Momo Skin") {
            if (!Require(skin.sex == bcn::SkinSex::female, "UBE skin leaked into the wrong sex")) return 1;
            if (!Require(skin.layout == bcn::SkinLayout::ube,
                    "UBE texture namespace was not classified as UBE")) return 1;
            if (!Require(skin.body.size() == 3U && skin.face.size() == 3U &&
                    skin.hands.empty() && skin.feet.empty(),
                    "UBE Body/Head d, n, and sk channels were not mapped exactly")) return 1;
            for (const auto* layers : { &skin.body, &skin.face }) {
                const std::string stem = layers == &skin.body ? "femalebody_1" : "femalehead";
                const std::array suffixes{ "_d.dds", "_n.dds", "_sk.dds" };
                for (std::size_t index{}; index < suffixes.size(); ++index) {
                    if (!Require(std::ranges::any_of(*layers, [&](const auto& layer) {
                            return layer.shaderTextureIndex == index &&
                                Filename(Lower(layer.path)) == stem + suffixes[index];
                        }), "UBE base-channel whitelist changed")) return 1;
                }
            }
            if (!Require(skin.id.ends_with(":female:ube"), "UBE profile id can collide with a conventional profile")) return 1;
            continue;
        }
        if (skin.name == "UBE Head Only") {
            if (!Require(skin.sex == bcn::SkinSex::female && skin.body.empty() &&
                    skin.hands.empty() && skin.feet.empty() && skin.face.size() == 1U,
                    "partial UBE head pack borrowed or invented another body part")) return 1;
            continue;
        }
        if (std::ranges::find(toolredLegacyPackNames, skin.name) !=
            toolredLegacyPackNames.end()) {
            if (!Require(skin.sex == bcn::SkinSex::female &&
                    skin.layout == bcn::SkinLayout::legacy &&
                    skin.body.size() == 1U && skin.hands.size() == 1U &&
                    skin.face.size() == 1U,
                    "a metadata-free Toolred-style pack lost its Legacy parts")) return 1;
            continue;
        }
        if (skin.name == "Male Partial") {
            if (!Require(skin.sex == bcn::SkinSex::male && skin.body.size() == 2U &&
                    skin.hands.empty() && skin.feet.empty() && skin.face.size() == 1U,
                    "partial male pack lost a supplied channel or synthesized a missing part")) return 1;
            if (!Require(std::ranges::all_of(skin.body, [](const auto& layer) {
                    return Filename(Lower(layer.path)).starts_with("malebody_1");
                }) && std::ranges::all_of(skin.face, [](const auto& layer) {
                    return Filename(Lower(layer.path)).starts_with("malehead");
                }), "male body and face files crossed part boundaries")) return 1;
            if (!Require(skin.maleGenitals.size() == 3U,
                    "SOS addon texture directories were not kept as separate variants")) return 1;
            const auto regular = std::ranges::find(
                skin.maleGenitals, "VectorPlexus Regular",
                &bcn::MaleGenitalTextureVariant::addonDirectory);
            const auto muscular = std::ranges::find(
                skin.maleGenitals, "VectorPlexus Muscular",
                &bcn::MaleGenitalTextureVariant::addonDirectory);
            const auto smurf = std::ranges::find(
                skin.maleGenitals, "Smurf Average",
                &bcn::MaleGenitalTextureVariant::addonDirectory);
            if (!Require(regular != skin.maleGenitals.end() && regular->humanoid.size() == 4U &&
                    regular->argonian.size() == 2U && regular->khajiit.size() == 1U &&
                    regular->elder.size() == 1U,
                    "SOS Regular humanoid/race/elder channels were not mapped exactly")) return 1;
            if (!Require(muscular != skin.maleGenitals.end() && muscular->humanoid.size() == 1U &&
                    muscular->humanoid.front().shaderTextureIndex == 1U &&
                    muscular->argonian.size() == 1U,
                    "SOS Muscular normal-only material was expanded into invented channels")) return 1;
            if (!Require(smurf != skin.maleGenitals.end() && smurf->humanoid.empty() &&
                    smurf->argonian.empty() && smurf->khajiit.size() == 1U && smurf->elder.empty() &&
                    smurf->khajiit.front().shaderTextureIndex == 7U,
                    "SOS race-only partial atlas was not registered independently")) return 1;
            continue;
        }
        if (skin.name == "Hands Only") {
            if (!Require(skin.sex == bcn::SkinSex::male && skin.body.empty() &&
                    skin.hands.size() == 1U && skin.feet.empty() && skin.face.empty(),
                    "hands-only pack was rejected or copied into body, feet, or face")) return 1;
            if (!Require(skin.hands.front().shaderTextureIndex == 1U,
                    "hands normal map was not kept on the hands normal channel")) return 1;
            continue;
        }
        if (skin.name == "Explicit HIMBO" ||
            skin.name == "Ambiguous Explicit Male") {
            if (!Require(skin.sex == bcn::SkinSex::male &&
                    skin.layout == bcn::SkinLayout::legacy &&
                    skin.body.size() == 1U && skin.hands.empty() &&
                    skin.feet.empty() && skin.face.empty(),
                    "a stale skin metadata file changed automatic male discovery")) return 1;
            continue;
        }
        if (skin.name == "HIMBO Skin SOS" || skin.name == "SAM Skin SOS") {
            if (!Require(skin.sex == bcn::SkinSex::male &&
                    skin.layout == bcn::SkinLayout::legacy && skin.body.size() == 1U &&
                    skin.maleGenitals.size() == 1U &&
                    skin.maleGenitals.front().addonDirectory == "VectorPlexus Regular" &&
                    skin.maleGenitals.front().humanoid.size() == 2U,
                    "HIMBO/SAM skin and its same-pack SOS atlas were not kept together")) return 1;
            continue;
        }
        if (!Require(skin.sex == bcn::SkinSex::female && !skin.body.empty() &&
                !skin.hands.empty() && !skin.face.empty(),
                "conventional female skin lost one of its supplied parts")) return 1;
        if (!Require(skin.feet.empty(), "missing feet incorrectly borrowed the body texture")) return 1;
        if (!Require(skin.body.size() == 4U && std::ranges::all_of(skin.body, [](const auto& layer) {
                return Filename(Lower(layer.path)).starts_with("femalebody_1");
            }), "female genital atlas crossed into the regular body channels")) return 1;
        constexpr std::array expectedCBBEGenitalAnalChannels{
            std::pair{ 0U, std::string_view{ "femalebody_etc_v2_1.dds" } },
            std::pair{ 1U, std::string_view{ "femalebody_etc_v2_1_msn.dds" } },
            std::pair{ 2U, std::string_view{ "femalebody_etc_v2_1_sk.dds" } },
            std::pair{ 7U, std::string_view{ "femalebody_etc_v2_1_s.dds" } }
        };
        if (!Require(skin.cbbeGenitalAnal.size() == expectedCBBEGenitalAnalChannels.size() &&
                skin.unpGenitalAnal.empty(),
                "CBBE 3BA genital/anal texture set crossed into BHUNP/UNP")) return 1;
        for (const auto& [index, filename] : expectedCBBEGenitalAnalChannels) {
            if (!Require(std::ranges::any_of(skin.cbbeGenitalAnal, [=](const auto& layer) {
                    return layer.shaderTextureIndex == index && Filename(Lower(layer.path)) == filename;
                }), "CBBE 3BA genital/anal diffuse/normal/subsurface/specular mapping is incorrect")) return 1;
        }
        if (!Require(skin.layout == bcn::SkinLayout::legacy,
                "a CBBE 3BA genital atlas incorrectly narrowed the Legacy skin")) return 1;
        if (!Require(skin.name.contains(skinPackName), "skin pack name was not preserved as UTF-8")) return 1;
        if (!Require(skin.body.front().path.starts_with("BodySkin\\" + skinPackName + "\\Textures\\"),
                "skin path escaped the virtual Data root or lost UTF-8")) return 1;
        const auto bodySkinTint = std::ranges::find_if(skin.body, [](const auto& layer) {
            return layer.path.ends_with("_sk.dds");
        });
        if (!Require(bodySkinTint != skin.body.end() && bodySkinTint->shaderTextureIndex == 2U,
                "_sk texture was not mapped to BSTextureSet subsurface slot 2")) return 1;
        const auto bodySpecular = std::ranges::find_if(skin.body, [](const auto& layer) {
            return layer.path.ends_with("_s.dds");
        });
        if (!Require(bodySpecular != skin.body.end() && bodySpecular->shaderTextureIndex == 7U,
                "_s texture was not mapped to BSTextureSet specular slot 7")) return 1;
        if (!Require(!skin.faceDetails.empty() && skin.faceDetails.front().shaderTextureIndex == 3U,
                "FaceGen detail texture was not mapped to BSTextureSet detail slot 3")) return 1;
        if (!Require(skin.elderBody.size() == 1U && skin.elderHands.size() == 1U &&
                skin.elderFace.size() == 1U &&
                skin.elderBody.front().shaderTextureIndex == 1U &&
                skin.elderHands.front().shaderTextureIndex == 1U &&
                skin.elderFace.front().shaderTextureIndex == 1U,
                "partial femaleold normals were not kept on their exact elder body/hand/face slots")) return 1;
        for (const auto race : {
                 bcn::HumanoidSkinRace::nord, bcn::HumanoidSkinRace::breton,
                 bcn::HumanoidSkinRace::darkElf, bcn::HumanoidSkinRace::highElf,
                 bcn::HumanoidSkinRace::imperial, bcn::HumanoidSkinRace::orc,
                 bcn::HumanoidSkinRace::redguard, bcn::HumanoidSkinRace::woodElf }) {
            const auto& layers = skin.raceFace[static_cast<std::size_t>(race)];
            if (!Require(layers.size() == 1U && layers.front().shaderTextureIndex == 1U,
                    "race-specific female face normal was not retained as a conditional face slot")) return 1;
        }
        if (!Require(skin.raceFace[static_cast<std::size_t>(bcn::HumanoidSkinRace::generic)].empty(),
                "a conditional race face was misclassified as the generic face")) return 1;
        const auto isExcludedBodySkinFile = [](const auto& layer) {
            const auto path = Lower(layer.path);
            return path.find("astrid") != std::string::npos ||
                path.find("afflicted") != std::string::npos ||
                path.find("tintmasks") != std::string::npos;
        };
        bool foundExcluded{};
        const auto inspectExcluded = [&](const auto& layers) {
            foundExcluded = foundExcluded || std::ranges::any_of(layers, isExcludedBodySkinFile);
        };
        inspectExcluded(skin.body);
        inspectExcluded(skin.cbbeGenitalAnal);
        inspectExcluded(skin.unpGenitalAnal);
        inspectExcluded(skin.hands);
        inspectExcluded(skin.feet);
        inspectExcluded(skin.face);
        inspectExcluded(skin.vampireFace);
        inspectExcluded(skin.elderBody);
        inspectExcluded(skin.elderHands);
        inspectExcluded(skin.elderFace);
        for (const auto& raceFace : skin.raceFace) inspectExcluded(raceFace);
        inspectExcluded(skin.faceDetails);
        if (!Require(!foundExcluded,
                "Astrid, Afflicted, or embedded tintmask files leaked into Body Skin mapping")) return 1;
    }
    if (!Require(argonianRows == 2U && khajiitRows == 2U,
            "beast-race packs did not produce separate female and male rows")) return 1;

    const auto futanariRoot = sandbox / "Futanari";
    const auto futaUbe = futanariRoot / "UBE TRX" / "Textures" / "!UBE" / "Body";
    Touch(futaUbe / "malebody_1_d.dds");
    Touch(futaUbe / "malebody_1_n.dds");
    // One pack can carry both UBE UV layouts without merging their rows.
    const auto futaUbeTrx = futanariRoot / "UBE TRX" / "TeXtUrEs" / "[tRx] FuTa AdDoN UbE";
    for (const auto* file : { "Schlong.DDS", "Schlong_msn.dds", "Schlong_sk.dds",
             "Schlong_s.dds" }) Touch(futaUbeTrx / file);
    const auto futaTrx = futanariRoot / "CBBE TRX" / "textures" /
        "[TRX] Futa addon" / "Regular" / "Default";
    for (const auto* file : { "schlong.dds", "schlong_msn.dds", "schlong_sk.dds",
             "schlong_s.dds", "wetschlong_110_s.dds" }) Touch(futaTrx / file);
    // An unrelated optional atlas in the same pack must not create a second
    // or incorrectly typed row.
    Touch(futanariRoot / "CBBE TRX" / "textures" / "Dw3BA" / "Default" / "schlong.dds");
    const auto futaErf = futanariRoot / "ERF" / "textures" /
        "erf_futanari" / "fairskincbbe";
    for (const auto* file : { "futanari_schlong.dds", "futanari_schlong_msn.dds",
             "futanari_schlong_sk.dds", "futanari_schlong_s.dds" }) Touch(futaErf / file);

    const auto futanari = bcn::FutanariSkinProfiles::ScanDirectory(futanariRoot);
    if (!Require(futanari.size() == 4U,
            "futanari catalog did not isolate native UBE, TRX UBE, CBBE TRX, and ERF rows")) return 1;
    const auto oldUbe = std::ranges::find(futanari, "futanari:UBE TRX:ube-trx", &bcn::FutanariSkinProfile::id);
    const auto newUbeTrx = std::ranges::find(futanari, "futanari:UBE TRX:ube-trx-addon", &bcn::FutanariSkinProfile::id);
    if (!Require(oldUbe != futanari.end() && newUbeTrx != futanari.end() &&
            oldUbe->type == bcn::FutanariSkinType::ubeTrx &&
            newUbeTrx->type == bcn::FutanariSkinType::ubeTrxAddon,
            "existing native UBE saved/favorite ID changed or collided with the TRX UBE row")) return 1;
    const auto requireFutanari = [&](const bcn::FutanariSkinType type,
        const std::string_view stem) {
        const auto found = std::ranges::find(futanari, type, &bcn::FutanariSkinProfile::type);
        if (found == futanari.end()) return false;
        return type == bcn::FutanariSkinType::ubeTrx ?
            HasExactUbeMaterialChannels(found->layers, stem) :
            HasExactMaterialChannels(found->layers, stem);
    };
    if (!Require(requireFutanari(bcn::FutanariSkinType::ubeTrx, "malebody_1") &&
            requireFutanari(bcn::FutanariSkinType::ubeTrxAddon, "schlong") &&
            requireFutanari(bcn::FutanariSkinType::cbbeTrx, "schlong") &&
            requireFutanari(bcn::FutanariSkinType::erf, "futanari_schlong"),
            "futanari skin files crossed addon/body types or material channels")) return 1;
    if (!Require(
            !bcn::futanari::BodySkinOwnsSosSlot(true) &&
            bcn::futanari::BodySkinOwnsSosSlot(false) &&
            bcn::futanari::ClassifyEvidence(
                R"(meshes\[TRX] Futa addon\Regular\trx_schlong_1.nif)", {}, {}) ==
                bcn::futanari::AddonKind::trx &&
            bcn::futanari::ClassifyEvidence(
                R"(meshes\!UBE\SOS_Addon\ube_penis_1.nif)", {}, {}) ==
                bcn::futanari::AddonKind::ube &&
            bcn::futanari::ClassifyEvidence({}, "Penis",
                R"(Textures\!UBE\Body\malebody_1_d.dds)") ==
                bcn::futanari::AddonKind::ube &&
            bcn::futanari::ClassifyEvidence({}, "penis",
                R"(textures\BodyChangeNG\Cache\futanari\1234\malebody_1_d.dds)") ==
                bcn::futanari::AddonKind::none &&
            bcn::futanari::ClassifyEvidence(
                R"(meshes\[TRX] Futa addon\trx.nif)", "penis",
                R"(textures\BodyChangeNG\Cache\futanari\1234\schlong.dds)") ==
                bcn::futanari::AddonKind::trx &&
            bcn::futanari::ClassifyEvidence({}, "CBBE_Shlong", {}) ==
                bcn::futanari::AddonKind::trx &&
            bcn::futanari::ClassifyEvidence({}, "CBBE_Schlong",
                R"(textures\BodyChangeNG\Cache\futanari\1234\schlong.dds)") ==
                bcn::futanari::AddonKind::trx &&
            bcn::futanari::ClassifyEvidence(
                R"(meshes\ERF_Futanari\futanari_1.nif)", {}, {}) ==
                bcn::futanari::AddonKind::erf &&
            bcn::futanari::ClassifyEvidence({}, "CBBE Schlong", {}) ==
                bcn::futanari::AddonKind::erf &&
            bcn::futanari::ClassifyEvidence({}, "FemaleBody", {}) ==
                bcn::futanari::AddonKind::none,
            "futanari geometry evidence confused normal body nodes, addon families, or slot ownership")) return 1;

    const auto maleSkin = std::ranges::find(skins, "Male Partial", &bcn::SkinProfile::name);
    const auto himboFamily = bcn::body_family::Bit(bcn::body_family::Family::himbo);
    const auto samFamily = bcn::body_family::Bit(bcn::body_family::Family::sam);
    if (!Require(maleSkin != skins.end() &&
            maleSkin->layout == bcn::SkinLayout::legacy &&
            bcn::SkinLayoutMatchesActor(maleSkin->layout, himboFamily) &&
            bcn::SkinLayoutMatchesActor(maleSkin->layout, samFamily) &&
            maleSkin->maleGenitals.size() == 3U,
            "a conventional male skin was not classified as Legacy")) return 1;
    const auto himboSkin = std::ranges::find(skins, "HIMBO Skin SOS", &bcn::SkinProfile::name);
    const auto samSkin = std::ranges::find(skins, "SAM Skin SOS", &bcn::SkinProfile::name);
    if (!Require(himboSkin != skins.end() && samSkin != skins.end() &&
            bcn::SkinLayoutMatchesActor(himboSkin->layout, himboFamily) &&
            bcn::SkinLayoutMatchesActor(himboSkin->layout, samFamily) &&
            bcn::SkinLayoutMatchesActor(samSkin->layout, samFamily) &&
            bcn::SkinLayoutMatchesActor(samSkin->layout, himboFamily),
            "conventional HIMBO and SAM packs were not normalized to Legacy")) return 1;
    if (!Require(bcn::skin_geometry::IsCBBEGenitalAnal("3BA_Vagina") &&
            bcn::skin_geometry::IsCBBEGenitalAnal("3bbb_vagina") &&
            bcn::skin_geometry::IsCBBEGenitalAnal("3BA_Anus") &&
            bcn::skin_geometry::IsCBBEGenitalAnal("3bbb_anus") &&
            bcn::skin_geometry::IsUNPGenitalAnal("BaseShapeVagina") &&
            bcn::skin_geometry::IsUNPGenitalAnal("BaseShapeAnus") &&
            bcn::skin_geometry::IsUNPGenitalAnal("BaseShapeCanal") &&
            bcn::skin_geometry::Matches("3BA", bcn::skin_geometry::BodySelection::regular) &&
            bcn::skin_geometry::Matches("MaleBody", bcn::skin_geometry::BodySelection::regular,
                R"(textures\actors\character\male\malebody_1.dds)") &&
            bcn::skin_geometry::Matches("BaseShape", bcn::skin_geometry::BodySelection::regular,
                R"(textures\!UBE\Body\femalebody_1_d.dds)") &&
            !bcn::skin_geometry::Matches("CBBE_Schlong", bcn::skin_geometry::BodySelection::regular) &&
            !bcn::skin_geometry::Matches("CBBE_Shlong", bcn::skin_geometry::BodySelection::regular) &&
            !bcn::skin_geometry::Matches("CBBE Schlong", bcn::skin_geometry::BodySelection::regular) &&
            !bcn::skin_geometry::Matches("Penis", bcn::skin_geometry::BodySelection::regular) &&
            !bcn::skin_geometry::Matches("3BA_Vagina", bcn::skin_geometry::BodySelection::regular) &&
            !bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::regular) &&
            !bcn::skin_geometry::Matches("BaseShapeCanal", bcn::skin_geometry::BodySelection::regular) &&
            bcn::skin_geometry::Matches("3BA_Vagina", bcn::skin_geometry::BodySelection::cbbeGenitalAnal) &&
            bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::cbbeGenitalAnal) &&
            !bcn::skin_geometry::Matches("BaseShapeAnus", bcn::skin_geometry::BodySelection::cbbeGenitalAnal) &&
            bcn::skin_geometry::Matches("BaseShapeVagina", bcn::skin_geometry::BodySelection::unpGenitalAnal) &&
            bcn::skin_geometry::Matches("BaseShapeAnus", bcn::skin_geometry::BodySelection::unpGenitalAnal) &&
            bcn::skin_geometry::Matches("BaseShapeCanal", bcn::skin_geometry::BodySelection::unpGenitalAnal) &&
            !bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::unpGenitalAnal) &&
            !bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::cbbeGenitalAnal,
                R"(textures\dw\ubeanus\malebody_1.dds)") &&
            !bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::regular,
                R"(textures\dw\ubeanus\malebody_1.dds)") &&
            bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::cbbeGenitalAnal,
                R"(textures\BodyChangeNG\Cache\skin\1234\femalebody_etc_v2_1.dds)") &&
            bcn::skin_geometry::Matches("RenamedShape", bcn::skin_geometry::BodySelection::cbbeGenitalAnal,
                R"(textures\actors\character\female\femalebody_etc_v2_1.dds)") &&
            bcn::skin_geometry::Matches("BaseShapeAnus", bcn::skin_geometry::BodySelection::cbbeGenitalAnal,
                R"(textures\actors\character\female\femalebody_etc_v2_1.dds)") &&
            !bcn::skin_geometry::Matches("BaseShapeAnus", bcn::skin_geometry::BodySelection::unpGenitalAnal,
                R"(textures\actors\character\female\femalebody_etc_v2_1.dds)") &&
            bcn::skin_geometry::Matches("RenamedShape", bcn::skin_geometry::BodySelection::unpGenitalAnal,
                R"(textures\actors\character\female\BakaUNP\VaginalAnalCanal2.dds)") &&
            bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::unpGenitalAnal,
                R"(textures\actors\character\female\BakaUNP\VaginalAnalCanal2.dds)") &&
            !bcn::skin_geometry::Matches("3BA_Anus", bcn::skin_geometry::BodySelection::cbbeGenitalAnal,
                R"(textures\actors\character\female\BakaUNP\VaginalAnalCanal2.dds)") &&
            bcn::skin_geometry::Matches("RenamedShape", bcn::skin_geometry::BodySelection::unpGenitalAnal,
                "textures/actors/character/female/BakaUNP/VaginalAnalCanal2.dds") &&
            bcn::skin_geometry::Matches("MaleGenitals", bcn::skin_geometry::BodySelection::maleGenitals) &&
            bcn::skin_geometry::Matches("CBBE_Schlong", bcn::skin_geometry::BodySelection::maleGenitals) &&
            bcn::skin_geometry::Matches("Penis", bcn::skin_geometry::BodySelection::maleGenitals) &&
            bcn::skin_geometry::Matches("RenamedShape", bcn::skin_geometry::BodySelection::maleGenitals,
                R"(textures\actors\character\SOS\VectorPlexus Regular\malegenitals_1.dds)") &&
            !bcn::skin_geometry::Matches("MaleBody", bcn::skin_geometry::BodySelection::maleGenitals,
                R"(textures\actors\character\male\malebody_1.dds)"),
            "CBBE 3BA and BHUNP/UNP genital/anal geometry routing crossed body or family boundaries")) return 1;
    if (!Require(bcn::skin_geometry::NeedsStandardBodyFallback(true, 0U) &&
            !bcn::skin_geometry::NeedsStandardBodyFallback(true, 1U) &&
            !bcn::skin_geometry::NeedsStandardBodyFallback(false, 0U),
            "UBE body routing did not fall back only when its slot-53 target was absent")) return 1;
    if (!Require(
            bcn::skin_geometry::IsBodyGeometryCandidate("3BA",
                R"(textures\actors\character\female\femalebody_1.dds)") &&
            bcn::skin_geometry::IsBodyGeometryCandidate("BaseShape",
                R"(textures\!UBE\Body\femalebody_1_d.dds)") &&
            bcn::skin_geometry::IsBodyGeometryCandidate("MaleBody",
                R"(textures\actors\character\male\malebody_1.dds)") &&
            !bcn::skin_geometry::IsBodyGeometryCandidate("FemaleHands",
                R"(textures\actors\character\female\femalehands_1.dds)") &&
            !bcn::skin_geometry::IsBodyGeometryCandidate("FemaleHead",
                R"(textures\actors\character\female\femalehead.dds)") &&
            !bcn::skin_geometry::IsBodyGeometryCandidate("3BA_Vagina",
                R"(textures\actors\character\female\femalebody_etc_v2_1.dds)") &&
            !bcn::skin_geometry::IsBodyGeometryCandidate("CBBE_Schlong",
                R"(textures\BodyChangeNG\Cache\futanari\1234\schlong.dds)") &&
            !bcn::skin_geometry::IsBodyGeometryCandidate("Penis",
                R"(textures\BodyChangeNG\Cache\futanari\1234\malebody_1_d.dds)"),
            "cross-slot outfit body routing accepted a non-body skin atlas")) return 1;
    if (!Require(
            bcn::skin_geometry::MatchesLimb(bcn::skin_geometry::LimbSelection::hands,
                "FemaleHands", R"(textures\actors\character\female\femalehands_1.dds)") &&
            !bcn::skin_geometry::MatchesLimb(bcn::skin_geometry::LimbSelection::hands,
                "FemaleBody", R"(textures\actors\character\female\femalebody_1.dds)") &&
            bcn::skin_geometry::MatchesLimb(bcn::skin_geometry::LimbSelection::feet,
                "FemaleFoot", R"(textures\actors\character\female\femalefeet_1.dds)") &&
            !bcn::skin_geometry::MatchesLimb(bcn::skin_geometry::LimbSelection::feet,
                "FemaleHands", R"(textures\actors\character\female\femalehands_1.dds)"),
            "body, hands, and feet fallback routing crossed texture-part boundaries")) return 1;
    constexpr std::uint32_t bodyMask = 1U << 2U;
    constexpr std::uint32_t handsMask = 1U << 3U;
    constexpr std::uint32_t feetMask = 1U << 4U;
    if (!Require(
            bcn::skin_geometry::MatchesRequestedPart(bodyMask, bodyMask, handsMask, feetMask,
                "FemaleBody", R"(textures\actors\character\female\femalebody_1.dds)") &&
            !bcn::skin_geometry::MatchesRequestedPart(bodyMask, bodyMask, handsMask, feetMask,
                "FemaleHands", R"(textures\actors\character\female\femalehands_1.dds)") &&
            bcn::skin_geometry::MatchesRequestedPart(handsMask, bodyMask, handsMask, feetMask,
                "FemaleHands", R"(textures\actors\character\female\femalehands_1.dds)") &&
            !bcn::skin_geometry::MatchesRequestedPart(handsMask, bodyMask, handsMask, feetMask,
                "FemaleFeet", R"(textures\actors\character\female\femalefeet_1.dds)") &&
            bcn::skin_geometry::MatchesRequestedPart(feetMask, bodyMask, handsMask, feetMask,
                "FemaleFeet", R"(textures\actors\character\female\femalefeet_1.dds)") &&
            !bcn::skin_geometry::MatchesRequestedPart(feetMask, bodyMask, handsMask, feetMask,
                "FemaleBody", R"(textures\actors\character\female\femalebody_1.dds)"),
            "a multi-slot naked Skin Armor routed body, hands, or feet into the wrong part")) return 1;
    if (!Require(
            bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                handsMask, handsMask, feetMask, "Hands") &&
            !bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                feetMask, handsMask, feetMask, "Hands") &&
            bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                feetMask, handsMask, feetMask, "Feet") &&
            !bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                handsMask, handsMask, feetMask, "Feet") &&
            !bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                handsMask, handsMask, feetMask, "glove") &&
            !bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                feetMask, handsMask, feetMask, "boota") &&
            !bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                feetMask, handsMask, feetMask, "stock") &&
            !bcn::skin_geometry::MatchesExplicitRequestedLimbNode(
                handsMask, handsMask, feetMask, "BaseShape"),
            "shared-atlas limbs accepted an outfit or wrong-part node")) return 1;
    if (!Require(
            !bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                handsMask, handsMask, feetMask, "FemaleHands", {}, false) &&
            bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                handsMask, handsMask, feetMask, "RenamedSkin",
                R"(textures\actors\character\female\femalehands_1.dds)", true) &&
            !bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                feetMask, handsMask, feetMask, "FemaleFeet", {}, false) &&
            bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                feetMask, handsMask, feetMask, "RenamedSkin",
                R"(textures\actors\character\female\femalefeet_1.dds)", true) &&
            !bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                handsMask, handsMask, feetMask, "Glove",
                R"(textures\armor\outfit\glove.dds)", false) &&
            !bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                feetMask, handsMask, feetMask, "Boot",
                R"(textures\armor\outfit\boot.dds)", false) &&
            !bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                handsMask, handsMask, feetMask, "FemaleBody",
                R"(textures\actors\character\female\femalebody_1.dds)", true) &&
            !bcn::skin_geometry::IsSafeCrossSlotLimbCandidate(
                feetMask, handsMask, feetMask, "FemaleHands",
                R"(textures\actors\character\female\femalehands_1.dds)", true),
            "cross-slot limb routing accepted a non-skin, outfit, body, or wrong-limb material")) return 1;
    if (!Require(
            bcn::ResolveFeetLayerSource(bcn::SkinLayout::legacy,
                bcn::SkinRace::humanoid, 4U, 0U) == bcn::FeetLayerSource::bodyAtlas &&
            bcn::ResolveFeetLayerSource(bcn::SkinLayout::legacy,
                bcn::SkinRace::humanoid, 4U, 1U) == bcn::FeetLayerSource::explicitFeet &&
            bcn::ResolveFeetLayerSource(bcn::SkinLayout::argonian,
                bcn::SkinRace::argonian, 4U, 0U) == bcn::FeetLayerSource::none,
            "feet layer planning crossed an explicit or beast-race atlas boundary")) return 1;
    struct FakeNifGeometry final
    {
        std::string_view node;
        std::string_view diffuse;
    };
    constexpr std::array fakeMultiSlotNif{
        FakeNifGeometry{ "3BA", R"(textures\actors\character\female\femalebody_1.dds)" },
        FakeNifGeometry{ "FemaleHands", R"(textures\actors\character\female\femalehands_1.dds)" },
        FakeNifGeometry{ "FemaleFeet", R"(textures\actors\character\female\femalefeet_1.dds)" },
        FakeNifGeometry{ "3BA_Vagina", R"(textures\actors\character\female\femalebody_etc_v2_1.dds)" }
    };
    const auto fakeNifPartCount = [&](const std::uint32_t requestedMask) {
        return std::ranges::count_if(fakeMultiSlotNif, [&](const FakeNifGeometry& geometry) {
            return bcn::skin_geometry::MatchesRequestedPart(
                requestedMask, bodyMask, handsMask, feetMask, geometry.node, geometry.diffuse);
        });
    };
    if (!Require(fakeNifPartCount(bodyMask) == 2U &&
            fakeNifPartCount(handsMask) == 1U && fakeNifPartCount(feetMask) == 1U,
            "fake multi-slot NIF did not isolate body/genital, hands, and feet node sets")) return 1;
    const auto standardFamily = bcn::body_family::Bit(bcn::body_family::Family::cbbe);
    const auto unpFamily = bcn::body_family::Bit(bcn::body_family::Family::unp);
    const auto ubeFamily = bcn::body_family::Bit(bcn::body_family::Family::ube);
    if (!Require(bcn::FutanariSkinTypeMatchesActor(
            bcn::FutanariSkinType::ubeTrx, ubeFamily) &&
            bcn::FutanariSkinTypeMatchesActor(bcn::FutanariSkinType::ubeTrxAddon, ubeFamily) &&
            !bcn::FutanariSkinTypeMatchesActor(bcn::FutanariSkinType::ubeTrxAddon, standardFamily) &&
            !bcn::FutanariSkinTypeMatchesActor(
                bcn::FutanariSkinType::cbbeTrx, ubeFamily) &&
            bcn::FutanariSkinTypeMatchesActor(
                bcn::FutanariSkinType::cbbeTrx, standardFamily) &&
            bcn::FutanariSkinTypeMatchesActor(
                bcn::FutanariSkinType::erf, standardFamily) &&
            !bcn::FutanariSkinTypeMatchesActor(
                bcn::FutanariSkinType::ubeTrx, standardFamily),
            "futanari catalog mixed UBE and Legacy actor layouts")) return 1;
    const auto ubeSkin = std::ranges::find(skins, "UBE 2.0 Momo Skin", &bcn::SkinProfile::name);
    const auto standardSkin = std::ranges::find(skins, skinPackName, &bcn::SkinProfile::name);
    const auto unpSkin = std::ranges::find(skins, unpSkinPackName, &bcn::SkinProfile::name);
    if (!Require(ubeSkin != skins.end() && standardSkin != skins.end() && unpSkin != skins.end(),
            "expected skin rows are missing")) return 1;
    if (!Require(bcn::SkinLayoutMatchesActor(ubeSkin->layout, ubeFamily) &&
            !bcn::SkinLayoutMatchesActor(ubeSkin->layout, standardFamily),
            "UBE skin compatibility leaked into CBBE")) return 1;
    if (!Require(bcn::SkinLayoutMatchesActor(standardSkin->layout, standardFamily) &&
            bcn::SkinLayoutMatchesActor(standardSkin->layout, unpFamily) &&
            !bcn::SkinLayoutMatchesActor(standardSkin->layout, ubeFamily),
            "Legacy skin was not shared by CBBE/UNP or leaked into UBE")) return 1;
    if (!Require(bcn::SkinLayoutMatchesActor(unpSkin->layout, unpFamily) &&
            bcn::SkinLayoutMatchesActor(unpSkin->layout, standardFamily) &&
            !bcn::SkinLayoutMatchesActor(unpSkin->layout, ubeFamily),
            "Legacy UNP-labelled skin was not shared by CBBE/UNP or leaked into UBE")) return 1;
    if (!Require(bcn::SkinRaceMatchesActor(bcn::SkinRace::argonian, bcn::SkinRace::argonian) &&
            !bcn::SkinRaceMatchesActor(bcn::SkinRace::argonian, bcn::SkinRace::khajiit) &&
            !bcn::SkinRaceMatchesActor(bcn::SkinRace::khajiit, bcn::SkinRace::humanoid),
            "beast-race skin compatibility leaked across races")) return 1;
    if (!Require(bcn::SkinRaceFromEditorID("ArgonianRaceVampire") == bcn::SkinRace::argonian &&
            bcn::SkinRaceFromEditorID("KhajiitRace") == bcn::SkinRace::khajiit &&
            bcn::SkinRaceFromEditorID("NordRace") == bcn::SkinRace::humanoid,
            "actor race EditorID classification did not preserve beast and humanoid boundaries")) return 1;
    if (!Require(
            bcn::HumanoidSkinRaceFromEditorID("NordRace") == bcn::HumanoidSkinRace::nord &&
            bcn::HumanoidSkinRaceFromEditorID("BretonRace") == bcn::HumanoidSkinRace::breton &&
            bcn::HumanoidSkinRaceFromEditorID("DarkElfRaceVampire") == bcn::HumanoidSkinRace::darkElf &&
            bcn::HumanoidSkinRaceFromEditorID("HighElfRace") == bcn::HumanoidSkinRace::highElf &&
            bcn::HumanoidSkinRaceFromEditorID("ImperialRace") == bcn::HumanoidSkinRace::imperial &&
            bcn::HumanoidSkinRaceFromEditorID("OrcRace") == bcn::HumanoidSkinRace::orc &&
            bcn::HumanoidSkinRaceFromEditorID("RedguardRace") == bcn::HumanoidSkinRace::redguard &&
            bcn::HumanoidSkinRaceFromEditorID("WoodElfRace") == bcn::HumanoidSkinRace::woodElf,
            "humanoid race EditorID classification did not select the matching face variant")) return 1;
    if (!Require(bcn::IsElderSkinVariant("ElderRace", "FemaleEvenToned") &&
            bcn::IsElderSkinVariant("NordRace", "FemaleOldGrumpy") &&
            !bcn::IsElderSkinVariant("NordRace", "FemaleEvenToned"),
            "elder race/voice classification did not preserve the distribution condition semantics")) return 1;

    const std::string tintPackName{ "틴트包" };
    const auto tintA = sandbox / "BodySkin" / std::filesystem::path{ L"틴트包" } / "textures" / "actors" / "character" /
        "character assets" / "tintmasks";
    Touch(tintA / "femalehead_lips.DDS");
    Touch(tintA / "femaleheadhuman_nose.dds");
    Touch(tintA / "not-a-tint.dds");
    const auto tintB = sandbox / "BodySkin" / "Pack B" / "textures" / "actors" / "character" /
        "character assets" / "tintmasks";
    Touch(tintB / "maleheadnord_lips.dds");
    const auto tintUbe = sandbox / "BodySkin" / "UBE Makeup" / "textures" / "actors" / "character" /
        "character assets" / "tintmasks";
    Touch(tintUbe / "femalehead_lips.dds");
    const auto tintCotr = sandbox / "BodySkin" / "COtR Makeup" / "textures" / "actors" / "character" /
        "character assets" / "tintmasks";
    Touch(tintCotr / "femalehead_eyeliner.dds");

    const auto tints = bcn::player_tint::Catalog::ScanDirectory(sandbox / "BodySkin");
    if (!Require(tints.size() == 6U, "tint scanner did not classify the expected DDS files")) return 1;
    if (!Require(std::ranges::any_of(tints, [&](const auto& tint) { return tint.pack == tintPackName; }),
            "tint pack name was not preserved as UTF-8")) return 1;
    if (!Require(std::ranges::any_of(tints, [&](const auto& tint) {
            return tint.pack == skinPackName && tint.name == "femalehead_lips";
        }), "a tint mask embedded in an ordinary BodySkin pack was not discovered")) return 1;
    for (const auto& tint : tints) {
        if (!Require(tint.path.starts_with("BodySkinTint\\"), "tint source key escaped its isolated cache namespace")) return 1;
        if (!Require(!tint.id.starts_with(".."), "tint id contains a parent-directory escape")) return 1;
    }
    const auto ubeTint = std::ranges::find(tints, "UBE Makeup", &bcn::player_tint::Asset::pack);
    const auto cotrTint = std::ranges::find(tints, "COtR Makeup", &bcn::player_tint::Asset::pack);
    const auto maleTint = std::ranges::find(tints, "Pack B", &bcn::player_tint::Asset::pack);
    const auto legacyTint = std::ranges::find(tints, tintPackName, &bcn::player_tint::Asset::pack);
    if (!Require(ubeTint != tints.end() &&
            ubeTint->bodyFamilies == bcn::body_family::Bit(bcn::body_family::Family::ube),
            "UBE tint pack was not isolated to UBE")) return 1;
    if (!Require(cotrTint != tints.end() &&
            bcn::player_tint::TintMatchesActor(cotrTint->bodyFamilies, standardFamily) &&
            bcn::player_tint::TintMatchesActor(cotrTint->bodyFamilies, ubeFamily),
            "COtR-compatible tint pack was not exposed to both female layouts")) return 1;
    if (!Require(maleTint != tints.end() && maleTint->sex == bcn::player_tint::Sex::male &&
            (maleTint->bodyFamilies & bcn::body_family::kMaleFamilies) != 0U,
            "male tint was not retained as a male-family asset")) return 1;
    const auto maleTintFamily = bcn::body_family::Bit(bcn::body_family::Family::himbo);
    if (!Require(legacyTint != tints.end() &&
            bcn::player_tint::TintAssetMatchesActor(legacyTint->sex,
                legacyTint->bodyFamilies, standardFamily, true) &&
            !bcn::player_tint::TintAssetMatchesActor(legacyTint->sex,
                legacyTint->bodyFamilies, ubeFamily, true) &&
            bcn::player_tint::TintAssetMatchesActor(ubeTint->sex,
                ubeTint->bodyFamilies, ubeFamily, true) &&
            !bcn::player_tint::TintAssetMatchesActor(ubeTint->sex,
                ubeTint->bodyFamilies, standardFamily, true) &&
            bcn::player_tint::TintAssetMatchesActor(maleTint->sex,
                maleTint->bodyFamilies, maleTintFamily, false) &&
            !bcn::player_tint::TintAssetMatchesActor(maleTint->sex,
                maleTint->bodyFamilies, standardFamily, true),
            "tint catalog filtering mixed actor sex or UBE/Legacy layouts")) return 1;

    const auto slaveTats = sandbox / "SlaveTats";
    WriteText(slaveTats / "General.json", R"json([
        {"name":"Face A","section":"General","texture":"Pack\\face.dds","area":"Face"},
        {"name":"Body A","section":"General","texture":"Pack\\body.dds","area":"Body"},
        {"name":"Hands A","section":"General","texture":"Pack\\hands.dds","area":"Hands"},
        {"name":"Feet A","section":"General","texture":"Pack\\feet.dds","area":"Feet"},
        {"name":"Escape","section":"General","texture":"..\\bad.dds","area":"Body"},
        {"name":"Wrong","section":"General","texture":"Pack\\wrong.dds","area":"Tail"}
    ])json");
    WriteText(slaveTats / "UBE Pack.json", R"json([
        {"name":"Tears","section":"UBE Tears","texture":"Tears\\tears.dds","area":"Face"}
    ])json");
    const auto tattoos = bcn::overlay::ScanSlaveTatsDirectory(slaveTats);
    if (!Require(tattoos.size() == 5U &&
            std::ranges::count(tattoos, bcn::overlay::Area::face,
                &bcn::overlay::Entry::area) == 2U &&
            std::ranges::count(tattoos, bcn::overlay::Area::body,
                &bcn::overlay::Entry::area) == 1U &&
            std::ranges::count(tattoos, bcn::overlay::Area::hands,
                &bcn::overlay::Entry::area) == 1U &&
            std::ranges::count(tattoos, bcn::overlay::Area::feet,
                &bcn::overlay::Entry::area) == 1U,
            "SlaveTats JSON rows were not separated into face/body/hands/feet")) return 1;
    const auto ubeTattoo = std::ranges::find(tattoos, bcn::overlay::Layout::ube,
        &bcn::overlay::Entry::layout);
    if (!Require(ubeTattoo != tattoos.end() &&
            ubeTattoo->sex == bcn::overlay::Sex::female &&
            ubeTattoo->texturePath ==
                R"(textures\actors\character\slavetats\Tears\tears.dds)",
            "SlaveTats UBE metadata or texture path classification failed")) return 1;
    if (!Require(std::ranges::all_of(tattoos, [](const auto& tattoo) {
            return tattoo.source == bcn::overlay::Source::slaveTats &&
                !tattoo.id.empty() && tattoo.name.starts_with("SlaveTats · ");
        }), "SlaveTats rows lost their source or stable identity")) return 1;
    // Content refresh must distinguish equal-size DDS replacements even if
    // an archive extraction preserves timestamps. Cache aliases must differ.
    const auto refreshSource = sandbox / "refresh.dds";
    std::ofstream(refreshSource, std::ios::binary) << "abc";
    const auto sourceTime = std::filesystem::last_write_time(refreshSource);
    const auto refreshKey = "BodySkin\\Refresh\\body.dds";
    bcn::runtime_assets::ClearGameRelativeSources("BodySkin\\");
    bcn::runtime_assets::RegisterGameRelativeSource(refreshKey, refreshSource);
    const auto beforeHash = bcn::runtime_assets::SourceContentHash(refreshKey);
    std::filesystem::current_path(sandbox);
    const auto beforePath = bcn::runtime_assets::TexturePathFromGameRelative(refreshKey, "test");
    std::ofstream(refreshSource, std::ios::binary) << "xyz";
    std::filesystem::last_write_time(refreshSource, sourceTime);
    bcn::runtime_assets::ClearGameRelativeSources("BodySkin\\");
    bcn::runtime_assets::RegisterGameRelativeSource(refreshKey, refreshSource);
    const auto afterHash = bcn::runtime_assets::SourceContentHash(refreshKey);
    const auto afterPath = bcn::runtime_assets::TexturePathFromGameRelative(refreshKey, "test");
    const auto expectedAfterPath =
        bcn::runtime_assets::ExpectedTexturePathFromGameRelative(refreshKey, "test");
    if (!Require(expectedAfterPath == afterPath &&
            bcn::runtime_assets::CachedTextureExists(afterPath),
            "exact runtime texture cache alias was not discoverable")) return 1;

    // A user may clean MO2 overwrite while the RaceMenu co-save still points
    // at a BCNG alias. Detection must be metadata-only, and the next normal
    // materialization must recreate the same stable path from the source.
    std::filesystem::remove(sandbox / "Data" / std::filesystem::path{ afterPath });
    bcn::runtime_assets::ClearGameRelativeSources("BodySkin\\");
    bcn::runtime_assets::RegisterGameRelativeSource(refreshKey, refreshSource);
    if (!Require(!bcn::runtime_assets::CachedTextureExists(afterPath),
            "deleted runtime texture cache alias was accepted as live")) return 1;
    const auto repairedPath = bcn::runtime_assets::TexturePathFromGameRelative(refreshKey, "test");
    if (!Require(repairedPath == afterPath &&
            bcn::runtime_assets::CachedTextureExists(repairedPath),
            "deleted runtime texture cache alias was not repaired from its source")) return 1;
    // Also repair without a catalog refresh: the old positive-cache entry is
    // still present in this case. Native callbacks retain their O(1) lookup.
    std::filesystem::remove(sandbox / "Data" / std::filesystem::path{ repairedPath });
    const auto repairedWithoutRefresh = bcn::runtime_assets::TexturePathFromGameRelative(refreshKey, "test");
    if (!Require(repairedWithoutRefresh == repairedPath &&
            std::filesystem::is_regular_file(sandbox / "Data" / std::filesystem::path{ repairedPath }),
            "preparation trusted an obsolete cached-positive after file deletion")) return 1;

    // Mu Dynamic NormalMap derives optional detail, mask, and overlay files
    // from the active normal-map basename. A private cache directory prevents
    // collisions, but the basename and installed companions must survive.
    const auto normalDirectory = sandbox / "mu-normal";
    std::filesystem::create_directories(normalDirectory);
    const auto normalSource = normalDirectory / "femalebody_1_msn.dds";
    const auto detailSource = normalDirectory / "femalebody_1_n.dds";
    const auto maskSource = normalDirectory / "femalebody_1_n_m.dds";
    const auto overlaySource = normalDirectory / "femalebody_1_n_ov.dds";
    std::ofstream(normalSource, std::ios::binary) << "normal";
    std::ofstream(detailSource, std::ios::binary) << "detail";
    std::ofstream(maskSource, std::ios::binary) << "mask-a";
    std::ofstream(overlaySource, std::ios::binary) << "overlay";
    constexpr std::string_view normalKey =
        "BodySkin\\Mu\\Textures\\actors\\character\\female\\femalebody_1_msn.dds";
    bcn::runtime_assets::ClearGameRelativeSources("BodySkin\\");
    bcn::runtime_assets::RegisterGameRelativeSource(normalKey, normalSource);
    const auto normalHash = bcn::runtime_assets::SourceContentHash(normalKey);
    const auto cachedNormal = bcn::runtime_assets::TexturePathFromGameRelative(normalKey, "skin");
    const auto cachedDirectory = sandbox / "Data" /
        std::filesystem::path{ cachedNormal }.parent_path();
    if (!Require(Filename(cachedNormal) == "femalebody_1_msn.dds" &&
            std::filesystem::is_regular_file(cachedDirectory / "femalebody_1_n.dds") &&
            std::filesystem::is_regular_file(cachedDirectory / "femalebody_1_n_m.dds") &&
            std::filesystem::is_regular_file(cachedDirectory / "femalebody_1_n_ov.dds"),
            "Mu normal-map basename or optional sibling bundle was lost in the runtime cache")) return 1;
    const auto maskTime = std::filesystem::last_write_time(maskSource);
    std::ofstream(maskSource, std::ios::binary) << "mask-b";
    std::filesystem::last_write_time(maskSource, maskTime);
    bcn::runtime_assets::ClearGameRelativeSources("BodySkin\\");
    bcn::runtime_assets::RegisterGameRelativeSource(normalKey, normalSource);
    const auto changedNormalHash = bcn::runtime_assets::SourceContentHash(normalKey);
    const auto changedCachedNormal =
        bcn::runtime_assets::TexturePathFromGameRelative(normalKey, "skin");
    if (!Require(changedNormalHash != normalHash && changedCachedNormal != cachedNormal &&
            Filename(changedCachedNormal) == "femalebody_1_msn.dds",
            "a same-size/timestamp Mu mask replacement did not invalidate the normal bundle")) return 1;

    // TRX wet integrations derive a sibling wet specular from the active
    // Schlong_s location. It must follow the selected profile into the same
    // private cache without replacing the normal slot-7 texture.
    constexpr std::string_view trxSpecularKey =
        "Futanari\\CBBE TRX\\textures\\[TRX] Futa addon\\Regular\\Default\\schlong_s.dds";
    bcn::runtime_assets::ClearGameRelativeSources("Futanari\\");
    bcn::runtime_assets::RegisterGameRelativeSource(trxSpecularKey, futaTrx / "schlong_s.dds");
    const auto cachedTrxSpecular =
        bcn::runtime_assets::TexturePathFromGameRelative(trxSpecularKey, "futanari");
    const auto cachedTrxDirectory = sandbox / "Data" /
        std::filesystem::path{ cachedTrxSpecular }.parent_path();
    if (!Require(Filename(cachedTrxSpecular) == "schlong_s.dds" &&
            std::filesystem::is_regular_file(cachedTrxDirectory / "wetschlong_110_s.dds"),
            "TRX wet specular did not follow the selected futanari skin into the runtime cache")) return 1;

    // CS resolves RFAOS/wet beside the active normal map. Preserve the global
    // MO2-winning defaults, never the similarly named selected-pack files.
    const auto ubeDefaults = sandbox / "Data" / "textures" / "!UBE";
    const auto defaultBodyRfaos = ubeDefaults / "Body" / "femalebody_1_rFaOs.DDS";
    const auto defaultHeadRfaos = ubeDefaults / "Head" / "femalehead_RFAOS.dds";
    WriteText(defaultBodyRfaos, "default-body-a");
    WriteText(defaultHeadRfaos, "default-head-a");
    WriteText(ubeDefaults / "femalebody_1_wet.dds", "default-body-wet");
    WriteText(ubeDefaults / "femalehead_wet.dds", "default-head-wet");
    constexpr std::string_view ubeBodyKey =
        "bOdYsKiN/UBE 2.0 Momo Skin/tExTuReS/!uBe/bOdY/FEMALEBODY_1_N.DDS";
    constexpr std::string_view ubeHeadKey =
        "BodySkin\\UBE 2.0 Momo Skin\\Textures\\!UBE\\Head\\femalehead_n.dds";
    const auto prepareUbe = [&] {
        bcn::runtime_assets::ClearGameRelativeSources("BodySkin\\");
        bcn::runtime_assets::RegisterGameRelativeSource(ubeBodyKey, ubeBody / "femalebody_1_n.dds");
        bcn::runtime_assets::RegisterGameRelativeSource(ubeHeadKey, ubeHead / "femalehead_n.dds");
    };
    prepareUbe();
    const auto cachedUbeBody = bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin");
    const auto cachedUbeHead = bcn::runtime_assets::TexturePathFromGameRelative(ubeHeadKey, "skin");
    const auto ubeBodyCache = (sandbox / "Data" / cachedUbeBody).parent_path();
    const auto ubeHeadCache = (sandbox / "Data" / cachedUbeHead).parent_path();
    if (!Require(!cachedUbeBody.empty() && !cachedUbeHead.empty() &&
            TextEquals(ubeBodyCache / "femalebody_1_rfaos.dds", "default-body-a") &&
            !std::filesystem::exists(ubeBodyCache / "femalebody_1_wet.dds") &&
            TextEquals(ubeHeadCache / "femalehead_rfaos.dds", "default-head-a") &&
            !std::filesystem::exists(ubeHeadCache / "femalehead_wet.dds") &&
            !std::filesystem::exists(ubeBodyCache / "femalebody_1_s.dds") &&
            TextEquals(ubeBody / "femalebody_1_RFAOS.dds", "pack-body-effect"),
            "UBE effect aliases activated parent-folder wet maps or borrowed pack effects")) return 1;
    // The parent-folder files are not part of CS's original normal-derived
    // lookup. Even edits to them must not change the selected skin alias.
    WriteText(ubeDefaults / "femalebody_1_wet.dds", "changed-root-wet");
    WriteText(ubeDefaults / "femalehead_wet.dds", "changed-root-head-wet");
    prepareUbe();
    if (!Require(bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin") == cachedUbeBody &&
            bcn::runtime_assets::TexturePathFromGameRelative(ubeHeadKey, "skin") == cachedUbeHead,
            "out-of-lookup root wet maps changed the normal cache signature")) return 1;
    // A pack's effect changes cannot select new effects; installed default
    // content changes must invalidate the normal bundle, even at equal stamps.
    WriteText(ubeBody / "femalebody_1_RFAOS.dds", "different-pack-effect");
    prepareUbe();
    if (!Require(bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin") == cachedUbeBody,
            "selected-pack RFAOS affected the installed-default alias")) return 1;
    const auto bodyRfaosTime = std::filesystem::last_write_time(defaultBodyRfaos);
    WriteText(defaultBodyRfaos, "default-body-b");
    std::filesystem::last_write_time(defaultBodyRfaos, bodyRfaosTime);
    prepareUbe();
    const auto changedUbeBody = bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin");
    const auto changedUbeDirectory = (sandbox / "Data" / changedUbeBody).parent_path();
    if (!Require(changedUbeBody != cachedUbeBody &&
            TextEquals(changedUbeDirectory / "femalebody_1_rfaos.dds", "default-body-b") &&
            TextEquals(defaultHeadRfaos, "default-head-a"),
            "installed UBE effect content refresh retained stale lookup paths")) return 1;
    // A wet map actually installed beside the default normal remains supported.
    // Switching between absent/present effects must not mutate old aliases.
    const auto defaultBodyWet = ubeDefaults / "Body" / "femalebody_1_wet.dds";
    WriteText(defaultBodyWet, "body-specific-wet");
    prepareUbe();
    const auto wetUbeBody = bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin");
    const auto wetUbeDirectory = (sandbox / "Data" / wetUbeBody).parent_path();
    if (!Require(!wetUbeBody.empty() && wetUbeBody != changedUbeBody &&
            TextEquals(wetUbeDirectory / "femalebody_1_wet.dds", "body-specific-wet") &&
            !std::filesystem::exists(changedUbeDirectory / "femalebody_1_wet.dds"),
            "in-lookup UBE wet map did not receive an isolated alias")) return 1;
    std::filesystem::remove(wetUbeDirectory / "femalebody_1_wet.dds");
    if (!Require(bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin") == wetUbeBody &&
            TextEquals(wetUbeDirectory / "femalebody_1_wet.dds", "body-specific-wet"),
            "missing UBE effect alias was not repaired without refresh")) return 1;
    // A normal success must not be reported if a known installed companion
    // could not be published. Only a synthetic empty directory is removed.
    std::filesystem::remove(wetUbeDirectory / "femalebody_1_wet.dds");
    std::filesystem::create_directory(wetUbeDirectory / "femalebody_1_wet.dds");
    if (!Require(bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin").empty(),
            "UBE preparation accepted a failed required effect publication")) return 1;
    std::filesystem::remove(wetUbeDirectory / "femalebody_1_wet.dds");
    if (!Require(bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin") == wetUbeBody,
            "UBE preparation could not recover after publication failure")) return 1;
    WriteText(ubeDefaults / "Head" / "femalehead_wet.dds", "head-specific-wet");
    prepareUbe();
    const auto exactHeadPath = bcn::runtime_assets::TexturePathFromGameRelative(ubeHeadKey, "skin");
    if (!Require(exactHeadPath != cachedUbeHead && TextEquals((sandbox / "Data" / exactHeadPath).parent_path() /
            "femalehead_wet.dds", "head-specific-wet"),
            "UBE head wet map at the original lookup location was not preserved")) return 1;
    std::filesystem::remove(defaultBodyWet);
    prepareUbe();
    if (!Require(bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin") == changedUbeBody &&
            !std::filesystem::exists(changedUbeDirectory / "femalebody_1_wet.dds") &&
            TextEquals(wetUbeDirectory / "femalebody_1_wet.dds", "body-specific-wet"),
            "removing the installed wet map reused wet aliases or deleted save-referenced files")) return 1;
    std::filesystem::remove(defaultBodyRfaos);
    prepareUbe();
    const auto noDefaults = bcn::runtime_assets::TexturePathFromGameRelative(ubeBodyKey, "skin");
    const auto noDefaultsDirectory = (sandbox / "Data" / noDefaults).parent_path();
    if (!Require(!noDefaults.empty() &&
            !std::filesystem::exists(noDefaultsDirectory / "femalebody_1_rfaos.dds") &&
            !std::filesystem::exists(noDefaultsDirectory / "femalebody_1_wet.dds") &&
            !std::filesystem::exists(cachedDirectory / "femalebody_1_rfaos.dds") &&
            !std::filesystem::exists(cachedTrxDirectory / "femalebody_1_wet.dds"),
            "missing defaults borrowed pack effects or leaked into non-UBE bundles")) return 1;

    Touch(sandbox / "Data" / "textures" / "BodyChangeNG" / "outside.dds");
    if (!Require(!bcn::runtime_assets::CachedTextureExists(
            "textures\\BodyChangeNG\\Cache\\..\\outside.dds") &&
            !bcn::runtime_assets::CachedTextureExists("C:\\outside.dds"),
            "runtime texture cache existence check accepted an unsafe path")) return 1;
    std::filesystem::current_path(originalCurrentPath);
    if (!Require(beforeHash != afterHash && !beforePath.empty() && beforePath != afterPath,
            "same size/time DDS edit retained content signature or texture cache alias")) return 1;
    bcn::runtime_assets::ClearGameRelativeSources("BodySkin\\");
    bcn::runtime_assets::RegisterGameRelativeSource(refreshKey, refreshSource);
    if (!Require(afterHash == bcn::runtime_assets::SourceContentHash(refreshKey),
            "unchanged refresh invalidated content hash")) return 1;

    // MO2 may expose one backing DDS both through its provider directory and
    // through the virtual Data tree. Windows path aliases for that same file
    // must share one source identity; otherwise large packs are fully hashed
    // once per catalog root. Mutating the file between alias registrations
    // makes an accidental second hash observable without exposing test-only
    // cache internals.
    const auto extendedRefreshSource = std::filesystem::path{
        std::wstring{ LR"(\\?\)" } + refreshSource.wstring()
    };
    std::ofstream(refreshSource, std::ios::binary) << "uvw";
    bcn::runtime_assets::RegisterGameRelativeSource(refreshKey, extendedRefreshSource);
    if (!Require(afterHash == bcn::runtime_assets::SourceContentHash(refreshKey),
            "one physical DDS was rehashed through a second Windows path alias")) return 1;
    // A mixed-sex pack must retain separate conditional channels and stable
    // IDs. Sort-earlier race folders must never supply the generic normal.
    const auto variantRoot = sandbox / "ConditionalAudit" / "BodySkin";
    const auto variantCharacter = variantRoot / "Mixed" / "Textures" / "actors" / "character";
    for (const auto* sex : { "male", "female" }) {
        for (const auto* part : { "body_1", "hands_1", "head" }) {
            Touch(variantCharacter / sex / (std::string{sex} + part + ".dds"));
            Touch(variantCharacter / sex / (std::string{sex} + part + "_msn.dds"));
        }
    }
    const auto beforeVariants = bcn::SkinProfiles::ScanDirectory(variantRoot);
    const std::array maleRaceDirs{ "nordmale", "bretonmale", "darkelfmale", "highelfmale",
        "imperialmale", "orcmale", "redguardmale", "woodelfmale" };
    for (const auto* directory : maleRaceDirs) {
        Touch(variantCharacter / directory /
            (std::string_view{directory} == "orcmale" ? "maleheadorc_msn.dds" : "malehead_msn.dds"));
    }
    for (const auto* sex : { "male", "female" }) {
        for (const auto* part : { "body_1", "hands_1", "head" })
            Touch(variantCharacter / (std::string{sex} + "old") /
                (std::string{sex} + part + "_msn.dds"));
    }
    Touch(variantCharacter / "bretonfemale" / "femalehead_msn.dds");
    const auto withVariants = bcn::SkinProfiles::ScanDirectory(variantRoot);
    if (!Require(beforeVariants.size() == 2U && withVariants.size() == 2U,
            "conditional directories created standalone rows")) return 1;
    for (const auto& profile : withVariants) {
        const auto original = std::ranges::find(beforeVariants, profile.id, &bcn::SkinProfile::id);
        if (!Require(original != beforeVariants.end(), "conditional DDS changed the automatic pack ID")) return 1;
        const std::string sex = profile.sex == bcn::SkinSex::male ? "male" : "female";
        if (!Require(profile.body.size() == 2U && profile.hands.size() == 2U && profile.face.size() == 2U &&
                profile.face[1].path.ends_with("\\" + sex + "\\" + sex + "head_msn.dds") &&
                profile.elderBody.size() == 1U && profile.elderHands.size() == 1U &&
                profile.elderFace.size() == 1U &&
                profile.elderBody[0].path.ends_with("\\" + sex + "old\\" + sex + "body_1_msn.dds") &&
                profile.elderHands[0].path.ends_with("\\" + sex + "old\\" + sex + "hands_1_msn.dds") &&
                profile.elderFace[0].path.ends_with("\\" + sex + "old\\" + sex + "head_msn.dds"),
                "male/female elder DDS missing or leaked into generic/other-sex channels")) return 1;
        if (profile.sex == bcn::SkinSex::male) {
            for (const auto race : { bcn::HumanoidSkinRace::nord, bcn::HumanoidSkinRace::breton,
                     bcn::HumanoidSkinRace::darkElf, bcn::HumanoidSkinRace::highElf,
                     bcn::HumanoidSkinRace::imperial, bcn::HumanoidSkinRace::orc,
                     bcn::HumanoidSkinRace::redguard, bcn::HumanoidSkinRace::woodElf }) {
                const auto& layers = profile.raceFace[static_cast<std::size_t>(race)];
                if (!Require(layers.size() == 1U && layers[0].shaderTextureIndex == 1U &&
                        !layers[0].path.contains("female"), "male race face missing or crossed sex")) return 1;
            }
        } else if (!Require(profile.raceFace[static_cast<std::size_t>(bcn::HumanoidSkinRace::nord)].empty(),
                "male race normal leaked into female profile")) return 1;
    }
    // Arbitrary case, not just all-lower/all-upper DDS extensions; preserve
    // author spelling while accepting all four asset families.
    const auto caseRoot = sandbox / "CaseVariants";
    const auto mixedSkinRoot = caseRoot / "BoDySkIn";
    Touch(mixedSkinRoot / "Pack" / "TeXtUrEs/AcToRs/ChArAcTeR/FeMaLe/FeMaLeBoDy_1.DdS");
    Touch(mixedSkinRoot / "UbePack" / "TeXtUrEs/!uBe/BoDy/FeMaLeBoDy_1_D.DdS");
    Touch(mixedSkinRoot / "Pack" / "TeXtUrEs/AcToRs/ChArAcTeR/Character Assets/TiNtMaSkS/FeMaLeHeAd_LiPs.DdS");
    const auto mixedFutaRoot = caseRoot / "FuTaNaRi";
    Touch(mixedFutaRoot / "Pack" / "TeXtUrEs/ErF_fUtAnArI/FaIrSkInCbBe/FuTaNaRi_ScHlOnG.DdS");
    const auto mixedSkins = bcn::SkinProfiles::ScanDirectory(mixedSkinRoot);
    const auto mixedFuta = bcn::FutanariSkinProfiles::ScanDirectory(mixedFutaRoot);
    const auto mixedTints = bcn::player_tint::Catalog::ScanDirectory(mixedSkinRoot);
    if (!Require(mixedSkins.size() == 2U && mixedFuta.size() == 1U && mixedTints.size() == 1U &&
            mixedSkins.front().body.size() == 1U && mixedFuta.front().layers.size() == 1U &&
            mixedTints.front().path.ends_with("FeMaLeHeAd_LiPs.DdS"),
            "mixed-case body/UBE/futanari/tint catalog discovery failed or rewrote spelling")) return 1;

    // Publish new immutable catalogs while readers still own the previous one.
    const auto snapshotRoot = sandbox / "SnapshotAudit";
    std::filesystem::create_directories(snapshotRoot);
    std::filesystem::current_path(snapshotRoot);
    const auto snapshotSkin = bcn::SkinProfiles::RootPath() / "A" / "textures" / "actors" / "character";
    Touch(snapshotSkin / "female" / "femalebody_1.dds");
    Touch(snapshotSkin / "female" / "femalehead.dds");
    Touch(snapshotSkin / "character assets" / "tintmasks" / "femalehead_lips.dds");
    const auto snapshotFuta = bcn::FutanariSkinProfiles::RootPath() / "TRX" / "textures" /
        "[TRX] Futa addon" / "Regular" / "Default";
    Touch(snapshotFuta / "schlong.dds");
    auto& skinsCatalog = bcn::SkinProfiles::Get();
    auto& futaCatalog = bcn::FutanariSkinProfiles::Get();
    auto& tintCatalog = bcn::player_tint::Catalog::Get();
    skinsCatalog.Refresh(); futaCatalog.Refresh(); tintCatalog.Refresh();
    auto skinView = skinsCatalog.SharedSnapshot();
    auto futaView = futaCatalog.SharedSnapshot();
    auto tintView = tintCatalog.SharedSnapshot();
    if (!Require(skinsCatalog.Find(Lower(skinView->front().id)).has_value() &&
            skinsCatalog.ContentHash(Lower(skinView->front().id)) == skinView->front().contentHash &&
            futaCatalog.Find(Lower(futaView->front().id)).has_value() &&
            futaCatalog.ContentHash(Lower(futaView->front().id)) == futaView->front().contentHash &&
            tintCatalog.Find(Lower(tintView->front().id)).has_value(),
            "saved skin/futanari/tint ID casing no longer resolves the current catalog")) return 1;
    if (!Require(skinView->size() == 1U && skinView->front().textureCount == 2U &&
            futaView->size() == 1U && tintView->size() == 1U &&
            skinView == skinsCatalog.SharedSnapshot() && futaView == futaCatalog.SharedSnapshot() &&
            tintView == tintCatalog.SharedSnapshot(), "catalog read copied or lost published data")) return 1;
    std::weak_ptr oldSkin = skinView;
    std::weak_ptr oldFuta = futaView;
    std::weak_ptr oldTint = tintView;
    Touch(snapshotSkin / "female" / "femalehands_1.dds");
    Touch(snapshotFuta / "schlong_s.dds");
    Touch(snapshotSkin / "character assets" / "tintmasks" / "femalehead_cheeks.dds");
    skinsCatalog.Refresh(); futaCatalog.Refresh(); tintCatalog.Refresh();
    if (!Require(skinView->front().textureCount == 2U && skinsCatalog.SharedSnapshot()->front().textureCount == 3U &&
            futaView->front().layers.size() == 1U && futaCatalog.SharedSnapshot()->front().layers.size() == 2U &&
            tintView->size() == 1U && tintCatalog.SharedSnapshot()->size() == 2U,
            "refresh invalidated existing readers or failed to publish new metadata")) return 1;
    skinView.reset(); futaView.reset(); tintView.reset();
    if (!Require(oldSkin.expired() && oldFuta.expired() && oldTint.expired(),
            "catalog retained retired snapshots without readers")) return 1;
    std::filesystem::current_path(originalCurrentPath);
    std::filesystem::remove_all(sandbox);
    return 0;
}

#include "BodyChangeNG/TemporaryBodyPreset.h"
#include "BodyChangeNG/BodyMorphWeight.h"
#include "BodyChangeNG/FrameTaskQueue.h"
#include <iostream>
#include <map>
#include <stdexcept>
#include <vector>

namespace
{
using namespace bcn::temporary_body;
unsigned checks{};
void Check(bool ok, const char* label) { ++checks; if (!ok) throw std::runtime_error(label); }
bool Near(float a,float b) { return std::abs(a-b)<.00001F; }
struct Actor {};
struct API {
    using Sources=std::map<std::string,Values>;
    Sources sources;
    int mode{},refreshes{};
    bool pruneZero{},corruptRead{};
    std::vector<std::string> writes;
    void SetMorph(Actor*,const char* name,const char* source,float value) {
        writes.emplace_back(source);
        if (pruneZero && value==0.F) {
            if (auto row=sources.find(source);row!=sources.end()) {
                row->second.erase(name);if(row->second.empty()) sources.erase(row);
            }
        } else sources[source].insert_or_assign(name,value);
    }
    float GetMorph(Actor*,const char* name,const char* source) {
        const auto row=sources.find(source);if(row==sources.end()) return 0.F;
        const auto item=row->second.find(name);if(item==row->second.end()) return 0.F;
        return item->second+(corruptRead && std::string_view(source)==key &&
            std::string_view(name)=="Breasts" ? .1F : 0.F);
    }
    float GetBodyMorphs(Actor*,const char* name) {
        float result{};unsigned count{};
        for(const auto& [source,values]:sources) if(const auto i=values.find(name);i!=values.end()) {
            result=mode==2?std::max(result,i->second):result+i->second;++count;
        }
        return mode==1&&count?result/static_cast<float>(count):result;
    }
    bool HasBodyMorphKey(Actor*,const char* source) {
        const auto row=sources.find(source);return row!=sources.end()&&!row->second.empty();
    }
    void ClearBodyMorphKeys(Actor*,const char* source) { writes.emplace_back(source);sources.erase(source); }
    void ClearBodyMorphNames(Actor*,const char* name) {
        for(auto row=sources.begin();row!=sources.end();) {
            row->second.erase(name);if(row->second.empty()) row=sources.erase(row);else ++row;
        }
    }
    Values Normal() const {
        Values result;for(const auto& [source,values]:sources) if(NormalBaseKey(source))
            for(const auto& [name,value]:values) result[name]+=value;
        return result;
    }
    Sources WithoutOwner() const { auto result=sources;result.erase(key);return result; }
};
API Baseline() {
    API api;
    api.sources["BodyChangeNG"]={{"Breasts",.6F},{"Waist",.3F}};
    api.sources["RaceMenuMorphsCBBE.esp"]={{"Breasts",.1F},{"Arms",.2F}};
    api.sources["BodyChangeNGOutfit"]={{"Breasts",-.05F}};
    api.sources["FHU"]={{"PregnancyBelly",.8F}};
    api.sources["SLIF"]={{"Breasts",.25F}};
    return api;
}
void BodyChecks() {
    Actor actor;
    for(const auto* source:{"BodyChangeNG","BodyChangerNG","BodyChangeNGEditorBaseline",
        "BodyChangeNGEditorOffset","OBody","OClothe","RaceMenuMorphsCBBE.esp",
        "RaceMenuMorphsHIMBO.esp","UBE_RaceMenuMorphs.esp"}) Check(NormalBaseKey(source),"known normal key");
    for(const auto* source:{"FHU","SLIF","Fertility Mode","PSQ_TransformPreset",
        "BodyChangeNGOutfit","BodyChangeNGPreview",key,"UnknownBody.esp"}) Check(!NormalBaseKey(source),"foreign/non-base source");
    auto api=Baseline();const auto before=api.sources;
    const Values desired{{"Breasts",1.2F},{"Waist",.8F}};
    const auto deltas=Deltas(desired,api.Normal());
    Check(Near(deltas.at("Breasts"),.5F),"normal plus editor compensation");
    Check(Near(deltas.at("Arms"),-.2F),"omitted slider targets build default");
    auto current=[] {return true;};auto refresh=[&] {++api.refreshes;};
    Check(Apply(api,&actor,deltas,current,refresh)==applied,"actual helper apply completion");
    Check(api.WithoutOwner()==before,"normal/editor/foreign/outfit data unchanged");
    Check(Near(api.GetBodyMorphs(&actor,"Breasts"),1.4F),"target plus foreign/outfit remains");
    Check(Near(api.GetBodyMorphs(&actor,"PregnancyBelly"),.8F),"FHU additive preserved");
    Check(Near(api.GetBodyMorphs(&actor,"Arms"),0.F),"omitted old normal cancelled");
    Check(api.refreshes==1,"completion after one model refresh");
    const auto first=api.sources;
    Check(Apply(api,&actor,Deltas(desired,api.Normal()),current,refresh)==applied,"reapply succeeds");
    Check(api.sources==first,"reapply cannot stack own layer");
    Check(Clear(api,&actor,current,refresh)==cleared,"clear complete");
    Check(api.sources==before,"exit exact normal data");
    const auto once=api.refreshes;
    Check(Clear(api,&actor,current,refresh)==cleared,"clear idempotent");
    Check(api.refreshes==once,"empty clear no redundant refresh");
    Check(std::ranges::all_of(api.writes,[](const auto& source){return source==key;}),"writer exact owned key");
    for(bool prune:{false,true}) for(bool empty:{false,true}) {
        api=Baseline();api.pruneZero=prune;const auto saved=api.sources;
        Values zero;if(!empty) zero={{"Breasts",0.F},{"Waist",0.F}};
        Check(Apply(api,&actor,Deltas(zero,api.Normal()),current,refresh)==applied,"empty valid/default all-zero preset");
        Check(api.HasBodyMorphKey(&actor,key),"zero preset keeps ownership");
        Check(Near(api.GetMorph(&actor,marker,key),1.F),"non-TRI nonzero marker");
        Check(api.WithoutOwner()==saved,"zero preset preserves source data");
        Check(Clear(api,&actor,current,refresh)==cleared && api.sources==saved,"zero preset exact exit");
    }
    for(float percent:{0.F,1.F,25.F,50.F,100.F}) {
        api=Baseline();const float target=-.2F+1.8F*bcn::body_morph_weight::FromEnginePercent(percent);
        Check(Apply(api,&actor,Deltas({{"Breasts",target}},api.Normal()),current,refresh)==applied,"weight endpoint apply");
        Check(Near(api.GetBodyMorphs(&actor,"Breasts"),target+.2F),"engine weight low/high interpolation");
    }
    for(int mode:{0,1,2}) {
        api=Baseline();api.mode=mode;const auto saved=api.sources;
        Check(UsesAdditive(api,&actor)==(mode==0),"actual aggregation probe");
        Check(api.sources==saved,"probe leaves all old entries intact");
        api.sources[key]={{"Breasts",.4F},{marker,1.F}};
        Check(Clear(api,&actor,current,refresh)==cleared,"clear available with mean/max too");
        Check(api.sources==saved,"non-additive cleanup exact");
    }
    api=Baseline();const auto saved=api.sources;
    Check(!Finite({{"Breasts",std::numeric_limits<float>::infinity()}}),"nonfinite policy reject");
    Check(Apply(api,&actor,{{"Breasts",std::numeric_limits<float>::quiet_NaN()}},current,refresh)==applicationFailed,"nonfinite no native write");
    Check(api.sources==saved,"nonfinite keeps prior body");
    api.corruptRead=true;
    Check(Apply(api,&actor,{{"Breasts",.5F}},current,refresh)==applicationFailed,"owned readback detects failed write");
}
void OwnerChecks() {
    Actor actor;auto api=Baseline();const auto saved=api.sources;
    std::int32_t latest=11;std::uint64_t epoch=5;
    auto current=[&] {return Current(11,latest,5,epoch);};auto refresh=[&] {++api.refreshes;};
    Check(Current(11,11,5,5),"current request");Check(!Current(0,0,5,5),"invalid token");
    Check(!Current(11,12,5,5),"new owner rejects stale request");
    Check(!Current(11,11,5,6),"new session rejects old request");
    latest=12;
    Check(Apply(api,&actor,{{"Breasts",.6F}},current,refresh)==superseded,"stale apply before write");
    Check(api.sources==saved&&api.refreshes==0,"stale apply no mutation");
    latest=11;epoch=6;
    Check(Clear(api,&actor,current,refresh)==superseded,"old-world clear rejected");
    Check(api.sources==saved,"new world data protected");
    epoch=5;unsigned gates{};auto interrupted=[&] {return ++gates<3;};
    Check(Apply(api,&actor,{{"Breasts",.6F},{"Waist",.2F}},interrupted,refresh)==superseded,"mid-write cancellation");
    Check(api.refreshes==0&&api.WithoutOwner()==saved,"partial write never touches foreign data");
    Check(Clear(api,&actor,[] {return true;},refresh)==cleared,"latest clear removes partial layer");
    Check(api.sources==saved,"partial recovery exact baseline");
    bcn::async_work::FrameTaskQueue queue;queue.Reset(true);
    constexpr auto channel=0x50535101U;unsigned oldRun{},clearRun{};
    Check(queue.Submit(20,channel,[&] {++oldRun;},1,true,true),"apply enqueued once");
    Check(queue.SubmitRestoration(20,[&] {++clearRun;Check(Clear(api,&actor,[] {return true;},refresh)==cleared,"queued clear");},1,channel),"clear supersedes pending same-owner apply");
    Check(queue.Pending()==1,"one coalesced job; no polling");
    queue.Advance();auto job=queue.Take();Check(job.has_value(),"next input tick admits work");
    job->run();job.reset();
    Check(oldRun==0&&clearRun==1,"cancelled apply never ran");
    Check(queue.Pending()==0,"no recurring work");
    Check(queue.Submit(20,channel,[&] {++oldRun;},1,true,true),"new pending job");
    queue.Reset(false);
    Check(queue.Pending()==0,"load reset removes pending work");
    Check(oldRun==0,"reset never executes old world callback");
}
}
int main() {
    try {BodyChecks();OwnerChecks();std::cout<<"{\"passed\":true,\"checks\":"<<checks<<",\"runtime_tested\":false}\n";}
    catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}

#include "BodyChangeNG/FrameTaskQueue.h"
#include "BodyChangeNG/AsyncWorkGuards.h"
#include <iostream>
#include <stdexcept>
#include <vector>
using bcn::async_work::FrameTaskQueue;
static void Check(bool ok, const char* message) { if (!ok) throw std::runtime_error(message); }
int main()
{
    try {
        FrameTaskQueue queue;
        Check(!queue.HasWork(), "empty queue incorrectly blocks removal");
        queue.Submit(10, 20, [] {});
        queue.Advance();
        {
            auto job = queue.Take();
            Check(job && queue.Pending() == 0 && queue.HasWork(),
                "removal missed an asynchronous lease with no queued callbacks");
        }
        queue.Advance(); queue.Advance();
        Check(!queue.HasWork(), "completed lease permanently blocks removal");
        // A native face refresh completes an already-committed TXST change.
        // A new body UI choice must not cancel it; repeated rebuild events
        // coalesce, and unrelated equipment work keeps a different key.
        const auto faceChannel = bcn::appearance::ChannelValue(bcn::appearance::WorkChannel::skinFaceRefresh);
        const auto equipmentChannel = bcn::appearance::ChannelValue(bcn::appearance::WorkChannel::equipmentVerify);
        int faceGeneration{};
        queue.Submit(90, faceChannel, [&] { faceGeneration = 1; }, 2, true);
        queue.Submit(90, faceChannel, [&] { faceGeneration = 2; }, 2, true);
        queue.Submit(90, equipmentChannel, [] {}, 2);
        Check(queue.Pending() == 2U, "UI cancellation lost native face completion or merged equipment work");
        queue.Advance();
        Check(!queue.Take(), "native face refresh ran before the rebuild boundary");
        queue.Advance();
        {
            auto faceJob = queue.Take();
            Check(faceJob && faceJob->channel == faceChannel, "native face completion missing");
            faceJob->run();
        }
        Check(faceGeneration == 2, "old native face event ran instead of the newest event");
        queue.Reset(true);
        int result{};
        queue.Submit(1, 1, [&] { result = 1; });
        queue.Submit(1, 1, [&] { result = 2; });
        Check(queue.Pending() == 1 && !queue.Take(), "coalescing or initial boundary");
        queue.Advance();
        auto job = queue.Take();
        Check(job.has_value(), "ready job missing"); job->run();
        Check(result == 2, "old coalesced value applied");
        queue.Submit(1, 2, [] {});
        queue.Submit(2, 1, [] {});
        queue.Advance();
        auto other = queue.Take();
        Check(other && other->actor == 2 && !queue.Take(), "in-flight actor overlapped or blocked other actor");
        auto callbackLease = job->lease; job.reset();
        Check(FrameTaskQueue::ValidLease(callbackLease), "live lease rejected");
        queue.Advance(); Check(!queue.Take(), "async callback lease lost");
        callbackLease.reset(); queue.Advance();
        Check(!queue.Take(), "release observation treated as settled frame");
        queue.Advance(); Check(queue.Take().has_value(), "completed actor never resumed");
        queue.Reset(true);
        queue.Submit(0, 0, [&] { queue.Submit(0, 0, [&] { ++result; }); });
        queue.Advance(); job = queue.Take(); job->run();
        Check(!queue.Take(), "nested submission executed in same tick");
        queue.Advance(); Check(queue.Take().has_value(), "nested submission lost");
        const auto epoch = queue.Epoch(); queue.Reset(false);
        Check(queue.Epoch() != epoch && !queue.Submit(1, 1, [] {}) && !queue.Take(), "load barrier");
        queue.Reset(true);
        queue.Submit(3, 1, [] {}); queue.CancelActor(3); queue.Advance();
        Check(!queue.Take(), "detached actor retained");
        queue.Submit(4, 1, [] {}); queue.Submit(5, 1, [] {}, 1, true); queue.Advance();
        Check(queue.Take()->actor == 5, "visible actor priority");
        for (int i=0;i<60;++i) queue.Advance();
        queue.Submit(6, 1, [] {}, 1, true); queue.Advance();
        Check(queue.Take()->actor == 4, "bulk starvation");
        queue.Submit(7, 1, [] {}); queue.Advance(); job = queue.Take();
        // Actor 6 is still pending from the priority test; cancel whichever
        // actor was selected and verify that cancellation keeps its lease.
        queue.CancelActor(job->actor);
        Check(!FrameTaskQueue::ValidLease(job->lease), "active callback not invalidated");
        queue.Reset(true);
        for (unsigned i=1;i<=500;++i) for (int j=0;j<10;++j) queue.Submit(i, 1, [] {});
        Check(queue.Pending() == 500, "duplicate event growth");
        queue.Reset(true);
        queue.Submit(8, 200, [] {}, 1, true);
        queue.Submit(8, 201, [] {});
        queue.Submit(8, 200, [] {}, 1, true);
        queue.Advance();
        Check(queue.Take()->channel == 201, "new preview overtook earlier commit");
        queue.Reset(true);
        queue.Submit(1, 100, [] {}, 1, true);
        queue.Submit(2, 201, [] {}, 1, true);
        queue.Advance();
        Check(queue.Take()->actor == 2, "visible native application delayed behind unrelated planning");
        queue.Reset(true);
        queue.Submit(10, 100, [] {});
        for (unsigned n=0; n<60; ++n) queue.Advance();
        // Simulate an expensive native call using an entire pump. Direct input
        // wins three reserved opportunities; aged bulk still gets a turn.
        for (unsigned n=0; n<3; ++n) {
            queue.Submit(20+n, 200, [] {}, 1, true, true);
            queue.Advance();
            auto input = queue.Take(true);
            Check(input && input->actor == 20+n && FrameTaskQueue::InteractiveLease(input->lease),
                "aged bulk stole reserved input opportunity");
        }
        queue.Submit(23, 200, [] {}, 1, true, true); queue.Advance();
        Check(queue.Take(true)->actor == 10, "continuous input starved aged bulk");
        Check(queue.Take()->actor == 23, "input lost after fairness opportunity");

        queue.Reset(true);
        queue.Submit(30, 201, [] {});
        queue.Submit(31, 100, [] {});
        queue.Submit(30, 200, [] {}, 1, true, true);
        queue.Advance(); job = queue.Take(true);
        Check(job && job->actor == 30 && job->channel == 201 && job->interactive,
            "reserved input overtook its own commit or failed to promote prerequisite");
        Check(queue.Take(true)->actor == 31 && !queue.Take(true), "input bypassed live actor lease");
        job.reset(); queue.Advance(); queue.Advance();
        Check(queue.Take(true)->channel == 200, "latest preview lost after earlier commit");

        queue.Reset(true);
        queue.Submit(40, 100, [] {}, 6);
        queue.Submit(40, 204, [] {}, 1, true, true);
        queue.Submit(41, 204, [] {}, 1, true, true);
        queue.Advance();
        Check(queue.Take(true)->actor == 41 && !queue.Take(true), "direct input bypassed same-actor due boundary");

        queue.Reset(true);
        queue.Submit(42, 204, [] {}); queue.Advance(); job = queue.Take();
        auto automaticLease = job->lease;
        Check(!FrameTaskQueue::InteractiveLease(automaticLease), "automatic skin incorrectly started interactive");
        Check(!queue.Submit(42, 204, [] {}, 1, true, false, automaticLease),
            "continuation allowed to reacquire its own busy actor");
        queue.Submit(0, 0, [] {}, 1, true, false, automaticLease);
        job.reset(); queue.Submit(43, 100, [] {});
        for (unsigned n=0; n<60; ++n) queue.Advance();
        queue.Submit(42, 201, [] {}, 1, true, true); queue.Advance();
        Check(FrameTaskQueue::InteractiveLease(automaticLease), "direct selection failed to promote running skin");
        job = queue.Take(true);
        Check(job && job->actor == 0 && job->lease == automaticLease && job->interactive,
            "queued skin continuation did not inherit later input priority");
        Check(queue.Take()->actor == 43 && !queue.Take(), "new selection overlapped promoted continuation");
        job.reset(); automaticLease.reset(); queue.Advance(); queue.Advance();
        Check(queue.Take(true)->channel == 201, "new selection lost after promoted skin finished");

        queue.Reset(true);
        queue.Submit(50, 204, [] {});
        for (int i=0; i<100; ++i) queue.Submit(50, 204, [&] { result = 77; }, 1, true, true);
        Check(queue.Pending() == 1 && queue.Status(50).queued && !queue.Status(50).busy,
            "latest-choice coalescing or queued status");
        Check(queue.Status(50, FrameTaskQueue::Clock::now() + std::chrono::seconds(2)).Delayed(),
            "long pending wait not exposed");
        queue.Advance(); job = queue.Take(true); job->run();
        Check(result == 77 && job->interactive && !queue.Status(50).queued && queue.Status(50).busy,
            "coalesced result or active status");
        // The VM retains its callback object, but a completed callback must
        // not keep the actor busy. Its real continuation DOES keep it busy.
        bcn::async_work::CompletionPayload<FrameTaskQueue::Lease> retainedCallback(job->lease);
        auto continuation = retainedCallback.Take(); job.reset();
        queue.Submit(50, 201, [] {}, 1, true, true); queue.Advance();
        Check(!queue.Take(true), "callback payload transfer released unfinished continuation");
        Check(!retainedCallback.Take(), "retained callback invoked twice");
        continuation.reset(); queue.Advance();
        Check(!queue.Take(true), "completion transfer removed quiet boundary");
        queue.Advance();
        Check(queue.Take(true).has_value(), "completed-but-retained callback blocked next choice");
        queue.Advance(); queue.Advance();
        Check(!queue.Status(50).busy && !queue.Status(50).queued, "completed work left stale UI status");

        // Multiple outstanding native callbacks: a newer selection may
        // supersede follow-ups, but cannot overlap any unfinished native call.
        queue.Reset(true);
        queue.Submit(55, 204, [] {}, 1, true, true); queue.Advance(); job = queue.Take(true);
        using NativeCallback = bcn::async_work::CompletionPayload<FrameTaskQueue::Lease>;
        std::vector<std::unique_ptr<NativeCallback>> nativeCallbacks;
        for (unsigned n=0; n<3; ++n) nativeCallbacks.push_back(std::make_unique<NativeCallback>(job->lease));
        job.reset();
        for (int n=0; n<100; ++n) queue.Submit(55, 204, [&, n] { result = n; }, 1, true, true);
        for (unsigned n=0; n<2; ++n) {
            auto finishedNative = nativeCallbacks[n]->Take(); finishedNative.reset();
            queue.Advance(); queue.Advance();
            Check(!queue.Take(true), "new skin overlapped remaining native callbacks");
        }
        auto lastNative = nativeCallbacks.back()->Take(); lastNative.reset();
        queue.Advance(); queue.Advance(); job = queue.Take(true);
        Check(job.has_value(), "retained completed native callbacks blocked latest skin"); job->run();
        Check(result == 99 && queue.Pending() == 0, "intermediate skin replayed or final skin lost");

        queue.Reset(true);
        queue.Submit(56, 204, [] {}, 1, true, true); queue.Advance(); job = queue.Take(true);
        NativeCallback cancelled(job->lease); job.reset();
        queue.CancelActor(56);
        auto cancelledResult = cancelled.Take();
        Check(cancelledResult && !FrameTaskQueue::ValidLease(*cancelledResult), "cancelled callback lost invalidation at transfer");
        cancelledResult.reset(); queue.Advance(); queue.Advance();
        Check(!queue.HasActorWork(56), "cancelled completed callback retained actor");

        // A VM callback is allowed to retain its callback object forever.
        // The watchdog cancels the shared lease; the queue must then release
        // the actor after the same quiet boundary even though the callback's
        // strong reference never returns.
        queue.Reset(true);
        queue.Submit(57, 204, [] {}, 1, true, true); queue.Advance(); job = queue.Take(true);
        NativeCallback neverReturning(job->lease);
        const auto neverReturningLease = job->lease;
        job.reset();
        queue.Submit(57, 201, [&] { result = 570; }, 1, true, true);
        for (unsigned n=0; n<4; ++n) queue.Advance();
        Check(!queue.Take(true), "unreturned callback lease released without cancellation");
        neverReturningLease->cancelled.store(true);
        queue.Advance();
        Check(!queue.Take(true), "timed-out callback skipped quiet boundary");
        queue.Advance(); job = queue.Take(true);
        Check(job && job->actor == 57 && job->channel == 201,
            "timed-out callback permanently blocked the actor");
        job->run();
        Check(result == 570 && !FrameTaskQueue::ValidLease(neverReturningLease),
            "late callback lease revived after timeout");
        Check(neverReturning.Take() && !FrameTaskQueue::ValidLease(neverReturningLease),
            "retained callback did not preserve cancellation");

        queue.Reset(true);
        queue.Submit(60, 204, [] {}, 1, true, true); queue.Advance(); job = queue.Take(true);
        auto detachedLease = job->lease; job.reset(); queue.CancelActor(60);
        Check(!FrameTaskQueue::ValidLease(detachedLease) && queue.Status(60).busy,
            "detach incorrectly reported unfinished callback complete");
        queue.Reset(false);
        Check(!queue.Status(60).busy && !queue.Status(60).queued && !FrameTaskQueue::ValidLease(detachedLease),
            "session reset leaked status or revived callback");

        // Body choices supersede only body choices. A native texture lease
        // must finish, and tint/overlay/genital work must survive rapid input.
        queue.Reset(true);
        queue.Submit(80, 204, [] {}, 1, true, true);
        queue.Advance(); job = queue.Take(true);
        auto skinLease = job->lease; job.reset();
        std::vector<int> completed;
        for (const auto channel : {206U, 207U, 208U, 209U, 210U, 211U})
            queue.Submit(80, channel, [&, channel] { completed.push_back(channel); }, 1, true, true);
        for (int click = 0; click < 10000; ++click)
            queue.Submit(80, 200, [&, click] { result = click; }, 1, true, true);
        Check(queue.Pending() == 7U && FrameTaskQueue::ValidLease(skinLease),
            "rapid body input cancelled unrelated work or grew the queue");
        queue.Advance(); Check(!queue.Take(true), "body overlapped active texture mutation");
        skinLease.reset();
        for (int tick = 0; tick < 30; ++tick) {
            queue.Advance();
            if (auto next = queue.Take(true)) next->run();
        }
        Check(completed == std::vector<int>{206,207,208,209,210,211} &&
            result == 9999 && queue.Pending() == 0U && !queue.Status(80).busy,
            "cross-feature work lost, stale body applied, or lease leaked");
        // An accepted skin undo outlives actor detach, but not the session.
        // Per-base generations discard old undo after a newer accepted choice.
        queue.Reset(true);
        unsigned generation = 1, restored{};
        for (unsigned cycle = 1; cycle <= 10000; ++cycle) {
            generation = cycle;
            queue.SubmitRestoration(80, [&, accepted = generation] { if (accepted == generation) ++restored; });
            queue.CancelActor(80);
            queue.Advance();
            while (auto undo = queue.Take()) undo->run();
        }
        Check(restored == 10000 && !queue.HasWork(), "detach undo lost or retained completed work");
        queue.SubmitRestoration(80, [&, accepted = generation] { if (accepted == generation) ++restored; });
        ++generation; queue.Advance();
        while (auto undo = queue.Take()) undo->run();
        Check(restored == 10000, "old undo overwrote new selection");
        const auto undoEpoch = queue.Epoch();
        queue.SubmitRestoration(80, [&] { ++restored; });
        queue.Reset(true); queue.Advance();
        Check(queue.Epoch() != undoEpoch && !queue.Take() && !queue.HasWork(), "undo crossed the session boundary");
        // Retain one captured undo through a long RaceMenu session. Do not
        // reallocate/requeue it each frame, and do not block unrelated NPCs.
        auto payload = std::make_shared<int>(0);
        const std::weak_ptr<int> weakPayload = payload;
        queue.SubmitRestoration(14, [payload] { ++*payload; }); payload.reset();
        queue.SubmitRestoration(80, [&] { ++restored; });
        queue.Advance();
        job = queue.Take(true, 14);
        Check(job && job->lease->restorationActor == 80, "player gate blocked an NPC undo");
        job->run(); job.reset();
        for (unsigned frame = 0; frame < 10000; ++frame) {
            queue.Advance();
            Check(!queue.Take(true, 14) && queue.Pending() == 1, "deferred undo duplicated or escaped its gate");
        }
        Check(!weakPayload.expired() && *weakPayload.lock() == 0, "deferred capture lost or prematurely invoked");
        queue.CancelActor(14); job = queue.Take(true);
        Check(job && job->lease->restorationActor == 14, "undo disappeared at RaceMenu actor cancellation");
        auto restoreLease = job->lease;
        job->run(); job.reset();
        Check(weakPayload.expired(), "finished restoration retained its capture");
        // A texture worker resumes later using the same gate, even if the
        // menu reopened after the original dispatch.
        queue.Submit(0, 0, [&] { ++restored; }, 1, true, true, restoreLease);
        queue.Advance(); Check(!queue.Take(true, 14), "restoration continuation bypassed RaceMenu");
        job = queue.Take(true); Check(job.has_value(), "restoration continuation never resumed");
        job->run(); job.reset();
        queue.Reset(true);
        Check(!queue.Submit(0, 0, [] {}, 1, true, true, restoreLease), "late worker revived an undo from a prior session");
        restoreLease.reset(); Check(!queue.HasWork(), "restoration retained queue work after reset");
        queue.SubmitRestoration(14, [] {}); queue.Advance(); job = queue.Take();
        auto cancelledRestore = job->lease; job.reset(); cancelledRestore->cancelled.store(true);
        queue.Submit(0, 0, [] {}, 1, true, true, cancelledRestore); queue.Advance();
        Check(!queue.Take(true, 14) && !queue.HasWork(), "cancelled restoration leaked behind the menu gate");
        // Channelled undo must retain actor FIFO, latest-choice coalescing and
        // busy ownership, without losing the RaceMenu/detach protection.
        queue.Reset(true); job.reset(); restored = 0;
        auto pendingCapture = std::make_shared<int>(1);
        std::weak_ptr<int> pendingWeak = pendingCapture;
        queue.Submit(14, 206, [pendingCapture] {}); pendingCapture.reset();
        queue.SubmitRestoration(14, [&] { ++restored; }, 1, 206);
        Check(pendingWeak.expired() && queue.Pending() == 1 && queue.HasActorChannelWork(14, 206),
            "channelled undo did not replace pending preview/release capture");
        queue.Submit(14, 207, [] {}); queue.CancelActor(14);
        Check(queue.Pending() == 1 && queue.Status(14).queued && !queue.HasActorChannelWork(14, 207),
            "detach lost undo or retained unrelated pending work/status");
        queue.Advance(); Check(!queue.Take(true, 14), "channelled undo escaped RaceMenu gate");
        job = queue.Take(true); Check(job && job->actor == 14 && job->channel == 206, "channelled undo lost actor ownership");
        auto channelLease = job->lease;
        Check(channelLease->restorationActor == 14 && channelLease->restorationEpoch == queue.Epoch(),
            "taking channelled undo replaced its restoration lease");
        job->run(); job.reset();
        queue.CancelActor(14);
        Check(FrameTaskQueue::ValidLease(channelLease) && queue.HasActorWork(14), "detach cancelled in-flight restoration");
        Check(!queue.Submit(14, 206, [] {}, 1, true, true, channelLease), "continuation reacquired its own actor");
        queue.Submit(0, 0, [&] { ++restored; }, 1, true, true, channelLease);
        queue.Submit(14, 206, [&] { result = 123; }); queue.Advance();
        Check(!queue.Take(true, 14), "new selection overlapped gated deferred restoration");
        job = queue.Take(true); Check(job && !job->actor && job->lease == channelLease, "restoration continuation lost lease");
        job->run(); job.reset();
        Check(!queue.Take(true), "new selection overlapped active restoration lease");
        channelLease.reset(); queue.Advance(); Check(!queue.Take(true), "undo skipped actor quiet boundary");
        queue.Advance(); job = queue.Take(true); Check(job && job->actor == 14, "new choice failed after undo");
        job->run(); job.reset(); queue.Advance(); queue.Advance();
        Check(restored == 2 && result == 123 && !queue.HasWork(), "deferred undo/new choice left work or wrong result");
        // Replacing a parked undo with a new ordinary selection must remove
        // its restoration lease: ordinary selection remains cancellable.
        auto replacedCapture = std::make_shared<int>(2);
        std::weak_ptr<int> replacedWeak = replacedCapture;
        queue.SubmitRestoration(14, [replacedCapture] {}, 1, 206); replacedCapture.reset();
        queue.Submit(14, 206, [] {});
        Check(replacedWeak.expired(), "replaced undo retained its capture");
        queue.CancelActor(14);
        Check(!queue.HasWork(), "new ordinary choice inherited old undo's cancellation immunity");
        for (unsigned cycle{}; cycle < 10000; ++cycle) {
            queue.SubmitRestoration(14, [&] { ++restored; }, 1, 206);
            queue.CancelActor(14); queue.Advance();
            while (auto undo = queue.Take()) undo->run();
            queue.Advance(); queue.Advance();
        }
        Check(restored == 10002 && !queue.HasWork(), "channelled undo cycles leaked work or lost restores");
        queue.SubmitRestoration(14, [] {}, 1, 206); queue.Advance(); job = queue.Take();
        channelLease = job->lease; job.reset(); queue.Reset(true);
        Check(!FrameTaskQueue::ValidLease(channelLease) &&
            !queue.Submit(0, 0, [] {}, 1, true, true, channelLease), "session reset revived channelled undo");
        FrameTaskQueue::WorkStatus threshold{true, false, 1499};
        Check(!threshold.Delayed(), "delay indicator threshold too early");
        threshold.elapsedMs = 1500;
        Check(threshold.Delayed(), "delay indicator threshold missing");
        std::cout << "FrameTaskQueueTests passed\n";
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}

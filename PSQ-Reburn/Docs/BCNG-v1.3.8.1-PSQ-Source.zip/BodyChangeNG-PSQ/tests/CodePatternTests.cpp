#include "BodyChangeNG/FormDeleteCallbackPattern.h"
#include "BodyChangeNG/PeImageFile.h"
#include "BodyChangeNG/PopupPlacement.h"
#include <limits>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <source_location>
#include <string>

namespace {
    void Require(bool ok, const std::source_location location =
        std::source_location::current())
    {
        if (!ok) {
            std::cerr << "CodePatternTests failed at line " << location.line() << '\n';
            std::abort();
        }
    }
    template<class T> void Put(std::span<std::uint8_t> bytes, std::size_t offset,T value) {
        Require(offset<=bytes.size() && sizeof(T)<=bytes.size()-offset);
        std::memcpy(bytes.data()+offset,&value,sizeof(value));
    }
}
int main()
{
    using namespace bcn::popup_placement;
    Require(keys.size() == 9U);
    constexpr std::array<std::string_view, 9> savedPopupKeys{
        "outfit", "settings", "tintColor", "overlayColor", "distributionBody",
        "distributionSkin", "distributionFutanari", "distributionOverlay", "removalConfirmation"};
    for (std::size_t index{}; index < keys.size(); ++index) Require(keys[index] == savedPopupKeys[index]);
    Require(Changed({}, 320.0F, 240.0F));
    Require(!Changed({ true, 320.0F, 240.0F }, 320.25F, 240.25F));
    Require(Changed({ true, 320.0F, 240.0F }, 350.0F, 240.0F));
    Require(!Valid(std::numeric_limits<float>::infinity(), 0.0F));
    Require(!Valid(0.0F, std::numeric_limits<float>::quiet_NaN()));
    Require(ClampAxis(1800.0F, 700.0F, 0.0F, 1920.0F) == 1220.0F);
    Require(ClampAxis(-500.0F, 700.0F, 0.0F, 1920.0F) == 0.0F);
    Require(ClampAxis(600.0F, 700.0F, 100.0F, 600.0F) == 100.0F);
    Require(ClampAxis(600.0F, 700.0F, 0.0F, 0.0F) == 600.0F);

    using namespace bcn::racemenu_form_delete;
    constexpr std::array<std::uint8_t,42> original{
        0x40,0x53,0x48,0x83,0xec,0x20,0x48,0x8b,0xd9,0x8b,0xd1,
        0x48,0x8d,0x0d,0x7e,0xbc,0x18,0x00,0xe8,0x89,0x88,0x03,0x00,
        0x8b,0xd3,0x48,0x8d,0x0d,0x70,0xbc,0x18,0x00,0x48,0x83,0xc4,0x20,
        0x5b,0xe9,0xc6,0x89,0x03,0x00};
    Require(DecodeNarrowingCallback(original,0x50AA0,0x300000)==CallbackPlan{0x50AA0,0x1DC730,0x89340,0x89490});
    // Address moves do not require another DLL hash/version entry. All four
    // signed relative displacements must be decoded on the loaded image.
    for (auto entry:{0x1000U,0xF0000U,0x200000U}) {
        auto code=original;
        const auto write=[&](std::size_t offset,std::uint32_t target) {
            Put<std::int32_t>(code,offset,static_cast<std::int32_t>(target-entry-offset-4));
        };
        write(14,0xD0000); write(28,0xD0000); write(19,0x60000); write(38,0x50000);
        Require(DecodeNarrowingCallback(code,entry,0x300000)==CallbackPlan{entry,0xD0000,0x60000,0x50000});
        write(28,0xD0008); Require(!DecodeNarrowingCallback(code,entry,0x300000));
        write(28,0xD0000); write(38,0x60000); Require(!DecodeNarrowingCallback(code,entry,0x300000));
        write(38,entry); Require(!DecodeNarrowingCallback(code,entry,0x300000));
        write(38,0x400000); Require(!DecodeNarrowingCallback(code,entry,0x300000));
    }
    for (std::size_t i{};i<original.size();++i) {
        if ((i>=14 && i<18) || (i>=19 && i<23) || (i>=28 && i<32) || i>=38) continue;
        auto changed=original; changed[i]^=0x01;
        Require(!DecodeNarrowingCallback(changed,0x50AA0,0x300000));
    }
    // A full-width legacy callback is NOT this bug and must stay untouched.
    auto wide=std::vector<std::uint8_t>(original.begin(),original.end());
    wide.insert(wide.begin()+9,0x48);
    Require(!DecodeNarrowingCallback(wide,0x50AA0,0x300000));
    Require(!DecodeNarrowingCallback({},0x50AA0,0x300000));
    Require(!DecodeNarrowingCallback(original,0xFFFFFFF0,0xFFFFFFFF));

    using bcn::code_image::File;
    std::vector<std::uint8_t> pe(0xC00);
    Put<std::uint16_t>(pe,0,0x5A4D); Put<std::uint32_t>(pe,0x3C,0x80);
    Put<std::uint32_t>(pe,0x80,0x4550); Put<std::uint16_t>(pe,0x84,0x8664);
    Put<std::uint16_t>(pe,0x86,2); Put<std::uint16_t>(pe,0x94,0xF0);
    Put<std::uint16_t>(pe,0x98,0x20B); Put<std::uint32_t>(pe,0x98+56,0x4000);
    Put<std::uint32_t>(pe,0x98+136,0x1800); Put<std::uint32_t>(pe,0x98+140,12);
    Put<std::uint32_t>(pe,0x188+8,0xA00); Put<std::uint32_t>(pe,0x188+12,0x1000);
    Put<std::uint32_t>(pe,0x188+16,0xA00); Put<std::uint32_t>(pe,0x188+20,0x200);
    Put<std::uint32_t>(pe,0x188+36,0x60000020);
    // BSS has virtual extent but no bytes on disk. Global Override resides
    // there in real SKEE; executable bytes must NOT be read from that range.
    Put<std::uint32_t>(pe,0x1B0+8,0x1000); Put<std::uint32_t>(pe,0x1B0+12,0x2000);
    Put<std::uint32_t>(pe,0x1B0+36,0xC0000080);
    Put<std::uint32_t>(pe,0xA00,0x1100); Put<std::uint32_t>(pe,0xA04,0x112A);
    const auto parsed=File::Parse(pe);
    Require(parsed.has_value());
    Require(parsed->IsFunction(0x1100) && !parsed->IsFunction(0x1101));
    Require(parsed->HasFlags(0x2800,8,0x80000000) && parsed->Bytes(0x2800,8).empty());
    Require(parsed->Bytes(0x1100,42).size()==42);
    Require(!parsed->HasFlags(0xFFFFFFF0,64,0x80000000));
    for (std::size_t size{};size<pe.size();++size) Require(!File::Parse(std::span(pe).first(size)));
    auto bad=pe; Put<std::uint32_t>(bad,0x3C,0xFFFFFFF0); Require(!File::Parse(bad));
    bad=pe; Put<std::uint16_t>(bad,0x86,97); Require(!File::Parse(bad));
    bad=pe; Put<std::uint32_t>(bad,0x188+16,0xFFFFFFFF); Require(!File::Parse(bad));
    bad=pe; Put<std::uint32_t>(bad,0xA04,0x1100); Require(!File::Parse(bad));
    bad=pe; Put<std::uint32_t>(bad,0x188+36,0x40000040); Require(!File::Parse(bad));

    // The NiNodeUpdate event is the face rebuild barrier. Once it fires, face
    // work must go directly to SKSE's game queue; routing it back through the
    // input-tick actor queue reintroduces a visible extra quiet-lease tick.
    std::ifstream faceFile(std::filesystem::path("src") / "BodyChangeNG" /
        "FaceSkinOverrides.cpp", std::ios::binary);
    Require(faceFile.good());
    const std::string faceSource((std::istreambuf_iterator<char>(faceFile)), {});
    const auto eventBegin = faceSource.find("void OnNiNodeUpdate(RE::Actor* actor)");
    const auto eventEnd = faceSource.find("void Reset(bool preserveBaselines)", eventBegin);
    Require(eventBegin != std::string::npos && eventEnd != std::string::npos);
    const auto eventBody = std::string_view(faceSource).substr(eventBegin, eventEnd - eventBegin);
    Require(eventBody.contains("SKSE::GetTaskInterface()"));
    Require(eventBody.contains("tasks->AddTask"));
    Require(!eventBody.contains("frame_tasks::Queue"));

    std::ifstream uiFile(std::filesystem::path("src") / "BodyChangeNG" /
        "UI.cpp", std::ios::binary);
    Require(uiFile.good());
    std::string uiSource((std::istreambuf_iterator<char>(uiFile)), {});
    std::erase(uiSource, '\r');
    const auto uiSection = [&uiSource](std::string_view begin, std::string_view end) {
        const auto first = uiSource.find(begin);
        const auto last = uiSource.find(end, first);
        Require(first != std::string::npos && last != std::string::npos && last > first);
        return std::string_view(uiSource).substr(first, last - first);
    };
    const auto editorEntry = uiSection("void OpenDistributionEditorFromCatalog(",
        "void OpenDistributionConditions(");
    const auto bodyCatalog = uiSection("void DrawCatalog(", "void DrawSkinCatalog()");
    Require(bodyCatalog.contains("현재 액터로 미리보기 불가") && bodyCatalog.contains("Cannot preview on the current actor") &&
        bodyCatalog.contains("无法在当前角色身上预览") && bodyCatalog.contains("가까운 액터로 배포항목 미리보기 중") &&
        bodyCatalog.contains("backendCurrentBody == item.id") &&
        bodyCatalog.contains("std::string(incompatibleLabel)"));
    Require(!bodyCatalog.contains("This item is incompatible with the selected actor.") &&
        bodyCatalog.contains("if (item.compatible && body && QueuePreset") &&
        bodyCatalog.contains("if (item.compatible) {") &&
        bodyCatalog.contains("if (distributionSelecting) RollbackSingleCatalogPreview(actor, DistributionPool::body)"));
    Require(editorEntry.contains("SetRuleDistributionSelection") &&
        !editorEntry.contains("ResetDistributionSelectionSession") &&
        !editorEntry.contains("ClearDistributionCatalogSelection"));
    const auto metadataRequest = uiSection("void RequestDistributionTargetOptions()",
        "void EnsureDistributionEditor()");
    Require(metadataRequest.contains("frame_tasks::Queue(0") &&
        metadataRequest.contains("WorkChannel::distributionTargets") &&
        metadataRequest.contains("g_distributionTargets.Current(ticket)") &&
        metadataRequest.contains("g_distributionTargets.Publish") &&
        metadataRequest.find("frame_tasks::Queue(0") < metadataRequest.find("CollectDistributionTargetOptions"));
    const auto targetRead = uiSection("void AddFormTargetOption(",
        "[[nodiscard]] std::optional<DistributionTargetSnapshot> CollectDistributionTargetOptions(");
    Require(targetRead.contains("distribution_target::Read<T>") &&
        !targetRead.contains("->GetName()") && !targetRead.contains("->GetFormEditorID()"));
    const auto ensureEditor = uiSection("void EnsureDistributionEditor()", "void SynchronizeDistributionRuleNames()");
    Require(ensureEditor.contains("g_distributionTargets.Read()") &&
        !ensureEditor.contains("GetFormArray") && !ensureEditor.contains("CollectDistributionTargetOptions("));
    Require(uiSection("void OnOpened()", "static void ResetForLoad(")
        .contains("ResetDistributionSelectionSession()"));
    const auto loadReset = uiSection("static void ResetForLoad(", "void OnClosed()");
    Require(loadReset.contains("g_uiSessionEpoch = 0") &&
        loadReset.contains("ResetDistributionEditor()") &&
        loadReset.contains("ResetDistributionSelectionSession()") &&
        loadReset.contains("Presentation::Get().DiscardSession()") &&
        !loadReset.contains("RollbackPendingSelections"));
    for (const auto section : {
            uiSection("void DrawCatalog(", "void DrawSkinCatalog()"),
            uiSection("void DrawSkinCatalog()", "void DrawOverlayCatalog()") }) {
        Require(!section.contains("if (distributionSelecting) return;") &&
            section.contains("FocusCatalogRow(row);\n                        previewRow(row);") &&
            section.contains("FocusCatalogRow(row);\n                    confirmRow(row);") &&
            section.contains("RollbackSingleCatalogPreview(actor, DistributionPool::"));
        const auto confirm = section.find("const auto confirmRow =");
        const auto distribution = section.find("if (distributionSelecting)", confirm);
        const auto stop = section.find("return;", distribution);
        const auto branch = section.substr(distribution, stop - distribution);
        Require(branch.contains("SetDistributionItemSelected") && branch.contains("previewRow(row)") &&
            !branch.contains("ApplyMode::commit") && !branch.contains("SaveManual"));
    }
    const auto futaSelection = uiSection("void DrawFutanariCatalog()", "void DrawPlayerTintCatalog()");
    Require(futaSelection.contains("CommitsActorChoice(confirm, distributionSelecting)") &&
        futaSelection.contains("FutanariSelectionMode::preview") &&
        futaSelection.contains("FocusCatalogRow(row);\n                        applyRow(row, false);") &&
        futaSelection.contains("FocusCatalogRow(row);\n                    applyRow(row, true);") &&
        futaSelection.contains("const auto backendCurrentID = actor ?") &&
        futaSelection.contains("profile.type != *actorType") &&
        futaSelection.contains("FutanariSkinTypeMatchesActor(profile.type, actorFamily)"));
    // Futanari uses the shared favorite control in both catalog modes. The star
    // has its own hit target and must not preview, confirm, or select a candidate.
    Require(futaSelection.contains("settings.favoriteFutanariSkins") &&
        futaSelection.contains("if (FavoritesOnly() && !favorites.contains(profile.id)) continue;") &&
        futaSelection.contains("const auto favoriteWidth = canFavorite ? Scaled(46.0F) : 0.0F;") &&
        futaSelection.contains("ImGui::InvisibleButton(\"item\", ImVec2((std::max)(0.0F, width - favoriteWidth), height))") &&
        futaSelection.contains("if (FavoriteButton(favorites.contains(id), height)) ToggleFutanariFavorite(id);") &&
        futaSelection.contains("currentID.empty(), false)") &&
        futaSelection.contains("bcn::asset_identity::Equal{}(profile->id, currentID), true)") &&
        futaSelection.find("const auto clicked = ImGui::IsItemClicked();") <
            futaSelection.find("FavoriteButton(favorites.contains(id), height)"));
    const auto futaFavorite = uiSection("void ToggleFutanariFavorite(", "void ToggleTintFavorite(");
    Require(futaFavorite.contains("settings.favoriteFutanariSkins") &&
        futaFavorite.contains("Settings::Get().Save()") &&
        !futaFavorite.contains("QueueApply") && !futaFavorite.contains("applyRow") &&
        !futaFavorite.contains("SetDistributionItemSelected"));
    Require(!uiSource.contains("showFavorites = g_activeTab != ActiveTab::futanari") &&
        uiSource.contains("ImGui::Checkbox(favoritesLabel, &FavoritesOnly());"));
    Require(uiSection("void CancelDistributionCatalogSelection()", "bool DistributionItemSelected(")
        .contains("RollbackSingleCatalogPreview(SelectedActor(), g_distributionPool)"));
    Require(uiSection("void OpenDistributionEditorFromCatalog()", "template <class Refresh")
        .contains("RollbackSingleCatalogPreview(SelectedActor(), g_distributionPool)"));
    const auto singleRollback = uiSection(
        "void RollbackSingleCatalogPreview(RE::Actor* actor, const", "void RollbackPendingSelections(RE::Actor* actor)\n");
    Require(singleRollback.contains("IsCurrent(g_uiSessionEpoch.load())") &&
        singleRollback.contains("FutanariSelectionMode::restore") &&
        singleRollback.contains("skin_transaction::Mode::restore") &&
        singleRollback.contains("g_pendingSkin->originalId") &&
        singleRollback.contains("QueueCancelPreview()") &&
        !singleRollback.contains("SetManual") && !singleRollback.contains("SetDistributionItemSelected"));
    const auto placementBegin = uiSource.find("bool BeginUndimmedPopupModal(");
    const auto placementEnd = uiSource.find("void TextDisabledWrapped", placementBegin);
    Require(placementBegin != std::string::npos && placementEnd != std::string::npos);
    const auto placementBody = std::string_view(uiSource).substr(placementBegin, placementEnd - placementBegin);
    Require(placementBody.contains("modals.Begin(") && placementBody.contains("RememberPopupPosition"));
    for (const auto* kind : keys) {
        Require(uiSource.contains(std::string("Kind::") + kind));
    }
    const auto outfitBegin = uiSource.find("void DrawOutfitPopup()");
    const auto outfitEnd = uiSource.find("void DrawSettingsPopup()", outfitBegin);
    const auto outfitBody = std::string_view(uiSource).substr(outfitBegin, outfitEnd - outfitBegin);
    Require(outfitBody.find("SetNextWindowSizeConstraints") < outfitBody.find("BeginUndimmedPopupModal"));
    const auto overlayBegin = uiSource.find("void DrawOverlayCatalog()");
    const auto overlayFooter = uiSource.find("// Keep color controls outside", overlayBegin);
    const auto overlayEnd = uiSource.find("void DrawFutanariCatalog()", overlayFooter);
    const auto footer = std::string_view(uiSource).substr(overlayFooter, overlayEnd - overlayFooter);
    Require(!footer.contains("if (distributionSelecting) return;") &&
        footer.contains("!color.has_value() && !distributionColorTarget") &&
        footer.contains("g_overlayColorDistributionDraft = distributionSelecting") &&
        footer.contains("g_overlayDistributionPreviewDirty[bcn::overlay::Index(colorArea)] = true") &&
        footer.contains("SyncDistributionOverlayPreviews();"));
    const auto colorPopupBegin = uiSource.find("void DrawOverlayDetailPopup()");
    const auto colorPopupEnd = uiSource.find("void DrawTintDetailPopup()", colorPopupBegin);
    const auto colorPopup = std::string_view(uiSource).substr(colorPopupBegin, colorPopupEnd - colorPopupBegin);
    Require(colorPopup.contains("g_overlayColorDrafts.Set(") &&
        colorPopup.contains("bcn::overlay::QueueColor(actor, g_overlayColorArea") &&
        colorPopup.contains("g_overlayColorDistributionDraft ? bcn::overlay::ApplyResult::queued :") &&
        colorPopup.contains("SyncDistributionOverlayPreviews();") &&
        !colorPopup.contains("if (!g_overlayColorDistributionDraft &&"));
    const auto overlayRows = std::string_view(uiSource).substr(overlayBegin, overlayFooter - overlayBegin);
    const auto overlayApplyBegin = overlayRows.find("const auto applyRow =");
    const auto overlayApplyEnd = overlayRows.find("std::size_t preferredIndex", overlayApplyBegin);
    Require(overlayApplyBegin != std::string::npos && overlayApplyEnd != std::string::npos);
    const auto overlayApply = overlayRows.substr(overlayApplyBegin, overlayApplyEnd - overlayApplyBegin);
    // Mouse and keyboard/gamepad share this handler; even an already-applied
    // row must update focus before its early return. Default keeps clear-area
    // ownership separate from the normal (nullopt) camera presentation.
    Require(overlayApply.contains("g_overlayArea = row.area;") &&
        overlayApply.contains("g_overlayCameraArea = row.entry ? std::optional{ row.area } : std::nullopt;") &&
        overlayApply.find("g_overlayCameraArea =") < overlayApply.find("return;") &&
        overlayApply.contains("g_overlayFocusedIds[bcn::overlay::Index(row.area)] = row.entry ? row.entry->id : std::string{};"));
    Require(!overlayApply.contains("bcn::overlay::QueueCancelPreviews(actor)") &&
        overlayApply.find("return;") < overlayApply.find("bcn::overlay::QueueApply(actor") &&
        !overlayApply.contains("g_overlayColorDrafts.Clear()"));
    const auto syncBegin = uiSource.find("void SyncDistributionOverlayPreviews()");
    const auto syncEnd = uiSource.find("void RememberPending", syncBegin);
    Require(syncBegin != std::string::npos && syncEnd != std::string::npos);
    const auto sync = std::string_view(uiSource).substr(syncBegin, syncEnd - syncBegin);
    Require(sync.contains("g_distributionSelectedOverlayIds[index]") &&
        sync.contains("QueuePreviewSet(actor, area, std::move(checked))") &&
        !sync.contains("QueueApply(") && !sync.contains("SetOverlayColor("));
    Require(overlayRows.contains("applyRow(rows[navigation.focused], navigation.confirm)") &&
        uiSource.contains("SetOverlayFocus(g_overlayCameraArea)") &&
        !uiSource.contains("SetOverlayFocus(g_overlayArea)") &&
        uiSource.contains("g_overlayCameraArea.reset();"));
    Require(overlayRows.contains("const auto commit = confirm && !distributionSelecting;") &&
        overlayRows.contains("if (commit) pending.reset();") &&
        overlayRows.contains("applyRow(overlayRow, false);") &&
        overlayRows.contains("SetDistributionOverlaySelected(row.area, row.entry->id,"));
    Require(uiSource.contains("rule.overlayColors[index] = g_overlayColorDrafts.CopySelection"));
    const auto closeBegin = uiSource.find("void OnClosed()");
    const auto closeEnd = uiSource.find("void Notify(", closeBegin);
    Require(closeBegin != std::string::npos && closeEnd != std::string::npos);
    const auto closeBody = std::string_view(uiSource).substr(closeBegin, closeEnd - closeBegin);
    Require(closeBody.contains("RollbackPendingSelections(SelectedActor())"));
    Require(closeBody.contains("if (currentSession) RollbackPendingSelections") &&
        closeBody.find("RollbackPendingSelections") < closeBody.find("ResetDistributionSelectionSession()") &&
        closeBody.contains("ResetDistributionEditor()"));
    Require(closeBody.contains("DiscardDistributionDraft()") &&
        !uiSource.contains("SaveDistributionDraft"));
    const auto popupStart = uiSource.find("void DrawDistributionPopup()");
    const auto closeEditorStart = uiSource.find("const auto closeEditor", popupStart);
    const auto closeEditorEnd = uiSource.find("if (!g_distributionItemDraft", closeEditorStart);
    const auto closeEditor = std::string_view(uiSource).substr(closeEditorStart,
        closeEditorEnd - closeEditorStart);
    Require(closeEditor.contains("DiscardDistributionDraft()") && !closeEditor.contains("Save"));
    const auto immediateStart = uiSource.find("bool SaveActiveDistributionRules()");
    const auto immediateEnd = uiSource.find("void DiscardDistributionDraft", immediateStart);
    const auto immediate = std::string_view(uiSource).substr(immediateStart, immediateEnd - immediateStart);
    Require(immediate.find("SaveRulesForNextGame") < immediate.find("SetRules(") &&
        immediate.contains("return false"));
    Require(uiSource.contains("SavedRulesSnapshot()") &&
        uiSource.contains("더블클릭 복수 적용/해제") && uiSource.contains("\"적용\", \"Applied\""));
    Require(!uiSource.contains("더블클릭으로") && uiSource.contains("FittedDisabledLine(help)"));
    Require(uiSource.contains("Reads installed mods. (Double-click to apply/remove multiple)"));
    Require(uiSource.contains("CalienteTools\\\\~에서 바디프리셋을 읽습니다.(더블클릭 적용)") &&
        uiSource.contains("Futanari\\\\<스킨명>\\\\Textures\\\\~ 에서 후타스킨을 읽습니다.(더블클릭 적용)") &&
        !uiSource.contains("usage.managed") && uiSource.contains("usage.applied, usage.capacity"));
    const auto discardBegin = uiSource.find("void DiscardDistributionDraft()");
    const auto discardEnd = uiSource.find("const char* OverlayAreaLabel", discardBegin);
    const auto discardBody = std::string_view(uiSource).substr(discardBegin, discardEnd-discardBegin);
    Require(discardBody.contains("SavedRulesSnapshot()") && !discardBody.contains("SaveRulesForNextGame") &&
        !discardBody.contains("SetRules(") && !discardBody.contains("RefreshDistributionTargetOptions"));
    Require(!uiSource.contains("CommitPendingSelections"));
    Require(uiSource.contains("ImGuiKey_W") && uiSource.contains("ImGuiKey_S") &&
        uiSource.contains("ImGuiKey_A") && uiSource.contains("ImGuiKey_D") &&
        uiSource.contains("native_ui::ActivatePressed()") && uiSource.contains("ImGuiKey_Enter") &&
        uiSource.contains("ImGuiKey_GamepadDpadUp") &&
        uiSource.contains("ImGuiKey_GamepadDpadDown") &&
        uiSource.contains("ImGuiKey_GamepadDpadLeft") &&
        uiSource.contains("ImGuiKey_GamepadDpadRight") &&
        uiSource.contains("native_ui::CancelPressed()"));
    Require(uiSource.contains("g_pendingFutanari") && uiSource.contains("g_pendingTintBaseline"));
    Require(uiSource.contains("SkinProfiles::Get().RefreshAsync()"));
    Require(uiSource.contains("overlay::RefreshCatalog(actor)"));
    Require(uiSource.contains("Reads body skins from BodySkin\\\\<skin pack>\\\\textures\\\\~. (Double-click to apply)"));
    Require(uiSource.contains("Reads tint masks from BodySkin\\\\<skin pack>\\\\textures\\\\~. (Double-click to apply)"));
    Require(uiSource.contains("Rotate: right-mouse drag / LT+RS left/right") &&
        uiSource.contains("bcn::ui_text::TitleBarRightHint(\"Body Change NG\", hint)") &&
        uiSource.contains("DrawTitleBarRotationHint();") &&
        !uiSource.contains("if (x <= titleEnd) return;") &&
        !uiSource.contains("ImGui::TextDisabled(\"%s\", Text(\n            \"캐릭터 회전"));
    Require(uiSource.contains("DrawCatalogCommandRow(DistributionPool::body") &&
        uiSource.contains("DrawCatalogCommandRow(DistributionPool::skin") &&
        uiSource.contains("DrawCatalogCommandRow(DistributionPool::overlay") &&
        uiSource.contains("DrawCatalogCommandRow(DistributionPool::futanari") &&
        uiSource.contains("\"배포 하기\", \"Distribute\"") &&
        uiSource.contains("Cancel distribution") &&
        uiSource.contains("Exclude custom followers") &&
        uiSource.contains("Exclude elder NPCs") &&
        uiSource.contains("return Text(\"이름\", \"Name\", \"名称\")") &&
        !uiSource.contains("이름이 같은 NPC") &&
        !uiSource.contains("ImportOBodyDefaults") &&
        !uiSource.contains("Load saved values") &&
        !uiSource.contains("배포 제외"));

    const auto openDistribution = uiSource.find("void OpenDistributionEditorFromCatalog()");
    const auto commandRow = uiSource.find("void DrawCatalogCommandRow", openDistribution);
    Require(openDistribution != std::string::npos && commandRow != std::string::npos);
    const auto commands = std::string_view(uiSource).substr(commandRow,
        uiSource.find("void FillRuleTargetFromSelectedActor", commandRow) - commandRow);
    Require(commands.find("SelectDistributionSex(true)") < commands.find("SelectDistributionSex(false)") &&
        commands.find("SelectDistributionSex(false)") < commands.find("\"Distribute\"") &&
        commands.find("\"Distribute\"") < commands.find("\"Cancel distribution\"") &&
        commands.contains("ImGui::BeginDisabled(pool == DistributionPool::futanari)"));
    const auto switchSexStart = uiSource.find("void SelectDistributionSex(");
    const auto switchSexEnd = uiSource.find("void BeginDistributionCatalogSelection", switchSexStart);
    const auto switchSex = std::string_view(uiSource).substr(switchSexStart, switchSexEnd - switchSexStart);
    Require(switchSex.contains("RollbackPendingSelections(SelectedActor())") &&
        switchSex.contains("if (g_distributionFemale != female) ClearDistributionCatalogSelection()") &&
        switchSex.contains("catalog.Refresh()") && switchSex.contains("NearestDistributionActor") &&
        switchSex.contains("ui_catalog::HumanElfPreviewRace") && switchSex.contains("HasKeywordString(\"ActorTypeNPC\")") &&
        switchSex.contains("!bcn::IsCustomFollowerActor(candidate)") &&
        switchSex.contains("!bcn::IsElderActor(candidate->GetActorBase())") &&
        switchSex.contains("futanari_support::RegisteredType(candidate).has_value()") &&
        switchSex.contains("SelectActor(target)") && switchSex.contains("++g_distributionCatalogRevision"));
    const auto newRuleStart = uiSource.find("bcn::DistributionRule NewDistributionRule()");
    const auto newRule = std::string_view(uiSource).substr(newRuleStart,
        uiSource.find("const char* DistributionPoolLabel", newRuleStart) - newRuleStart);
    Require(newRule.contains("const auto female = g_distributionFemale") &&
        !newRule.contains("SelectedActor()"));
    Require(uiSource.contains("const auto selectedMale = distributionSelecting ? !g_distributionFemale : actorMale") &&
        uiSource.contains("preset.male == actorMale &&") &&
        uiSource.contains("bcn::body_family::Matches(presetMask, DistributionCatalogFamily(settings))") &&
        uiSource.contains("DistributionCatalogFamily(settings)).Compatible()") &&
        uiSource.contains("SnapshotLegacy(area, female)") &&
        uiSource.contains("(base->GetSex() == RE::SEX::kFemale) != g_distributionFemale") &&
        uiSource.contains("catalogRevision == g_distributionCatalogRevision"));
    const auto openDistributionBody = std::string_view(uiSource).substr(
        openDistribution, uiSource.find("void OpenDistributionConditions", openDistribution) - openDistribution);
    Require(openDistributionBody.contains("SetRuleDistributionSelection(rule)") &&
        !openDistributionBody.contains("ClearDistributionCatalogSelection()"));
    const auto addRuleBegin = uiSource.find("+ Add rule");
    const auto deleteRuleBegin = uiSource.find("- Delete rule", addRuleBegin);
    Require(addRuleBegin != std::string::npos && deleteRuleBegin != std::string::npos);
    const auto addRuleBody = std::string_view(uiSource).substr(
        addRuleBegin, deleteRuleBegin - addRuleBegin);
    Require(addRuleBody.contains("if (rule.female == g_distributionFemale) SetRuleDistributionSelection(rule)") &&
        addRuleBody.contains("g_distributionRuleTabs.Remember(rule, g_distributionPool)") &&
        !addRuleBody.contains("source.presetIds") &&
        !addRuleBody.contains("source.skinProfileIds"));
    const auto directOpenStart = uiSource.find("void OpenDistributionConditions(");
    const auto directOpenBody = std::string_view(uiSource).substr(directOpenStart, commandRow - directOpenStart);
    Require(directOpenStart != std::string::npos &&
        !directOpenBody.contains("NewDistributionRule") &&
        !directOpenBody.contains("push_back") && directOpenBody.contains("EnsureDistributionEditor()"));
    Require(commands.contains("OpenDistributionConditions(pool)") &&
        uiSource.contains("DrawDistributionItemPopup();") &&
        uiSource.contains("!g_distributionItemDraft && bcn::popup_placement::CanConsumeCancel() && EscapePressed()") &&
        uiSource.contains("prefix + \" · \" + rule.name"));
    Require(uiSource.contains("SameLine(ImGui::GetWindowContentRegionMax().x - closeWidth)"));
    Require(uiSource.contains("File path: Data\\\\SKSE\\\\Plugins\\\\OBody_presetDistributionConfig.json"));
    Require(uiSource.contains("선택 액터 설정 값 초기화") &&
        uiSource.contains("전체 액터 설정 값 초기화") &&
        uiSource.contains("actor_settings_reset::QueueActor(SelectedActor())") &&
        uiSource.contains("actor_settings_reset::QueueAll()") &&
        !uiSource.contains("선택 액터 바디 모프 초기화") &&
        !uiSource.contains("전체 배포 바디 결과 초기화"));
    Require(uiSource.find("RightAlignedButton(Text(\"완료\", \"Done\", \"完成\"))") !=
        uiSource.rfind("RightAlignedButton(Text(\"완료\", \"Done\", \"完成\"))"));

    std::ifstream distributionHeaderFile(std::filesystem::path("src") / "BodyChangeNG" /
        "Distribution.h", std::ios::binary);
    Require(distributionHeaderFile.good());
    const std::string distributionHeader((std::istreambuf_iterator<char>(distributionHeaderFile)), {});
    const auto readFeatureSource = [](const char* name) {
        std::ifstream file(std::filesystem::path("src") / "BodyChangeNG" / name, std::ios::binary);
        Require(file.good());
        return std::string((std::istreambuf_iterator<char>(file)), {});
    };
    const auto distributionSource = readFeatureSource("Distribution.cpp");
    const auto manualSkinStart = distributionSource.find("skin_application::QueueApply(actor, manual->skinId");
    const auto automaticSkinStart = distributionSource.find("skin_application::QueueApply(actor, automaticSkin->selectedId)");
    Require(manualSkinStart != std::string::npos && automaticSkinStart > manualSkinStart);
    Require(std::string_view(distributionSource).substr(manualSkinStart,
        automaticSkinStart - manualSkinStart).contains("skin_transaction::Selection::direct"));
    Require(readFeatureSource("SkinProfiles.cpp").contains(
        "SkinProfileCompatibility(*found, sex, actorRace, actorFamily).Compatible()"));
    const auto directSkinStart = uiSource.find("void DrawSkinCatalog()");
    const auto directSkinEnd = uiSource.find("void DrawOverlayCatalog()", directSkinStart);
    Require(directSkinStart != std::string::npos && directSkinEnd != std::string::npos);
    const auto directSkin = std::string_view(uiSource).substr(directSkinStart, directSkinEnd - directSkinStart);
    Require(directSkin.contains("Selection::direct") && directSkin.contains("SaveManualSkinIfNeeded(actor, skin.id)") &&
        directSkin.contains("No distribution rules needed.") && directSkin.contains("Mode::preview"));
    Require(distributionSource.contains("return IsCustomFollower(actor, actor ? actor->GetActorBase() : nullptr)"));
    const auto actorCatalogSource = readFeatureSource("ActorCatalog.cpp");
    const auto searchStart = actorCatalogSource.find("void SearchStep(");
    const auto searchEnd = actorCatalogSource.find("void ActorCatalog::Search(", searchStart);
    Require(searchStart != std::string::npos && searchEnd != std::string::npos);
    const auto searchCode = std::string_view(actorCatalogSource).substr(searchStart, searchEnd - searchStart);
    Require(searchCode.contains("RE::FormType::ActorCharacter") && searchCode.contains("job->next + 256U") &&
        searchCode.contains("job->generation != g_searchGeneration") &&
        searchCode.contains("IsCurrent(job->epoch)") && searchCode.contains("std::make_shared<const std::vector"));
    Require(!searchCode.contains("Is3DLoaded") && !searchCode.contains("kNearbyActorRadius") &&
        !searchCode.contains("MoveTo") && !searchCode.contains("QueueNiNodeUpdate"));
    Require(readFeatureSource("RaceMenuBodyMorph.cpp").contains(
        "if (!actor->Is3DLoaded()) return mode == ApplyMode::commit ?"));
    Require(readFeatureSource("SkinApplication.cpp").contains(
        "if (actor && !actor->Is3DLoaded() && !skin_transaction::RestoresPreview(mode)) return result;"));
    Require(!actorCatalogSource.contains("IsCustomFollowerActor") &&
        !actorCatalogSource.contains("IsElderActor"));
    Require(!actorCatalogSource.contains("IsHostileToActor") &&
        !actorCatalogSource.contains("IsInCombat"));
    Require(actorCatalogSource.contains("!actor->IsDisabled() && actor->Is3DLoaded() && !actor->IsDead()") &&
        actorCatalogSource.contains("HasMeaningfulName(actor)") &&
        actorCatalogSource.contains("actor->IsPlayerTeammate() || actor->HasKeywordString(\"ActorTypeNPC\")") &&
        actorCatalogSource.contains("kNearbyActorRadius = 4096.0F") &&
        actorCatalogSource.contains("kMaximumNearbyActors = 32") &&
        actorCatalogSource.contains("seen.insert(actor->GetFormID())"));
    const auto refreshStart = distributionSource.find("void Distribution::RefreshFutanariSelection(");
    const auto refreshEnd = distributionSource.find("bool Distribution::ApplyActor(", refreshStart);
    Require(refreshStart != std::string::npos && refreshEnd != std::string::npos);
    const auto futaRefresh = std::string_view(distributionSource).substr(refreshStart, refreshEnd - refreshStart);
    Require(futaRefresh.contains("IsEligibleNPC(actor, RE::PlayerCharacter::GetSingleton())") &&
        futaRefresh.contains("frame_tasks::HasPreview") && futaRefresh.contains("previous->futanari.manual") &&
        futaRefresh.contains("ChooseFutanariRule") && futaRefresh.contains("SetAutomaticFutanariSkin") &&
        !futaRefresh.contains("SetRuleSelection") && !futaRefresh.contains("QueueApply") &&
        !futaRefresh.contains("SetManual"));
    Require(distributionSource.contains("rule.scope == bcn::DistributionScope::allNPCs &&\n            !bcn::MatchesDistributionScopeFilters") ||
        distributionSource.contains("rule.scope == bcn::DistributionScope::allNPCs &&\r\n            !bcn::MatchesDistributionScopeFilters"));
    Require(distributionSource.contains("!rule.includeChildNPCs && actor->IsChild()") &&
        distributionSource.contains(".includeChildNPCs = source.value(\"includeChildNPCs\", false)"));
    const auto skinApplicationSource = readFeatureSource("SkinApplication.cpp");
    const auto futanariSupportSource = readFeatureSource("FutanariSupport.cpp");
    const auto targetResolverSource = readFeatureSource("SkinTargetResolver.cpp");
    const auto nativeAddonSource = readFeatureSource("NativeAddonSkinBackend.cpp");
    Require(futanariSupportSource.contains("futanari::GenitalSlots(kind,") &&
        futanariSupportSource.contains("futanari::IsAddonFaction(addon.kind") &&
        futanariSupportSource.contains("addon.plugin == plugin") &&
        targetResolverSource.contains("futanari::GenitalSlots(modelKind,") &&
        targetResolverSource.contains("FutanariSkinTypeForAddon(result.addonKind") &&
        nativeAddonSource.contains("IsCandidateSlotIndex(context->index)") &&
        nativeAddonSource.contains("parts[context->index]") &&
        nativeAddonSource.contains("AcceptGenitalSlot(context->index, slots, channel, kind)") &&
        nativeAddonSource.contains("AcceptGenitalSlot(24, slots, channel, kind)") &&
        !nativeAddonSource.contains("parts[22]") &&
        skinApplicationSource.contains("female ? bcn::futanari::kSlot54 : 0U"));
    Require(futaSelection.contains("IsUbeFutanariSkinType(profile.type)") &&
        distributionSource.contains("IsUbeFutanariSkinType(*type)"));
    const auto reapplyStart = skinApplicationSource.find("void QueueReapplyCurrentFutanari(");
    const auto reapplyEnd = skinApplicationSource.find("void InvalidateFutanariDetection(", reapplyStart);
    Require(reapplyStart != std::string::npos && reapplyEnd != std::string::npos);
    const auto futaReapply = std::string_view(skinApplicationSource).substr(reapplyStart, reapplyEnd - reapplyStart);
    Require(futaReapply.find("RefreshFutanariSelection(actor)") < futaReapply.find("CurrentFutanariProfileId(actor)") &&
        futaReapply.contains("FutanariSelectionSignature") && futaReapply.contains("frame_tasks::HasPreview") &&
        !futaReapply.contains("Distribution::Get().ApplyActor"));
    Require(skinApplicationSource.find("bcn::skin_session::FutanariSelectionSignature(") < reapplyStart);
    const auto bodyItemsSource = uiSection("std::vector<CatalogItem> BodyItems()", "RE::Actor* SelectedActor()");
    Require(bodyItemsSource.contains("PresetCatalog::Get().ListSnapshot()") &&
        !bodyItemsSource.contains("PresetCatalog::Get().Snapshot()"));
    Require(!bodyItemsSource.contains("Family::ube")); // No unconditional UBE exclusion.
    const auto worldDistributionHeader = uiSection("if (g_distributionSelectionMode || g_showDistribution)",
        "const auto* selectedActor = SelectedActor();");
    const auto actorBranch = worldDistributionHeader.find("} else {");
    Require(actorBranch != std::string_view::npos &&
        worldDistributionHeader.substr(0, actorBranch).contains("Distribute selected items to world NPCs within a chosen scope") &&
        !worldDistributionHeader.substr(0, actorBranch).contains("BeginCombo") &&
        worldDistributionHeader.find("ImGui::BeginCombo(\"##actor\"") > actorBranch &&
        worldDistributionHeader.find("ImGui::Button(refreshActorsLabel)") > actorBranch &&
        worldDistributionHeader.contains("ImGui::Button(outfitLabel)") &&
        worldDistributionHeader.contains("ImGui::Button(settingsLabel)"));
    const auto bodyRowsSource = uiSection("void DrawCatalog(", "void DrawSkinCatalog()");
    Require(bodyRowsSource.contains("ImGuiListClipper") && bodyRowsSource.contains("IncludeItemByIndex") &&
        bodyRowsSource.contains("Scaled(53.0F) + ImGui::GetStyle().ItemSpacing.y"));
    const auto mouseHostSource = readFeatureSource("NativeImGuiHost.cpp");
    Require(mouseHostSource.contains("RemoveBackendMousePositions(firstBackendEvent)") &&
        mouseHostSource.contains("g_mouseInput.Drain(io, CurrentMousePosition())") &&
        !mouseHostSource.contains("ImGui_ImplWin32_WndProcHandler(window"));
    const auto mouseFilter = readFeatureSource("TextInputFilter.cpp");
    Require(mouseFilter.find("SubmitGameMouseButton(buttonID, button->IsDown(), button->IsUp())") <
        mouseFilter.find("if (buttonID != kRightMouseButton)"));
    Require(mouseHostSource.contains("g_mouseInput.GameButton(button, down, up)") &&
        !mouseHostSource.contains("QueueWindowButton") && !mouseHostSource.contains("g_rightMouseState") &&
        !mouseHostSource.contains("g_mouseWheelSteps"));
    const auto faceNoOpSource = readFeatureSource("FaceSkinOverrides.cpp");
    Require(faceNoOpSource.contains("CanKeepVisibleTexture(desired, property, name,") &&
        faceNoOpSource.contains("!firstHead || firstHead == thirdHead") &&
        faceNoOpSource.contains("texture && texture->rendererTexture, self->persistent, current"));
    const auto registrySource = readFeatureSource("ActorRegistry.cpp");
    const auto bodyVerifyBegin = registrySource.find("bool ActorRegistry::NeedsBodyApply(");
    const auto bodyVerifyEnd = registrySource.find("bool ActorRegistry::NeedsSkinApply(", bodyVerifyBegin);
    Require(bodyVerifyBegin != std::string::npos && bodyVerifyEnd != std::string::npos);
    const auto bodyVerifySource = std::string_view(registrySource).substr(bodyVerifyBegin, bodyVerifyEnd - bodyVerifyBegin);
    Require(bodyVerifySource.contains("EvaluateLiveBodyApplication") &&
        !bodyVerifySource.contains("if (state->body.application.verifiedThisSession) return false"));
    const auto actorEventsSource = readFeatureSource("ActorEvents.cpp");
    Require(actorEventsSource.contains("racemenu::QueueVerifySavedBody(actor)"));
    Require(actorEventsSource.contains("(tracked || futanari_support::Available())") &&
        actorEventsSource.contains("!mayRegisterFutanari") &&
        actorEventsSource.contains("appearance::WorkChannel::equipmentVerify"));
    Require(!distributionHeader.contains("bodyExcluded") &&
        !distributionHeader.contains("skinExcluded") &&
        !distributionHeader.contains("overlayExcluded") &&
        !distributionHeader.contains("bool excluded"));
    std::ifstream packagedRulesFile(std::filesystem::path("package") / "SKSE" /
        "Plugins" / "BodyChangeNGdistribution.json", std::ios::binary);
    Require(packagedRulesFile.good());
    const std::string packagedRules((std::istreambuf_iterator<char>(packagedRulesFile)), {});
    Require(packagedRules.contains("\"schemaVersion\": 8") &&
        packagedRules.contains("\"rules\": [") &&
        packagedRules.contains("/* EXAMPLE: individual_body") &&
        !packagedRules.contains("Excluded") &&
        !packagedRules.contains("excluded"));
    Require(readFeatureSource("Distribution.cpp").contains("distribution_json::Read(sourcePath.path)"));
    std::ifstream packageScriptFile(std::filesystem::path("scripts") /
        "Package-Release.ps1", std::ios::binary);
    Require(packageScriptFile.good());
    const std::string packageScript((std::istreambuf_iterator<char>(packageScriptFile)), {});
    Require(packageScript.contains("schemaVersion -ne 8") &&
        packageScript.contains("rules.Count -ne 0") &&
        !packageScript.contains("default-exclude-") &&
        !packageScript.contains("TintMask/README.txt"));

    const auto skinCatalog = uiSource.find("void DrawSkinCatalog()");
    const auto skinPreview = uiSource.find("const auto previewRow", skinCatalog);
    const auto skinConfirm = uiSource.find("const auto confirmRow", skinPreview);
    Require(skinCatalog != std::string::npos && skinPreview != std::string::npos &&
        skinConfirm != std::string::npos);
    const auto skinPreviewBody = std::string_view(uiSource).substr(
        skinPreview, skinConfirm - skinPreview);
    Require(skinPreviewBody.contains("QueueDefaultSkin(false)"));
    Require(skinPreviewBody.contains("skin_transaction::Mode::preview"));
    Require(!skinPreviewBody.contains("SaveManualSkinIfNeeded"));
    Require(uiSource.contains("QueuePreviewDefault(actor)"));
    const auto manualSkinHelper = uiSource.find("void SaveManualSkinIfNeeded");
    const auto manualDefaultBodyHelper = uiSource.find("void SaveManualDefaultBodyIfNeeded", manualSkinHelper);
    const auto manualDefaultSkinHelper = uiSource.find("void SaveManualDefaultSkinIfNeeded", manualDefaultBodyHelper);
    const auto pendingHelper = uiSource.find("void RememberPending", manualDefaultSkinHelper);
    Require(manualSkinHelper != std::string::npos && manualDefaultBodyHelper != std::string::npos &&
        manualDefaultSkinHelper != std::string::npos && pendingHelper != std::string::npos);
    const auto manualPersistenceHelpers = std::string_view(uiSource).substr(
        manualSkinHelper, pendingHelper - manualSkinHelper);
    Require(!manualPersistenceHelpers.contains("actor == player") &&
        manualPersistenceHelpers.contains("SetManualSkinAssignment") &&
        manualPersistenceHelpers.contains("SetManualDefaultBody") &&
        manualPersistenceHelpers.contains("SetManualDefaultSkin"));

    const auto mainTabs = uiSource.find("HandleTabNavigation(playerSelected, futanariAvailable)");
    Require(!uiSource.contains("선택 액터 적용 중") &&
        !uiSource.contains("Applying to selected actor") &&
        !uiSource.contains("선택 액터 적용 대기 중"));
    const auto bodyTab = uiSource.find("TabButton(Text(\"바디프리셋\"", mainTabs);
    const auto skinTab = uiSource.find("TabButton(Text(\"바디스킨\"", bodyTab);
    const auto tintTab = uiSource.find("TabButton(Text(\"틴트마스크\"", skinTab);
    const auto futanariTab = uiSource.find("TabButton(Text(\"후타스킨\"", tintTab);
    const auto overlayTab = uiSource.find("TabButton(Text(\"오버레이\"", futanariTab);
    Require(mainTabs != std::string::npos && bodyTab < skinTab && skinTab < tintTab &&
        tintTab < futanariTab && futanariTab < overlayTab);

    const auto overlayCatalogUi = uiSource.find("void DrawOverlayCatalog()");
    const auto futanariCatalogUi = uiSource.find("void DrawFutanariCatalog()", overlayCatalogUi);
    Require(overlayCatalogUi != std::string::npos && futanariCatalogUi != std::string::npos);
    const auto futanariCatalogEnd = uiSource.find("void DrawPlayerTintCatalog()", futanariCatalogUi);
    const auto futanariDistributionMode = uiSource.find(
        "const auto distributionSelecting = IsDistributionSelectionFor(DistributionPool::futanari)",
        futanariCatalogUi);
    const auto futanariCommandRow = uiSource.find(
        "DrawCatalogCommandRow(DistributionPool::futanari", futanariDistributionMode);
    const auto futanariActorRejection = uiSource.find(
        "if (!distributionSelecting && !actorType)", futanariCommandRow);
    Require(futanariCatalogEnd != std::string::npos &&
        futanariDistributionMode < futanariCommandRow &&
        futanariCommandRow < futanariActorRejection &&
        futanariActorRejection < futanariCatalogEnd);
    const auto overlayCatalogBody = std::string_view(uiSource).substr(
        overlayCatalogUi, futanariCatalogUi - overlayCatalogUi);
    Require(overlayCatalogBody.contains("ImGui::TreeNodeEx") &&
        overlayCatalogBody.contains("g_overlaySectionsOpen") &&
        overlayCatalogBody.contains("ImGuiListClipper") &&
        overlayCatalogBody.contains("Face Paint") &&
        overlayCatalogBody.contains("Body Paint") &&
        overlayCatalogBody.contains("Hand Paint") &&
        overlayCatalogBody.contains("Feet Paint") &&
        overlayCatalogBody.contains("EllipsizeText(subtitle, subtitleWidth)") &&
        overlayCatalogBody.contains("renderedRowBottom") &&
        overlayCatalogBody.contains("sectionCursor") &&
        !overlayCatalogBody.contains("← Areas") &&
        !overlayCatalogBody.contains("← 부위 선택"));
    const auto overlayCatalogEndChild = overlayCatalogBody.rfind("ImGui::EndChild()");
    const auto overlayFixedColor = overlayCatalogBody.rfind(
        "const auto color = bcn::overlay::CurrentColor(actor, colorArea, colorEntryId)");
    Require(overlayCatalogEndChild != std::string_view::npos &&
        overlayFixedColor != std::string_view::npos &&
        overlayFixedColor > overlayCatalogEndChild &&
        overlayCatalogBody.contains("Color area"));
    Require(!uiSource.contains("틴트마스크 방식만 호환되며") &&
        !uiSource.contains("Only the tint-mask method is compatible"));
    Require(uiSource.contains("CenteredCheckbox(\"##distributionSelected\"") &&
        uiSource.contains("ImGui::AlignTextToFramePadding();"));

    std::ifstream overlayFile(std::filesystem::path("src") / "BodyChangeNG" /
        "RaceMenuOverlay.cpp", std::ios::binary);
    Require(overlayFile.good());
    const std::string overlaySource((std::istreambuf_iterator<char>(overlayFile)), {});
    const auto freeBegin = overlaySource.find("bool NodeIsFree(");
    const auto freeEnd = overlaySource.find("bool LiveNodeMatches(", freeBegin);
    Require(freeBegin != std::string::npos && freeEnd != std::string::npos);
    const auto freeBody = std::string_view(overlaySource).substr(freeBegin, freeEnd - freeBegin);
    // Releasing SlaveTats' live blank DDS must not bypass any registered
    // texture/tint/alpha reservation, or ignore the other loaded camera view.
    Require(freeBody.contains("index < 8U") &&
        freeBody.contains("bcn::overlay::kTextureKey, index)) return false;") &&
        freeBody.contains("bcn::overlay::kTintKey, bcn::overlay::kScalarIndex)") &&
        freeBody.contains("bcn::overlay::kAlphaKey, bcn::overlay::kScalarIndex)) return false;") &&
        freeBody.contains("for (const bool firstPerson : { false, true })") &&
        freeBody.contains("CanClaimNode(false, diffuse)"));
    Require(overlaySource.contains("accounting.Observe(!NodeIsFree(interfaces, actor, female, *node)") &&
        overlaySource.contains("if (node && NodeIsFree(interfaces, actor, female, *node))"));
    const auto colorBegin = overlaySource.find("ApplyResult QueueColor(");
    const auto colorEnd = overlaySource.find("ApplyResult QueueClear(", colorBegin);
    Require(colorBegin != std::string::npos && colorEnd != std::string::npos);
    const auto colorBody = std::string_view(overlaySource).substr(
        colorBegin, colorEnd - colorBegin);
    Require(colorBody.contains("coloringPreview") &&
        colorBody.contains("StorePreview") &&
        colorBody.contains("coloringPreview ? ApplyMode::preview") &&
        colorBody.contains("ColorOwnedNode") &&
        colorBody.contains("if (preview && preview->batchMode) return;") &&
        !colorBody.contains("previewOnly") && !colorBody.contains("return QueueApply("));
    const auto nodeColorBegin = overlaySource.find("bool ColorOwnedNode(");
    const auto nodeColorEnd = overlaySource.find("void RemovePreviewItemValue(", nodeColorBegin);
    Require(nodeColorBegin != std::string::npos && nodeColorEnd != std::string::npos);
    const auto nodeColorBody = std::string_view(overlaySource).substr(nodeColorBegin, nodeColorEnd - nodeColorBegin);
    Require(nodeColorBody.contains("NodeOwnedBySelection") &&
        nodeColorBody.contains("OverlayStackAbi::legacyV1") &&
        nodeColorBody.contains("SetNodeProperty") &&
        !nodeColorBody.contains("ApplyNow(") && !nodeColorBody.contains("ActorRegistry::"));
    const auto removePreviewEnd = overlaySource.find("bcn::overlay::ApplyResult RemoveOneNow", nodeColorEnd);
    const auto removePreviewBody = std::string_view(overlaySource).substr(nodeColorEnd, removePreviewEnd - nodeColorEnd);
    Require(removePreviewBody.find("preview.BorrowedSelection(value, committed)") <
        removePreviewBody.find("RemoveExactOwnedOverlay"));
    Require(removePreviewBody.contains("preview.VisitLive(") &&
        overlaySource.contains("ReconcilePreviewItems(next.batch, desired") &&
        overlaySource.contains("wanted.color, reserved)") &&
        overlaySource.contains("auto previous = PreviewFor(actor->GetFormID(), area)"));

    std::ifstream presentationFile(std::filesystem::path("src") / "BodyChangeNG" /
        "MenuCharacterPresentation.cpp", std::ios::binary);
    Require(presentationFile.good());
    const std::string presentationSource((std::istreambuf_iterator<char>(presentationFile)), {});
    const auto rotationBegin = presentationSource.find("void Presentation::UpdateRotationInteraction()");
    Require(rotationBegin != std::string::npos);
    const auto rotationBody = std::string_view(presentationSource).substr(rotationBegin);
    Require(rotationBody.contains("ImGuiKey_GamepadL2") &&
        rotationBody.contains("ImGuiKey_GamepadRStickLeft") &&
        rotationBody.contains("ImGuiKey_GamepadRStickRight") &&
        rotationBody.contains("leftTrigger >= kGamepadTriggerThreshold") &&
        rotationBody.contains("std::clamp(io.DeltaTime, 0.0F, 0.05F)"));

    std::ifstream inputFilterFile(std::filesystem::path("src") / "BodyChangeNG" /
        "TextInputFilter.cpp", std::ios::binary);
    Require(inputFilterFile.good());
    const std::string inputFilterSource((std::istreambuf_iterator<char>(inputFilterFile)), {});
    Require(inputFilterSource.contains("kMenuNavigationButtons") &&
        inputFilterSource.contains("SubmitMenuNavigationKey(scanCode, !release)") &&
        inputFilterSource.contains("g_preMenuNavigationButtons") &&
        inputFilterSource.contains("g_swallowedMenuNavigationUntilReleaseButtons") &&
        inputFilterSource.contains("*link = event->next"));
    Require(inputFilterSource.contains("GetMappedKey(\"Activate\", device") &&
        inputFilterSource.contains("GetMappedKey(\"Cancel\", device") &&
        inputFilterSource.contains("bindingsFor(RE::INPUT_DEVICE::kKeyboard)") &&
        inputFilterSource.contains("bindingsFor(RE::INPUT_DEVICE::kGamepad)"));
    const auto navigationStart = uiSource.find("CatalogNavigationCommand HandleCatalogNavigation");
    const auto navigationEnd = uiSource.find("void FocusCatalogRow", navigationStart);
    const auto navigationSource = std::string_view(uiSource).substr(navigationStart,
        navigationEnd - navigationStart);
    Require(navigationSource.contains("native_ui::ActivatePressed()") &&
        !navigationSource.contains("ImGuiKey_E,") &&
        !navigationSource.contains("ImGuiKey_Space") &&
        !navigationSource.contains("ImGuiKey_GamepadFaceDown"));
    Require(uiSource.contains("native_ui::CancelPressed()") &&
        !uiSource.contains("ImGuiKey_GamepadFaceRight"));
    Require(uiSource.contains("!g_showOverlayDetails && bcn::popup_placement::CanConsumeCancel() && EscapePressed()") &&
        uiSource.contains("Kind::removalConfirmation") &&
        uiSource.contains("skinSnapshot = bcn::SkinProfiles::Get().SharedSnapshot()") &&
        uiSource.contains("profileSnapshot = bcn::FutanariSkinProfiles::Get().SharedSnapshot()") &&
        uiSource.contains("assetSnapshot = bcn::player_tint::Catalog::Get().SharedSnapshot()") &&
        !uiSource.contains("std::unordered_set<std::string> texturePaths"));

    std::ifstream catalogFile(std::filesystem::path("src") / "BodyChangeNG" /
        "OverlayCatalog.cpp", std::ios::binary);
    Require(catalogFile.good());
    const std::string catalogSource((std::istreambuf_iterator<char>(catalogFile)), {});
    Require(catalogSource.contains("g_catalogSettled") &&
        catalogSource.contains("g_slaveTatsLoaded") &&
        catalogSource.contains("BeginCatalogRequest(target, false)") &&
        catalogSource.contains("BeginCatalogRequest(target, true)"));

    std::ifstream profilesFile(std::filesystem::path("src") / "BodyChangeNG" /
        "SkinProfiles.cpp", std::ios::binary);
    Require(profilesFile.good());
    const std::string profilesSource((std::istreambuf_iterator<char>(profilesFile)), {});
    Require(profilesSource.contains("bool SkinProfiles::RefreshAsync()") &&
        profilesSource.contains("catalog_refresh::Get().Submit(this") &&
        profilesSource.contains("refreshing_.exchange"));

    std::ifstream assetCacheFile(std::filesystem::path("src") / "BodyChangeNG" /
        "RuntimeAssetCache.cpp", std::ios::binary);
    Require(assetCacheFile.good());
    const std::string assetCacheSource((std::istreambuf_iterator<char>(assetCacheFile)), {});
    const auto registerBegin = assetCacheSource.find("void RegisterGameRelativeSource(");
    const auto registerEnd = assetCacheSource.find("std::uint64_t SourceContentHash(", registerBegin);
    Require(registerBegin != std::string::npos && registerEnd != std::string::npos);
    const auto registerBody = std::string_view(assetCacheSource).substr(
        registerBegin, registerEnd - registerBegin);
    Require(registerBody.contains("File hashing is intentionally outside") &&
        registerBody.find("HashFile(hash, stableSource)") >
            registerBody.find("File hashing is intentionally outside"));

    std::ifstream faceBatchFile(std::filesystem::path("src") / "BodyChangeNG" /
        "FaceSkinOverrides.cpp", std::ios::binary);
    Require(faceBatchFile.good());
    const std::string faceBatchSource((std::istreambuf_iterator<char>(faceBatchFile)), {});
    Require(faceBatchSource.contains("PersistsFace(actor->IsPlayerRef(), request.mode)"));
    Require(faceBatchSource.contains("CanRollbackKey(current,") &&
        faceBatchSource.contains("PrepareWrite(self->baseline,") &&
        faceBatchSource.contains("void RollbackChannel()") &&
        faceBatchSource.contains("completion = std::move(it->second.completion)"));
    Require(faceBatchSource.contains("it->second.paths = it->second.goodPaths") &&
        faceBatchSource.contains("it->second.mode = it->second.goodMode") &&
        faceBatchSource.contains("it->second.mode == mode"));
    std::ifstream nativeSkinFile(std::filesystem::path("src") / "BodyChangeNG" /
        "NativeSkinBackend.cpp", std::ios::binary);
    Require(nativeSkinFile.good());
    const std::string nativeSkinSource((std::istreambuf_iterator<char>(nativeSkinFile)), {});
    const auto sourceFamilyStart = nativeSkinSource.find("std::optional<std::uint32_t> SourceBodyFamily(");
    const auto sourceFamilyEnd = nativeSkinSource.find("std::optional<std::string> CurrentProfileId(", sourceFamilyStart);
    Require(sourceFamilyStart != std::string::npos && sourceFamilyEnd != std::string::npos);
    const auto sourceFamily = std::string_view(nativeSkinSource).substr(sourceFamilyStart, sourceFamilyEnd - sourceFamilyStart);
    Require(!sourceFamily.contains("!instance.sourceFamily") && sourceFamily.contains("!instance.skin.armor") &&
        sourceFamily.contains("instance.sourceRace != race") && sourceFamily.contains("instance.sourceSex != base->GetSex()") &&
        sourceFamily.contains("skin == instance.skin.armor"));
    Require(nativeSkinSource.contains("!actor->Is3DLoaded() && !skin_transaction::RestoresPreview(mode)") &&
        nativeSkinSource.contains("restoring ? frame_tasks::QueueRestoration(actorId, std::move(work))") &&
        nativeSkinSource.contains("frame_tasks::Queue(actorId, std::move(work), 1U, appearance::WorkChannel::skinApply)") &&
        nativeSkinSource.contains("if (!frame_tasks::IsCurrent(epoch) || !frame_tasks::ValidLease(lease)) return;") &&
        nativeSkinSource.contains("if (!RequestStillCurrent(baseId, generation, profile.id)) return;"));
    Require(nativeSkinSource.contains("SharedEmbeddedSkinBaseline(") &&
        nativeSkinSource.contains("NeedsEmbeddedSkinBaseline(") &&
        nativeSkinSource.contains("sourceAddon->IsValidRace(race)") &&
        nativeSkinSource.contains("const auto firstPersonReady = inspectModel(") &&
        nativeSkinSource.contains("target.modelSpaceNormals") &&
        nativeSkinSource.contains("CloneTexture(target.provider,") &&
        nativeSkinSource.contains("SetModelAlternateTextures(*model, pending)") &&
        !nativeSkinSource.contains("synthesizeMissingUbeTexture") &&
        !nativeSkinSource.contains("CreateUbeTexture(") &&
        !nativeSkinSource.contains("UbeBaselineTexturePath("));
    const auto instanceBegin = nativeSkinSource.find("std::optional<BaseInstance> BuildInstance(");
    const auto instanceEnd = nativeSkinSource.find("bool RequestStillCurrent(", instanceBegin);
    Require(instanceBegin != std::string::npos && instanceEnd != std::string::npos);
    const auto instanceSource = std::string_view(nativeSkinSource).substr(instanceBegin, instanceEnd - instanceBegin);
    Require(!instanceSource.contains("profile") && !instanceSource.contains("plan.body"));
    Require(nativeSkinSource.contains("RecordsApplication(mode)") &&
        nativeSkinSource.contains("instance.desiredMode != mode") &&
        nativeSkinSource.contains("instance.desiredContentHash != profile->contentHash") &&
        nativeSkinSource.contains("RestoreApplied(instance, *beforeMutation)") &&
        nativeSkinSource.contains("RestoreApplied(instance, *instance.goodState)") &&
        nativeSkinSource.contains("instance.goodState.reset()"));
    const auto currentBegin = faceBatchSource.find("bool Current()");
    const auto actorBegin = faceBatchSource.find("RE::NiPointer<RE::Actor> Actor()", currentBegin);
    Require(currentBegin != std::string::npos && actorBegin != std::string::npos);
    const auto currentBody = std::string_view(faceBatchSource).substr(
        currentBegin, actorBegin - currentBegin);
    Require(currentBody.contains("OwnsActiveBatch") &&
        currentBody.contains("activeGeneration") &&
        !currentBody.contains("it->second.generation == generation"));

    std::ifstream morphFile(std::filesystem::path("src") / "BodyChangeNG" /
        "RaceMenuBodyMorph.cpp", std::ios::binary);
    Require(morphFile.good());
    const std::string morphSource((std::istreambuf_iterator<char>(morphFile)), {});
    const auto cleanupStart = morphSource.find("void ClearPreviewNow(");
    const auto cleanupEnd = morphSource.find("bool IsNippleRefitSlider(", cleanupStart);
    Require(cleanupStart != std::string::npos && cleanupEnd != std::string::npos);
    const auto cleanup = std::string_view(morphSource).substr(cleanupStart, cleanupEnd - cleanupStart);
    Require(cleanup.contains("keys::ClearPreview(*bodyMorph, actor.get())") &&
        cleanup.contains("HasActivePreview(actor.get())") &&
        cleanup.find("keys::ClearPreview") < cleanup.find("actor->Is3DLoaded()"));
    Require(morphSource.contains("bcn::slider_name::Map<float> desiredMorphs") &&
        morphSource.contains("bcn::slider_name::Map<float> replaced") &&
        morphSource.contains("bcn::slider_name::Map<float> previewOutfit") &&
        !morphSource.contains("CollectCompatibleSliderNames") &&
        !morphSource.contains("std::unordered_map<std::string, float>"));
    Require(!morphSource.contains("->GetBodyMorphs(") &&
        !morphSource.contains("AbsolutePresetCorrection") &&
        !morphSource.contains("CompatibleSliderUniverse") &&
        !morphSource.contains("kLegacyOBodyKey") && !morphSource.contains("kLegacyOClotheKey"));
    Require(morphSource.contains("keys::BeginPresetCommit(*bodyMorph, actor.get(), settings.preserveOtherMorphs)") &&
        morphSource.contains("bodyMorph->GetMorph(actor.get(), name, kCommittedKey)") &&
        morphSource.contains("PreviewPresetCorrection(desired, replaced[name]) : desired"));
    Require(!morphSource.contains("raceMenuLegacy") && !morphSource.contains("RSMLegacy"));
    std::ifstream outfitFile(std::filesystem::path("src") / "BodyChangeNG" / "OutfitRefit.cpp", std::ios::binary);
    Require(outfitFile.good());
    const std::string outfitSource((std::istreambuf_iterator<char>(outfitFile)), {});
    const auto outfitGate = outfitSource.find("if (!outfit_refit_evaluation::ShouldApply(");
    const auto familyGate = outfitSource.find("if (female && !body_morph_policy::SupportsOutfitCorrection(");
    const auto refitLookup = outfitSource.find("auto found = PresetCatalog::Get().FindRefit(");
    Require(outfitGate != std::string::npos && familyGate != std::string::npos &&
        refitLookup != std::string::npos && outfitGate < familyGate && familyGate < refitLookup &&
        outfitSource.substr(outfitGate, familyGate - outfitGate).contains("return { Action::clear, signature }") &&
        outfitSource.contains("procedural-v4|") &&
        outfitSource.contains("rendered_outfit::EvaluateVisible(") &&
        outfitSource.contains("!IsBlacklisted(worn[index], rules)"));
    Require(!morphSource.contains("StableRandomSeed(") && !morphSource.contains("StableRange(") &&
        morphSource.contains("body_morph_policy::GenerateNippleMorphs(") &&
        morphSource.contains("body_morph_policy::GenerateGenitalMorphs(") &&
        !morphSource.contains("std::clamp(actorBase") && !morphSource.contains("std::clamp(base"));
    Require(!uiSource.contains("normalizedNpcCorrection") &&
        !uiSource.contains("settings.orefitEnabled = true") &&
        !uiSource.contains("settings.orefitNippleMorphing = true"));
    // Both anatomy options stay inside the female committed-preset block.
    // Player eligibility is intentional; preview/outfit never reroll anatomy.
    const auto anatomyBegin = morphSource.find("if (mode == bcn::racemenu::ApplyMode::commit && actorBase && actorBase->GetSex() == RE::SEX::kFemale)");
    const auto ubeGenitalBegin = morphSource.find("if (femaleFamily == bcn::body_morph_policy::FemaleFamily::ube &&", anatomyBegin);
    const auto ubeGenitalEnd = morphSource.find("if (mode != bcn::racemenu::ApplyMode::outfit)", ubeGenitalBegin);
    Require(anatomyBegin != std::string::npos && ubeGenitalBegin != std::string::npos && ubeGenitalEnd != std::string::npos);
    const auto ubeGenital = std::string_view(morphSource).substr(ubeGenitalBegin, ubeGenitalEnd - ubeGenitalBegin);
    Require(ubeGenital.contains("femaleFamily == bcn::body_morph_policy::FemaleFamily::ube") &&
        !morphSource.substr(anatomyBegin, ubeGenitalEnd - anatomyBegin).contains("PlayerCharacter") &&
        ubeGenital.contains("ube_anatomy::SupportedExtras(actor.get())") &&
        ubeGenital.contains("if (settings.nippleRandomization)") &&
        ubeGenital.contains("if (settings.genitalRandomization)") &&
        ubeGenital.contains("ube_nipple::Generate(") &&
        ubeGenital.contains("body_morph_policy::OBodyChance, bcn::body_morph_policy::OBodyRandom, write") &&
        !ubeGenital.contains("ube_nipple::SelectShape") &&
        ubeGenital.contains("ube_genital::Generate(shape, blend,") &&
        !ubeGenital.contains("GenerateNippleMorphs"));
    Require(morphSource.contains("bcn::ube_anatomy::ClearSupportCache();"));
    Require(uiSource.contains("여성 유두 랜덤화") && uiSource.contains("Female nipple randomization") &&
        uiSource.contains("女性乳头随机化") && uiSource.contains("여성 생식기 랜덤화") &&
        uiSource.contains("Female genital randomization") && uiSource.contains("女性生殖器随机化"));
    // Values, including zero, go to SetMorph; no BCNG range/epsilon filter.
    const auto morphWriteBegin = morphSource.find("for (const auto& [name, desired] : desiredMorphs)");
    const auto morphWriteEnd = morphSource.find("ApplyVisibleMorphs(*bodyMorph, actor.get(),", morphWriteBegin);
    Require(morphWriteBegin != std::string::npos && morphWriteEnd != std::string::npos);
    const auto morphWrite = std::string_view(morphSource).substr(morphWriteBegin, morphWriteEnd - morphWriteBegin);
    Require(morphWrite.contains("bodyMorph->SetMorph(actor.get(), name.c_str(), key, value)") &&
        !morphWrite.contains("if (") && !morphWrite.contains("clamp("));
    Require(morphSource.contains("OutfitRefit::Get().Evaluate(actor.get(), &preset)") &&
        morphSource.contains("PreviewBaseCollector collector(settings.preserveOtherMorphs, replaceOutfit)") &&
        morphSource.contains("previewOutfit.insert_or_assign") &&
        morphSource.contains("rendered_outfit::ValidateApply(actor.get())"));
    const auto defaultPreviewBegin = morphSource.find("ApplyResult QueuePreviewDefault(");
    const auto defaultPreviewEnd = morphSource.find("void QueueReapplyCurrent(", defaultPreviewBegin);
    Require(defaultPreviewBegin != std::string::npos && defaultPreviewEnd != std::string::npos);
    const auto defaultPreviewBody = std::string_view(morphSource).substr(
        defaultPreviewBegin, defaultPreviewEnd - defaultPreviewBegin);
    Require(defaultPreviewBody.contains("kPreviewKey, -value"));
    Require(defaultPreviewBody.contains("PreviewBaseCollector collector(true, true)") &&
        !defaultPreviewBody.contains("ClearReplacedBody"));
    Require(morphSource.contains("keys::ClearReplacedBody(*bodyMorph, resolved.get())") &&
        morphSource.contains("keys::ClearReplacedBody(*morph, resolved.get())") &&
        morphSource.contains("preset && preset->UsesBuildDefaults()") &&
        morphSource.contains("return (usesBuildDefaults || hasCommitted) && !hasOBody") &&
        morphSource.contains("return !hasBaseOrPreview && !hasOBody"));
    const auto defaultVerificationBegin = morphSource.find("const auto hasBaseOrPreview =");
    const auto defaultVerificationEnd = morphSource.find("return !hasBaseOrPreview", defaultVerificationBegin);
    Require(defaultVerificationBegin != std::string::npos && defaultVerificationEnd != std::string::npos);
    const auto defaultVerification = std::string_view(morphSource).substr(
        defaultVerificationBegin, defaultVerificationEnd - defaultVerificationBegin);
    Require(!defaultVerification.contains("kOutfitKey") && !defaultVerification.contains("kLegacyOutfitKey"));
    const auto explicitClearBegin = morphSource.find("ApplyResult QueueClearBodyChangeMorphs(");
    const auto explicitClearEnd = morphSource.find("bool QueueClearAllBodyChangeMorphs(", explicitClearBegin);
    Require(explicitClearBegin != std::string::npos && explicitClearEnd != std::string::npos);
    const auto explicitClear = std::string_view(morphSource).substr(explicitClearBegin, explicitClearEnd - explicitClearBegin);
    Require(explicitClear.contains("InvalidateOutfit(actor)") && explicitClear.contains("keys::ClearOwned") &&
        explicitClear.contains("keys::ClearReplacedBody"));
    const auto savedVerifyBegin = morphSource.find("void QueueVerifySavedBody(");
    const auto savedVerifyEnd = morphSource.find("bool HasOutfitCorrection(", savedVerifyBegin);
    Require(savedVerifyBegin != std::string::npos && savedVerifyEnd != std::string::npos);
    const auto savedVerifySource = std::string_view(morphSource).substr(savedVerifyBegin, savedVerifyEnd - savedVerifyBegin);
    Require(savedVerifySource.contains("frame_tasks::HasPreview") &&
        savedVerifySource.contains("HasActivePreview") &&
        savedVerifySource.contains("appearance::WorkChannel::bodyCommit") &&
        savedVerifySource.contains("appearance::WorkChannel::bodyPreviewCleanup") &&
        savedVerifySource.contains("appearance::WorkChannel::bodyVerify") &&
        savedVerifySource.contains("NeedsBodyApply") &&
        savedVerifySource.contains("selection.selectedId") &&
        savedVerifySource.contains("UpdatePolicy::deferred") &&
        !savedVerifySource.contains("Distribution::"));
    Require(!defaultPreviewBody.contains(
        "ClearBodyMorphKeys(resolved.get(), kCommittedKey)"));
    Require(!defaultPreviewBody.contains(
        "ClearBodyMorphKeys(resolved.get(), kLegacyOBodyKey)"));
    // These are production features, not opt-in diagnostic build variants.
    std::ifstream nativeFeatureFile(std::filesystem::path("src") / "BodyChangeNG" /
        "NativeAddonSkinBackend.cpp", std::ios::binary);
    Require(nativeFeatureFile.good());
    const std::string nativeFeatureSource((std::istreambuf_iterator<char>(nativeFeatureFile)), {});
    Require(!nativeFeatureSource.contains("BODY_CHANGE_NG_NATIVE_ADDON_TXST_TRIAL") &&
        nativeFeatureSource.contains("IsReadableImageRange(base, nt->OptionalHeader.SizeOfImage, address, iat.Size") &&
        nativeFeatureSource.contains("patterns::ae") &&
        nativeFeatureSource.contains("MatchRelocatedCode(") &&
        nativeFeatureSource.contains("ResolveRuntimeLayout(version)") &&
        nativeFeatureSource.contains("RtlLookupFunctionEntry") &&
        nativeFeatureSource.contains("visitor call sites already changed"));
    std::ifstream mainFeatureFile(std::filesystem::path("src") / "main.cpp", std::ios::binary);
    Require(mainFeatureFile.good());
    const std::string mainFeatureSource((std::istreambuf_iterator<char>(mainFeatureFile)), {});
    const auto preSaveBoundary = mainFeatureSource.find("message->type == SKSE::MessagingInterface::kSaveGame");
    Require(preSaveBoundary != std::string::npos &&
        mainFeatureSource.find("bcn::face_preview::BeforeSave()", preSaveBoundary) <
        mainFeatureSource.find("message->type == SKSE::MessagingInterface::kPreLoadGame", preSaveBoundary));
    const auto previewTransactionSource = readFeatureSource("FacePreviewTransaction.cpp");
    Require(previewTransactionSource.contains("manager->GetRuntimeData().thread.isBusy") &&
        previewTransactionSource.contains("state->GetSaveGameSaving()") &&
        previewTransactionSource.contains("state->GetSaveGameLoading()") &&
        previewTransactionSource.contains("runtime::ResolveGameBranch(REL::Module::get().version())") &&
        previewTransactionSource.contains("EXCLUSIVE_SKYRIM_FLAT"));
    Require(mainFeatureSource.contains("racemenu_form_delete::InstallInGame()") &&
        !mainFeatureSource.contains("BODY_CHANGE_NG_FORM_DELETE_GUARD_TRIAL"));
    const auto newGameBoundary = mainFeatureSource.find("message->type == SKSE::MessagingInterface::kNewGame");
    Require(newGameBoundary != std::string::npos &&
        mainFeatureSource.find("bcn::ui::OnSessionReset()", newGameBoundary) <
        mainFeatureSource.find("bcn::frame_tasks::Reset(true)", newGameBoundary));
    Require(mainFeatureSource.find("(void)bcn::catalog_refresh::Get()") >
        mainFeatureSource.find("bcn::player_tint::Catalog::Get().Refresh()"));
    Require(profilesSource.contains("~ClearRefreshFlag()") &&
        !profilesSource.contains("AuditProfileDds") &&
        !morphSource.contains("LogBodyTriState") &&
        !faceBatchSource.contains("FaceGPU"));
    std::ifstream familyFile(std::filesystem::path("src") / "BodyChangeNG" / "BodyFamily.cpp",
        std::ios::binary);
    Require(familyFile.good());
    const std::string familySource((std::istreambuf_iterator<char>(familyFile)), {});
    Require(familySource.contains("ResolveActorFamily(loaded.explicitFamilies,") &&
        !familySource.contains("ResolveSkinTextureFamily(0U, installedFamilies, SkinTextureLayout::unknown"));
    Require(familySource.contains("addon->IsValidRace(race)") &&
        familySource.contains("Slot::kBody") && familySource.contains("Slot::kHands") &&
        familySource.contains("Slot::kFeet") &&
        familySource.contains("IsBodyFamilyAddon(addon, actor->GetRace())"));
    Require(!familySource.contains("shape.name + ' ' + shape.diffuse") &&
        !familySource.contains("BSModelDB::Demand") && !familySource.contains("recursive_directory_iterator"));
    const auto transformationEvents = readFeatureSource("ActorEvents.cpp");
    // Both distribution entry points use the existing family compatibility
    // policy. A Legacy-only pre-filter silently removes every UBE skin.
    Require(!uiSource.contains("skin.layout != bcn::SkinLayout::legacy"));
    const auto nodeEvent = transformationEvents.find("const SKSE::NiNodeUpdateEvent* event");
    Require(nodeEvent != std::string::npos &&
        transformationEvents.find("skin_application::QueueTransformationReconcile(actor)", nodeEvent) != std::string::npos &&
        transformationEvents.contains("events->AddEventSink<RE::TESSwitchRaceCompleteEvent>(this)"));
    std::cout<<"CodePatternTests passed: callback, PE bounds, face queue, and preview lifecycle\n";
}

#include "BodyChangeNG/SkinProfiles.h"
#include "BodyChangeNG/CatalogRefreshQueue.h"
#include "BodyChangeNG/ContentSignature.h"
#include "BodyChangeNG/CatalogRoots.h"
#include "BodyChangeNG/PathText.h"
#include "BodyChangeNG/RuntimeAssetCache.h"

#include <SKSE/Logger.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <ranges>
#include <stop_token>
#include <system_error>
#include <thread>
#include <unordered_set>

namespace
{

    constexpr std::size_t kMaxProfiles = 512;
    constexpr std::size_t kMaxPathLength = 1024;
    constexpr std::uint8_t kDiffuseTextureIndex = 0U;
    constexpr std::uint8_t kNormalTextureIndex = 1U;
    // BSTextureSet uses slot 2 for subsurface/skin tint and slot 3 for the
    // FaceGen detail map.  Keeping these semantic names here avoids confusing
    // BodySlide's `_sk` suffix with the specular slot (which is slot 7).
    constexpr std::uint8_t kSkinTintTextureIndex = 2U;
    constexpr std::uint8_t kDetailTextureIndex = 3U;
    constexpr std::uint8_t kSpecularTextureIndex = 7U;

    [[nodiscard]] bool EqualsIgnoreCase(const std::string_view left, const std::string_view right)
    {
        if (left.size() != right.size()) return false;
        for (std::size_t index{}; index < left.size(); ++index) {
            const auto lower = [](const char value) {
                return value >= 'A' && value <= 'Z' ? static_cast<char>(value + ('a' - 'A')) : value;
            };
            if (lower(left[index]) != lower(right[index])) return false;
        }
        return true;
    }

    // MO2 enumerates a merged virtual Data tree. Canonical relative() can
    // resolve an entry to its physical provider under the MO2 mods directory,
    // so logical Data children appear to escape through "..". Catalog paths
    // must stay lexical inside the virtual tree.
    [[nodiscard]] std::optional<std::filesystem::path> RelativeWithin(
        const std::filesystem::path& path, const std::filesystem::path& root)
    {
        auto relative = path.lexically_relative(root);
        if (relative.empty() || relative.is_absolute()) return std::nullopt;
        for (const auto& component : relative) {
            if (component == "..") return std::nullopt;
        }
        return relative;
    }

    [[nodiscard]] bool IsGameRelativeTexturePath(const std::filesystem::path& dataRoot,
                                                  const std::filesystem::path& profileDirectory,
                                                  std::string& path)
    {
        if (path.empty() || path.size() > kMaxPathLength) return false;
        std::ranges::replace(path, '/', '\\');
        if (path.find("..") != std::string::npos || path.find(':') != std::string::npos || path.starts_with("\\")) return false;
        if (!bcn::asset_identity::EndsWith(path, ".dds")) return false;

        // `Textures\\...` is deliberately profile-relative. It lets a skin pack
        // retain its original texture tree under BodySkin/<skin>/Textures.
        if (bcn::asset_identity::StartsWith(path, "Textures\\")) {
            const auto relative = RelativeWithin(profileDirectory, dataRoot);
            if (!relative) return false;
            path = bcn::path_text::GenericUtf8(*relative) + "\\" + path;
            std::ranges::replace(path, '/', '\\');
        }

        return bcn::asset_identity::StartsWith(path, "BodySkin\\") ||
            bcn::asset_identity::StartsWith(path, "Futanari\\") ||
            bcn::asset_identity::StartsWith(path, "Textures\\");
    }

    [[nodiscard]] std::string LowerAscii(std::string value)
    {
        std::ranges::transform(value, value.begin(), [](const unsigned char character) {
            return static_cast<char>(std::tolower(character));
        });
        return value;
    }

    [[nodiscard]] bool HasPathComponent(const std::string_view path, const std::string_view component)
    {
        std::size_t begin{};
        while (begin < path.size()) {
            while (begin < path.size() && (path[begin] == '\\' || path[begin] == '/')) ++begin;
            auto end = begin;
            while (end < path.size() && path[end] != '\\' && path[end] != '/') ++end;
            if (EqualsIgnoreCase(path.substr(begin, end - begin), component)) return true;
            begin = end + 1U;
        }
        return false;
    }

    [[nodiscard]] std::optional<std::filesystem::path> FindTextureDirectory(const std::filesystem::path& skinDirectory)
    {
        std::error_code error;
        for (std::filesystem::directory_iterator it(skinDirectory, error), end; !error && it != end; it.increment(error)) {
            if (it->is_directory(error) && EqualsIgnoreCase(bcn::path_text::Utf8(it->path().filename()), "Textures")) return it->path();
        }
        return std::nullopt;
    }

    [[nodiscard]] std::optional<std::filesystem::path> FindTextureFile(const std::filesystem::path& textureDirectory,
                                                                        const std::string_view filename)
    {
        std::error_code error;
        for (std::filesystem::directory_iterator it(textureDirectory,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (it->is_regular_file(statusError) && !statusError &&
                EqualsIgnoreCase(bcn::path_text::Utf8(it->path().filename()), filename)) {
                return it->path();
            }
        }
        return std::nullopt;
    }

    [[nodiscard]] bool IsAutoTextureAnchor(const std::string_view filename)
    {
        constexpr std::array standardStems{
            std::string_view{ "femalebody_1" }, std::string_view{ "femalebody_etc_v2_1" },
            std::string_view{ "VaginalAnalCanal2" },
            std::string_view{ "femalehands_1" },
            std::string_view{ "femalefeet_1" }, std::string_view{ "femalehead" },
            std::string_view{ "femaleheadvampire" },
            std::string_view{ "malebody_1" }, std::string_view{ "malehands_1" },
            std::string_view{ "malefeet_1" }, std::string_view{ "malehead" },
            std::string_view{ "maleheadvampire" },
            // Vanilla beast-race texture names. Argonians use fully qualified
            // stems, while Khajiit use female*/ *male inside race-specific
            // directories. The directory is the authoritative race signal.
            std::string_view{ "argonianfemalebody" }, std::string_view{ "argonianfemalehands" },
            std::string_view{ "argonianfemalefeet" }, std::string_view{ "argonianfemalehead" },
            std::string_view{ "argonianfemaleheadvampire" },
            std::string_view{ "argonianmalebody" }, std::string_view{ "argonianmalehands" },
            std::string_view{ "argonianmalefeet" }, std::string_view{ "argonianmalehead" },
            std::string_view{ "argonianmaleheadvampire" },
            std::string_view{ "femalebody" }, std::string_view{ "femalehands" },
            std::string_view{ "femalefeet" },
            std::string_view{ "bodymale" }, std::string_view{ "handsmale" },
            std::string_view{ "feetmale" }, std::string_view{ "headmale" },
            std::string_view{ "headmalevampire" },
            std::string_view{ "khajiitfemalebody" }, std::string_view{ "khajiitfemalehands" },
            std::string_view{ "khajiitfemalefeet" }, std::string_view{ "khajiitfemalehead" },
            std::string_view{ "khajiitmalebody" }, std::string_view{ "khajiitmalehands" },
            std::string_view{ "khajiitmalefeet" }, std::string_view{ "khajiitmalehead" }
        };
        constexpr std::array standardSuffixes{
            std::string_view{ ".dds" }, std::string_view{ "_msn.dds" },
            std::string_view{ "_sk.dds" }, std::string_view{ "_s.dds" }
        };
        for (const auto stem : standardStems) {
            for (const auto suffix : standardSuffixes) {
                if (EqualsIgnoreCase(filename, std::string{ stem } + std::string{ suffix })) return true;
            }
        }
        constexpr std::array ubeStems{
            std::string_view{ "femalebody_1" }, std::string_view{ "femalehead" }
        };
        constexpr std::array ubeSuffixes{
            std::string_view{ "_d.dds" }, std::string_view{ "_n.dds" },
            std::string_view{ "_sk.dds" }
        };
        for (const auto stem : ubeStems) {
            for (const auto suffix : ubeSuffixes) {
                if (EqualsIgnoreCase(filename, std::string{ stem } + std::string{ suffix })) return true;
            }
        }
        return false;
    }

    [[nodiscard]] std::vector<std::filesystem::path> FindTextureSetDirectories(const std::filesystem::path& skinDirectory)
    {
        std::vector<std::filesystem::path> directories;
        std::error_code error;
        // Do not require an immediate `Textures` child.  Skin packs commonly
        // keep the original Bethesda tree (Textures/actors/.../female), while
        // others use BodyChange-style CustomSet folders.  Discover a set from
        // the actual body diffuse file rather than querying every traversed
        // directory: on MO2's virtual filesystem, directory metadata can be
        // incomplete even when its files are available to Skyrim.
        for (std::filesystem::recursive_directory_iterator it(skinDirectory,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (!it->is_regular_file(statusError) || statusError) continue;
            const auto filename = bcn::path_text::Utf8(it->path().filename());
            if (!IsAutoTextureAnchor(filename)) continue;
            const auto directory = it->path().parent_path();
            if (std::ranges::find(directories, directory) == directories.end()) {
                directories.push_back(directory);
            }
        }
        std::ranges::sort(directories);
        return directories;
    }

    [[nodiscard]] std::vector<bcn::SkinTextureLayer> AutoPart(const std::filesystem::path& dataRoot,
                                                               const std::filesystem::path& textureDirectory,
                                                               const std::string_view stem)
    {
        // Skyrim's BSTextureSet convention is TX00 diffuse, TX01 normal,
        // TX02 subsurface/skin tint and TX07 specular. `_sk` is not a
        // specular map; `_s` is.
        const std::array<std::pair<std::string, std::uint8_t>, 4> candidates{
            std::pair{ std::string{ stem } + ".dds", kDiffuseTextureIndex },
            std::pair{ std::string{ stem } + "_msn.dds", kNormalTextureIndex },
            std::pair{ std::string{ stem } + "_sk.dds", kSkinTintTextureIndex },
            std::pair{ std::string{ stem } + "_s.dds", kSpecularTextureIndex }
        };
        std::vector<bcn::SkinTextureLayer> layers;
        for (const auto& [filename, index] : candidates) {
            const auto file = FindTextureFile(textureDirectory, filename);
            if (!file) continue;
            const auto relative = RelativeWithin(*file, dataRoot);
            if (!relative) continue;
            auto path = bcn::path_text::GenericUtf8(*relative);
            if (!IsGameRelativeTexturePath(dataRoot, textureDirectory, path)) continue;
            bcn::runtime_assets::RegisterGameRelativeSource(path, *file);
            layers.push_back({ index, std::move(path) });
        }
        return layers;
    }

    [[nodiscard]] std::vector<bcn::SkinTextureLayer> AutoPartAliases(
        const std::filesystem::path& dataRoot, const std::filesystem::path& textureDirectory,
        const std::initializer_list<std::string_view> stems)
    {
        std::vector<bcn::SkinTextureLayer> layers;
        for (const auto stem : stems) {
            for (auto& candidate : AutoPart(dataRoot, textureDirectory, stem)) {
                if (std::ranges::find(layers, candidate.shaderTextureIndex,
                        &bcn::SkinTextureLayer::shaderTextureIndex) == layers.end()) {
                    layers.push_back(std::move(candidate));
                }
            }
        }
        std::ranges::sort(layers, {}, &bcn::SkinTextureLayer::shaderTextureIndex);
        return layers;
    }

    [[nodiscard]] std::vector<bcn::MaleGenitalTextureVariant> AutoSosMaleGenitals(
        const std::filesystem::path& dataRoot, const std::filesystem::path& skinDirectory)
    {
        std::vector<bcn::MaleGenitalTextureVariant> variants;
        std::unordered_set<std::string> knownDirectories;
        std::error_code error;
        for (std::filesystem::recursive_directory_iterator it(skinDirectory,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (!it->is_regular_file(statusError) || statusError) continue;
            const auto filename = bcn::path_text::Utf8(it->path().filename());
            const auto isRecognizedPart = [&filename](const std::string_view stem) {
                return EqualsIgnoreCase(filename, std::string{ stem } + ".dds") ||
                    EqualsIgnoreCase(filename, std::string{ stem } + "_msn.dds") ||
                    EqualsIgnoreCase(filename, std::string{ stem } + "_sk.dds") ||
                    EqualsIgnoreCase(filename, std::string{ stem } + "_s.dds");
            };
            // A deliberately partial skin may contain only a race/elder
            // variant or one channel. Any recognized SOS atlas is sufficient
            // to register its addon directory.
            const auto isSosAnchor = isRecognizedPart("malegenitals_1") ||
                isRecognizedPart("malegenitals_argonian_1") ||
                isRecognizedPart("malegenitals_khajiit_1") ||
                isRecognizedPart("malegenitals_old_1");
            if (!isSosAnchor) continue;
            const auto directory = it->path().parent_path();
            const auto genericPath = bcn::path_text::GenericUtf8(directory);
            if (!HasPathComponent(genericPath, "SOS")) continue;
            const auto addonDirectory = bcn::path_text::Utf8(directory.filename());
            auto key = LowerAscii(addonDirectory);
            if (key.empty() || !knownDirectories.insert(key).second) continue;

            auto humanoid = AutoPart(dataRoot, directory, "malegenitals_1");
            auto argonian = AutoPart(dataRoot, directory, "malegenitals_argonian_1");
            auto khajiit = AutoPart(dataRoot, directory, "malegenitals_khajiit_1");
            auto elder = AutoPart(dataRoot, directory, "malegenitals_old_1");
            if (humanoid.empty() && argonian.empty() && khajiit.empty() && elder.empty()) continue;
            variants.push_back({
                .addonDirectory = addonDirectory,
                .humanoid = std::move(humanoid),
                .argonian = std::move(argonian),
                .khajiit = std::move(khajiit),
                .elder = std::move(elder)
            });
        }
        std::ranges::sort(variants, [](const auto& left, const auto& right) {
            return LowerAscii(left.addonDirectory) < LowerAscii(right.addonDirectory);
        });
        return variants;
    }

    void OverlayChannels(std::vector<bcn::SkinTextureLayer>& base,
        const std::vector<bcn::SkinTextureLayer>& overlay)
    {
        for (const auto& layer : overlay) {
            const auto existing = std::ranges::find(base, layer.shaderTextureIndex,
                &bcn::SkinTextureLayer::shaderTextureIndex);
            if (existing != base.end()) *existing = layer;
            else base.push_back(layer);
        }
        std::ranges::sort(base, {}, &bcn::SkinTextureLayer::shaderTextureIndex);
    }

    void AppendUniqueLayers(std::vector<bcn::SkinTextureLayer>& destination,
        const std::vector<bcn::SkinTextureLayer>& source, const bool onePerChannel)
    {
        for (const auto& layer : source) {
            const auto duplicate = onePerChannel ?
                std::ranges::find(destination, layer.shaderTextureIndex,
                    &bcn::SkinTextureLayer::shaderTextureIndex) != destination.end() :
                bcn::asset_identity::Find(destination, layer.path,
                    &bcn::SkinTextureLayer::path) != destination.end();
            if (!duplicate) destination.push_back(layer);
        }
        std::ranges::sort(destination, {}, &bcn::SkinTextureLayer::shaderTextureIndex);
    }

    [[nodiscard]] std::optional<bcn::HumanoidSkinRace> RaceFaceDirectory(
        const std::filesystem::path& directory, const bcn::SkinSex sex)
    {
        const auto name = bcn::path_text::Utf8(directory.filename());
        if (sex == bcn::SkinSex::male) {
            if (EqualsIgnoreCase(name, "nordmale")) return bcn::HumanoidSkinRace::nord;
            if (EqualsIgnoreCase(name, "bretonmale")) return bcn::HumanoidSkinRace::breton;
            if (EqualsIgnoreCase(name, "darkelfmale")) return bcn::HumanoidSkinRace::darkElf;
            if (EqualsIgnoreCase(name, "highelfmale")) return bcn::HumanoidSkinRace::highElf;
            if (EqualsIgnoreCase(name, "imperialmale")) return bcn::HumanoidSkinRace::imperial;
            if (EqualsIgnoreCase(name, "orcmale")) return bcn::HumanoidSkinRace::orc;
            if (EqualsIgnoreCase(name, "redguardmale")) return bcn::HumanoidSkinRace::redguard;
            if (EqualsIgnoreCase(name, "woodelfmale")) return bcn::HumanoidSkinRace::woodElf;
            return std::nullopt;
        }
        if (EqualsIgnoreCase(name, "nordfemale")) return bcn::HumanoidSkinRace::nord;
        if (EqualsIgnoreCase(name, "bretonfemale")) return bcn::HumanoidSkinRace::breton;
        if (EqualsIgnoreCase(name, "darkelffemale")) return bcn::HumanoidSkinRace::darkElf;
        if (EqualsIgnoreCase(name, "highelffemale")) return bcn::HumanoidSkinRace::highElf;
        if (EqualsIgnoreCase(name, "imperialfemale")) return bcn::HumanoidSkinRace::imperial;
        if (EqualsIgnoreCase(name, "femaleorc")) return bcn::HumanoidSkinRace::orc;
        if (EqualsIgnoreCase(name, "redguardfemale")) return bcn::HumanoidSkinRace::redguard;
        if (EqualsIgnoreCase(name, "woodelffemale")) return bcn::HumanoidSkinRace::woodElf;
        return std::nullopt;
    }

    [[nodiscard]] bool IsElderTextureDirectory(
        const std::filesystem::path& directory, const bcn::SkinSex sex)
    {
        return EqualsIgnoreCase(bcn::path_text::Utf8(directory.filename()),
            sex == bcn::SkinSex::male ? "maleold" : "femaleold");
    }

    [[nodiscard]] bool IsConditionalHumanoidDirectory(const std::filesystem::path& directory)
    {
        for (const auto sex : { bcn::SkinSex::female, bcn::SkinSex::male }) {
            if (IsElderTextureDirectory(directory, sex) || RaceFaceDirectory(directory, sex)) return true;
        }
        return false;
    }

    [[nodiscard]] std::vector<std::filesystem::path> FindConditionalHumanoidDirectories(
        const std::filesystem::path& skinDirectory)
    {
        std::vector<std::filesystem::path> directories;
        std::error_code error;
        for (std::filesystem::recursive_directory_iterator it(skinDirectory,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (!it->is_directory(statusError) || statusError ||
                !IsConditionalHumanoidDirectory(it->path())) continue;
            directories.push_back(it->path());
        }
        std::ranges::sort(directories);
        return directories;
    }

    void MergeAutoProfile(bcn::SkinProfile& destination, const bcn::SkinProfile& source)
    {
        if (destination.layout == bcn::SkinLayout::unknown) {
            destination.layout = source.layout;
        } else if (source.layout != bcn::SkinLayout::unknown &&
            destination.layout != source.layout) {
            // One catalog row must never combine DDS files from incompatible
            // UV layouts. Keep its assets visible to diagnostics but make the
            // row ineligible for application.
            destination.layout = bcn::SkinLayout::unknown;
        }
        AppendUniqueLayers(destination.body, source.body, true);
        AppendUniqueLayers(destination.cbbeGenitalAnal, source.cbbeGenitalAnal, true);
        AppendUniqueLayers(destination.unpGenitalAnal, source.unpGenitalAnal, true);
        AppendUniqueLayers(destination.hands, source.hands, true);
        AppendUniqueLayers(destination.feet, source.feet, true);
        AppendUniqueLayers(destination.face, source.face, true);
        AppendUniqueLayers(destination.vampireFace, source.vampireFace, true);
        AppendUniqueLayers(destination.faceDetails, source.faceDetails, false);
    }

    void AttachConditionalHumanoidLayers(const std::filesystem::path& dataRoot,
        const std::filesystem::path& skinDirectory, bcn::SkinProfile& profile)
    {
        if (profile.race != bcn::SkinRace::humanoid ||
            profile.layout == bcn::SkinLayout::ube) return;

        const bool male = profile.sex == bcn::SkinSex::male;
        for (const auto& directory : FindConditionalHumanoidDirectories(skinDirectory)) {
            if (IsElderTextureDirectory(directory, profile.sex)) {
                OverlayChannels(profile.elderBody, AutoPart(dataRoot, directory, male ? "malebody_1" : "femalebody_1"));
                OverlayChannels(profile.elderHands, AutoPart(dataRoot, directory, male ? "malehands_1" : "femalehands_1"));
                OverlayChannels(profile.elderFace, AutoPart(dataRoot, directory, male ? "malehead" : "femalehead"));
                continue;
            }
            const auto race = RaceFaceDirectory(directory, profile.sex);
            if (!race) continue;
            auto layers = *race == bcn::HumanoidSkinRace::orc ?
                (male ? AutoPartAliases(dataRoot, directory, { "maleheadorc", "malehead" }) :
                    AutoPartAliases(dataRoot, directory, { "femaleheadorc", "femalehead" })) :
                AutoPart(dataRoot, directory, male ? "malehead" : "femalehead");
            OverlayChannels(profile.raceFace[static_cast<std::size_t>(*race)], layers);
        }
    }

    struct AutoRaceLayout final
    {
        bcn::SkinRace race{ bcn::SkinRace::humanoid };
        std::optional<bcn::SkinSex> fixedSex;
    };

    [[nodiscard]] AutoRaceLayout DetectAutoRaceLayout(const std::filesystem::path& textureDirectory)
    {
        const auto path = bcn::path_text::GenericUtf8(textureDirectory);
        if (HasPathComponent(path, "argonianfemale")) {
            return { bcn::SkinRace::argonian, bcn::SkinSex::female };
        }
        if (HasPathComponent(path, "argonianmale")) {
            return { bcn::SkinRace::argonian, bcn::SkinSex::male };
        }
        if (HasPathComponent(path, "khajiitfemale")) {
            return { bcn::SkinRace::khajiit, bcn::SkinSex::female };
        }
        if (HasPathComponent(path, "khajiitmale")) {
            return { bcn::SkinRace::khajiit, bcn::SkinSex::male };
        }
        return {};
    }

    [[nodiscard]] std::vector<bcn::SkinTextureLayer> AutoUbePart(
        const std::filesystem::path& dataRoot, const std::filesystem::path& textureDirectory,
        const std::string_view stem)
    {
        // UBE's PBR-aware body/head materials use explicit diffuse, normal,
        // and skin/subsurface names. RFAOS/wet companions are deliberately
        // not forced into a guessed BSTextureSet slot; those remain owned by
        // the active material/PBR setup.
        const std::array<std::pair<std::string, std::uint8_t>, 3> candidates{
            std::pair{ std::string{ stem } + "_d.dds", kDiffuseTextureIndex },
            std::pair{ std::string{ stem } + "_n.dds", kNormalTextureIndex },
            std::pair{ std::string{ stem } + "_sk.dds", kSkinTintTextureIndex }
        };
        std::vector<bcn::SkinTextureLayer> layers;
        for (const auto& [filename, index] : candidates) {
            const auto file = FindTextureFile(textureDirectory, filename);
            if (!file) continue;
            const auto relative = RelativeWithin(*file, dataRoot);
            if (!relative) continue;
            auto path = bcn::path_text::GenericUtf8(*relative);
            if (!IsGameRelativeTexturePath(dataRoot, textureDirectory, path)) continue;
            bcn::runtime_assets::RegisterGameRelativeSource(path, *file);
            layers.push_back({ index, std::move(path) });
        }
        return layers;
    }

    [[nodiscard]] std::optional<std::filesystem::path> FindChildDirectory(
        const std::filesystem::path& parent, const std::string_view name)
    {
        std::error_code error;
        for (std::filesystem::directory_iterator it(parent,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (it->is_directory(statusError) && !statusError &&
                EqualsIgnoreCase(bcn::path_text::Utf8(it->path().filename()), name)) return it->path();
        }
        return std::nullopt;
    }

    [[nodiscard]] std::optional<std::filesystem::path> FindDescendantDirectory(
        std::filesystem::path parent, const std::initializer_list<std::string_view> components)
    {
        for (const auto component : components) {
            const auto child = FindChildDirectory(parent, component);
            if (!child) return std::nullopt;
            parent = *child;
        }
        return parent;
    }

    [[nodiscard]] bcn::body_family::Mask InferAutoConventionalFamilies(
        const bcn::SkinSex sex, const bcn::SkinRace race)
    {
        if (race != bcn::SkinRace::humanoid) return 0U;
        // Pack names and optional metadata never decide a humanoid UV family.
        // Every conventional namespace is Legacy; the selected actor's one
        // resolved BodyFamily selects CBBE/UNP/vanilla/HIMBO/SAM routing.
        return bcn::StandardSkinFamilies(sex);
    }

    [[nodiscard]] std::vector<bcn::SkinTextureLayer> AutoFaceDetails(
        const std::filesystem::path& dataRoot, const std::filesystem::path& textureDirectory,
        const bool female)
    {
        std::vector<bcn::SkinTextureLayer> layers;
        const auto prefix = female ? std::string{ "femaleheaddetail_" } : std::string{ "maleheaddetail_" };
        std::error_code error;
        for (std::filesystem::directory_iterator it(textureDirectory,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (!it->is_regular_file(statusError) || statusError) continue;
            auto filename = bcn::path_text::Utf8(it->path().filename());
            std::ranges::transform(filename, filename.begin(), [](const unsigned char character) {
                return static_cast<char>(std::tolower(character));
            });
            if (!filename.ends_with(".dds") ||
                (!filename.starts_with(prefix) && filename != "blankdetailmap.dds")) continue;
            const auto relative = RelativeWithin(it->path(), dataRoot);
            if (!relative) continue;
            auto path = bcn::path_text::GenericUtf8(*relative);
            if (!IsGameRelativeTexturePath(dataRoot, textureDirectory, path)) continue;
            bcn::runtime_assets::RegisterGameRelativeSource(path, it->path());
            layers.push_back({ kDetailTextureIndex, std::move(path) });
        }
        std::ranges::sort(layers, {}, &bcn::SkinTextureLayer::path);
        return layers;
    }

    [[nodiscard]] std::vector<bcn::SkinProfile> AutoProfiles(const std::filesystem::path& dataRoot,
                                                              const std::filesystem::path& root,
                                                              const std::filesystem::path& skinDirectory,
                                                              const std::filesystem::path& textureRoot,
                                                              const std::filesystem::path& textureDirectory,
                                                              const bcn::SkinSex sex)
    {
        const auto female = sex == bcn::SkinSex::female;
        const auto raceLayout = DetectAutoRaceLayout(textureDirectory);
        if (raceLayout.fixedSex && *raceLayout.fixedSex != sex) return {};
        const auto layout = bcn::body_family::DetectSkinTextureLayout(
            bcn::path_text::GenericUtf8(textureDirectory),
            female ? bcn::body_family::Sex::female : bcn::body_family::Sex::male);
        if (layout == bcn::body_family::SkinTextureLayout::ube) {
            if (!female) return {};
            // A partial UBE pack may contain only Body or only Head. Resolve
            // both sibling atlases from whichever directory supplied the
            // discovery anchor.
            const auto atlasRoot = textureDirectory.parent_path();
            const auto bodyDirectory = FindChildDirectory(atlasRoot, "Body");
            const auto headDirectory = FindChildDirectory(atlasRoot, "Head");
            auto body = bodyDirectory ? AutoUbePart(dataRoot, *bodyDirectory, "femalebody_1") :
                std::vector<bcn::SkinTextureLayer>{};
            auto face = headDirectory ? AutoUbePart(dataRoot, *headDirectory, "femalehead") :
                std::vector<bcn::SkinTextureLayer>{};
            if (body.empty() && face.empty()) return {};
            const auto skinPath = RelativeWithin(skinDirectory, root);
            if (!skinPath) return {};
            const auto skinRelative = bcn::path_text::GenericUtf8(*skinPath);
            if (skinRelative.empty()) return {};
            return { bcn::SkinProfile{
                .id = "auto:" + skinRelative + ":female:ube",
                .name = bcn::path_text::Utf8(skinDirectory.filename()),
                .sex = bcn::SkinSex::female,
                .race = bcn::SkinRace::humanoid,
                .layout = bcn::SkinLayout::ube,
                .body = std::move(body),
                .face = std::move(face),
                .source = textureDirectory
            } };
        }
        std::vector<bcn::SkinTextureLayer> body;
        std::vector<bcn::SkinTextureLayer> cbbeGenitalAnal;
        std::vector<bcn::SkinTextureLayer> unpGenitalAnal;
        std::vector<bcn::SkinTextureLayer> hands;
        std::vector<bcn::SkinTextureLayer> feet;
        std::vector<bcn::SkinTextureLayer> face;
        std::vector<bcn::SkinTextureLayer> vampireFace;
        switch (raceLayout.race) {
        case bcn::SkinRace::argonian:
            if (female) {
                body = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianfemalebody", "femalebody", "femalebody_1" });
                hands = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianfemalehands", "femalehands", "femalehands_1" });
                feet = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianfemalefeet", "femalefeet", "femalefeet_1" });
                face = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianfemalehead", "femalehead" });
                vampireFace = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianfemaleheadvampire", "femaleheadvampire" });
            } else {
                body = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianmalebody", "bodymale", "malebody", "malebody_1" });
                hands = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianmalehands", "handsmale", "malehands", "malehands_1" });
                feet = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianmalefeet", "feetmale", "malefeet", "malefeet_1" });
                face = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianmalehead", "headmale", "malehead" });
                vampireFace = AutoPartAliases(dataRoot, textureDirectory,
                    { "argonianmaleheadvampire", "headmalevampire", "maleheadvampire" });
            }
            break;
        case bcn::SkinRace::khajiit:
            if (female) {
                body = AutoPartAliases(dataRoot, textureDirectory,
                    { "femalebody", "femalebody_1", "khajiitfemalebody" });
                hands = AutoPartAliases(dataRoot, textureDirectory,
                    { "femalehands", "femalehands_1", "khajiitfemalehands" });
                feet = AutoPartAliases(dataRoot, textureDirectory,
                    { "femalefeet", "femalefeet_1", "khajiitfemalefeet" });
                face = AutoPartAliases(dataRoot, textureDirectory,
                    { "femalehead", "khajiitfemalehead" });
                vampireFace = AutoPartAliases(dataRoot, textureDirectory,
                    { "femaleheadvampire" });
            } else {
                body = AutoPartAliases(dataRoot, textureDirectory,
                    { "bodymale", "malebody", "malebody_1", "khajiitmalebody" });
                hands = AutoPartAliases(dataRoot, textureDirectory,
                    { "handsmale", "malehands", "malehands_1", "khajiitmalehands" });
                feet = AutoPartAliases(dataRoot, textureDirectory,
                    { "feetmale", "malefeet", "malefeet_1", "khajiitmalefeet" });
                face = AutoPartAliases(dataRoot, textureDirectory,
                    { "headmale", "malehead", "khajiitmalehead" });
                vampireFace = AutoPartAliases(dataRoot, textureDirectory,
                    { "headmalevampire", "maleheadvampire" });
            }
            break;
        case bcn::SkinRace::humanoid:
            body = AutoPart(dataRoot, textureDirectory, female ? "femalebody_1" : "malebody_1");
            if (female) {
                cbbeGenitalAnal = AutoPart(dataRoot, textureDirectory, "femalebody_etc_v2_1");
                const auto unpDirectory = EqualsIgnoreCase(
                    bcn::path_text::Utf8(textureDirectory.filename()), "BakaUNP") ?
                    std::optional<std::filesystem::path>{ textureDirectory } :
                    FindChildDirectory(textureDirectory, "BakaUNP");
                if (unpDirectory) {
                    unpGenitalAnal = AutoPart(dataRoot, *unpDirectory, "VaginalAnalCanal2");
                }
            }
            hands = AutoPart(dataRoot, textureDirectory, female ? "femalehands_1" : "malehands_1");
            feet = AutoPart(dataRoot, textureDirectory, female ? "femalefeet_1" : "malefeet_1");
            face = AutoPart(dataRoot, textureDirectory, female ? "femalehead" : "malehead");
            vampireFace = AutoPart(dataRoot, textureDirectory, female ? "femaleheadvampire" : "maleheadvampire");
            break;
        }
        auto faceDetails = AutoFaceDetails(dataRoot, textureDirectory, female);
        // Detail maps augment a discovered face/body part but never create a
        // profile by themselves because blankdetailmap.dds is sex-ambiguous.
        if (body.empty() && cbbeGenitalAnal.empty() && unpGenitalAnal.empty() &&
            hands.empty() && feet.empty() && face.empty() && vampireFace.empty()) return {};
        const auto skinPath = RelativeWithin(skinDirectory, root);
        const auto setPath = RelativeWithin(textureDirectory, textureRoot);
        if (!skinPath || !setPath) return {};
        const auto skinRelative = bcn::path_text::GenericUtf8(*skinPath);
        if (skinRelative.empty()) return {};
        const auto suffix = female ? "female" : "male";
        // The user-facing unit is one top-level BodySkin folder per sex.  A
        // skin pack may contain optional detail maps or an extra nested set
        // directory, but those files must never explode into separate rows.
        // The stable id therefore belongs to the pack folder, not to an
        // individual DDS or nested texture directory.
        auto baseID = "auto:" + skinRelative + ":" + suffix;
        if (raceLayout.race == bcn::SkinRace::argonian) baseID += ":argonian";
        else if (raceLayout.race == bcn::SkinRace::khajiit) baseID += ":khajiit";
        const auto baseName = bcn::path_text::Utf8(skinDirectory.filename());
        const auto bodyFamilies = InferAutoConventionalFamilies(
            sex, raceLayout.race);
        const auto skinLayout = raceLayout.race == bcn::SkinRace::humanoid ?
            bcn::SkinLayoutFromFamilyMask(bodyFamilies) :
            bcn::BeastSkinLayout(raceLayout.race);
        return { bcn::SkinProfile{
            .id = baseID,
            .name = baseName,
            .sex = sex,
            .race = raceLayout.race,
            .layout = skinLayout,
            .body = std::move(body),
            .cbbeGenitalAnal = std::move(cbbeGenitalAnal),
            .unpGenitalAnal = std::move(unpGenitalAnal),
            .hands = std::move(hands),
            .feet = std::move(feet),
            .face = std::move(face),
            .vampireFace = std::move(vampireFace),
            .faceDetails = std::move(faceDetails),
            .source = textureDirectory
        } };
    }

}

namespace bcn
{
    std::string SkinRaceLabel(const SkinRace race)
    {
        switch (race) {
        case SkinRace::argonian: return "Argonian";
        case SkinRace::khajiit: return "Khajiit";
        default: return "Humanoid";
        }
    }

    SkinRace SkinRaceFromEditorID(const std::string_view editorID)
    {
        const auto lower = LowerAscii(std::string{ editorID });
        if (lower.find("argonian") != std::string::npos) return SkinRace::argonian;
        if (lower.find("khajiit") != std::string::npos) return SkinRace::khajiit;
        return SkinRace::humanoid;
    }

    SkinRace ResolveActorSkinRace(const RE::Actor* actor)
    {
        const auto* race = actor ? actor->GetRace() : nullptr;
        if (!race) return SkinRace::humanoid;
        const auto* editorID = race->GetFormEditorID();
        if (editorID && editorID[0] != '\0') {
            const auto detected = SkinRaceFromEditorID(editorID);
            if (detected != SkinRace::humanoid) return detected;
        }
        // Skyrim.esm is always load index 00. Exact full IDs are a safe
        // fallback if editor IDs are unavailable without misclassifying an
        // unrelated full plugin that happens to reuse the same local ID.
        switch (race->GetFormID()) {
        case 0x00013740U: return SkinRace::argonian;
        case 0x00013745U: return SkinRace::khajiit;
        default: return SkinRace::humanoid;
        }
    }

    HumanoidSkinRace HumanoidSkinRaceFromEditorID(const std::string_view editorID)
    {
        const auto lower = LowerAscii(std::string{ editorID });
        if (lower.find("breton") != std::string::npos) return HumanoidSkinRace::breton;
        if (lower.find("darkelf") != std::string::npos || lower.find("dunmer") != std::string::npos) {
            return HumanoidSkinRace::darkElf;
        }
        if (lower.find("highelf") != std::string::npos || lower.find("altmer") != std::string::npos) {
            return HumanoidSkinRace::highElf;
        }
        if (lower.find("imperial") != std::string::npos) return HumanoidSkinRace::imperial;
        if (lower.find("orc") != std::string::npos) return HumanoidSkinRace::orc;
        if (lower.find("redguard") != std::string::npos) return HumanoidSkinRace::redguard;
        if (lower.find("woodelf") != std::string::npos || lower.find("bosmer") != std::string::npos) {
            return HumanoidSkinRace::woodElf;
        }
        if (lower.find("nord") != std::string::npos) return HumanoidSkinRace::nord;
        return HumanoidSkinRace::generic;
    }

    bool IsElderSkinVariant(const std::string_view raceEditorID, const std::string_view voiceEditorID)
    {
        const auto race = LowerAscii(std::string{ raceEditorID });
        if (race.find("elder") != std::string::npos) return true;
        const auto voice = LowerAscii(std::string{ voiceEditorID });
        return voice.find("old") != std::string::npos || voice.find("elder") != std::string::npos;
    }

    bool IsElderActor(RE::TESNPC* base)
    {
        if (!base) return false;
        const auto* race = base->GetRace();
        const auto* raceEditorID = race ? race->GetFormEditorID() : nullptr;
        const auto* voice = base->GetVoiceType();
        const auto* voiceEditorID = voice ? voice->GetFormEditorID() : nullptr;
        return IsElderSkinVariant(
            raceEditorID ? std::string_view{ raceEditorID } : std::string_view{},
            voiceEditorID ? std::string_view{ voiceEditorID } : std::string_view{});
    }

    std::string SkinFamilyLabel(const SkinLayout layout, const SkinSex sex)
    {
        if (layout == SkinLayout::ube) return "UBE";
        if (layout == SkinLayout::legacy) {
            return sex == SkinSex::female ? "CBBE or UNP" : "HIMBO or SAM";
        }
        if (sex == SkinSex::male) return "Male";
        return "Unclassified";
    }

    std::string FutanariSkinTypeLabel(const FutanariSkinType type)
    {
        switch (type) {
        case FutanariSkinType::ubeTrx: return "UBE · SOS/TNG";
        case FutanariSkinType::ubeTrxAddon: return "UBE · TRX";
        case FutanariSkinType::cbbeTrx: return "CBBE 3BA · TRX";
        case FutanariSkinType::erf: return "CBBE 3BA · ERF";
        }
        return "Unknown";
    }

    SkinProfiles& SkinProfiles::Get()
    {
        static SkinProfiles profiles;
        return profiles;
    }

    std::filesystem::path SkinProfiles::RootPath()
    {
        return std::filesystem::current_path() / "Data" / "BodySkin";
    }

    std::vector<SkinProfile> SkinProfiles::ScanDirectory(const std::filesystem::path& root)
    {
        const auto dataRoot = root.parent_path();
        std::vector<SkinProfile> loaded;
        std::error_code error;
        if (std::filesystem::exists(root, error)) {
            for (std::filesystem::directory_iterator it(root,
                     std::filesystem::directory_options::skip_permission_denied, error), end;
                 it != end; it.increment(error)) {
                if (error) {
                    error.clear();
                    continue;
                }
                std::error_code statusError;
                if (!it->is_directory(statusError) || statusError || loaded.size() >= kMaxProfiles) continue;
                const auto skinDirectory = it->path();
                std::vector<SkinProfile> packProfiles;
                for (const auto& setDirectory : FindTextureSetDirectories(skinDirectory)) {
                    // Sex-specific elder and race-face folders are conditional
                    // variants of the pack's conventional male/female row. They
                    // must not become an independent row or win the shared
                    // pack id before the conventional directory is read.
                    if (IsConditionalHumanoidDirectory(setDirectory)) continue;
                    for (const auto sex : { SkinSex::female, SkinSex::male }) {
                        for (const auto& profile : AutoProfiles(dataRoot, root, skinDirectory, skinDirectory, setDirectory, sex)) {
                            const auto existing = bcn::asset_identity::Find(packProfiles, profile.id, &SkinProfile::id);
                            if (existing == packProfiles.end()) packProfiles.push_back(profile);
                            else MergeAutoProfile(*existing, profile);
                        }
                    }
                }
                for (auto& profile : packProfiles) {
                    if (loaded.size() >= kMaxProfiles) break;
                    if (profile.sex == SkinSex::male) {
                        profile.maleGenitals = AutoSosMaleGenitals(dataRoot, skinDirectory);
                    }
                    AttachConditionalHumanoidLayers(dataRoot, skinDirectory, profile);
                    if (profile.layout == SkinLayout::unknown) {
                        SKSE::log::warn(
                            "Body Change NG kept skin profile '{}' as diagnostic-only: its non-Legacy layout is ambiguous",
                            profile.name);
                    }
                    if (bcn::asset_identity::Find(loaded, profile.id, &SkinProfile::id) == loaded.end()) {
                        loaded.push_back(std::move(profile));
                    } else {
                        SKSE::log::warn("Body Change NG ignored duplicate skin profile id '{}'", profile.id);
                    }
                }
            }
        }
        if (error) SKSE::log::warn("Body Change NG could not scan {}: {}", bcn::path_text::Utf8(root), error.message());
        for (auto& profile : loaded) {
            ContentSignature hash;
            hash.Number(static_cast<unsigned>(profile.sex)); hash.Number(static_cast<unsigned>(profile.race));
            hash.Number(static_cast<unsigned>(profile.layout));
            const auto layers = [&](const auto& list) {
                hash.Number(list.size());
                for (const auto& layer : list) {
                    hash.Number(layer.shaderTextureIndex); hash.Text(layer.path);
                    hash.Number(runtime_assets::SourceContentHash(layer.path));
                }
            };
            layers(profile.body); layers(profile.hands); layers(profile.feet); layers(profile.face);
            layers(profile.cbbeGenitalAnal); layers(profile.unpGenitalAnal); layers(profile.vampireFace);
            layers(profile.elderBody); layers(profile.elderHands); layers(profile.elderFace);
            layers(profile.faceDetails);
            for (const auto& list : profile.raceFace) layers(list);
            for (const auto& variant : profile.maleGenitals) {
                hash.Text(variant.addonDirectory);
                layers(variant.humanoid); layers(variant.argonian); layers(variant.khajiit); layers(variant.elder);
            }
            profile.contentHash = hash.value;
        }
        std::ranges::sort(loaded, {}, &SkinProfile::name);
        return loaded;
    }

    void SkinProfiles::Refresh()
    {
        const auto root = RootPath();
        // Start the bounded cache worker at an explicit catalog boundary so
        // the first actor selection never pays thread-startup cost.
        runtime_assets::InitializeTexturePreparation();
        runtime_assets::ClearGameRelativeSources("BodySkin\\");
        std::vector<SkinProfile> loaded;
        for (const auto& scanRoot : catalog_roots::Discover(root)) {
            for (auto& profile : ScanDirectory(scanRoot)) {
                if (const auto found = bcn::asset_identity::Find(loaded, profile.id, &SkinProfile::id);
                    found != loaded.end()) *found = std::move(profile);
                else loaded.push_back(std::move(profile));
            }
        }
        std::ranges::sort(loaded, {}, &SkinProfile::name);
        for (auto& skin : loaded) {
            bcn::asset_identity::Set<std::string_view> paths;
            const auto collect = [&](const auto& layers) {
                for (const auto& layer : layers) paths.insert(layer.path);
            };
            collect(skin.body); collect(skin.cbbeGenitalAnal); collect(skin.unpGenitalAnal);
            collect(skin.hands); collect(skin.feet); collect(skin.face); collect(skin.vampireFace);
            collect(skin.elderBody); collect(skin.elderHands); collect(skin.elderFace);
            for (const auto& race : skin.raceFace) collect(race);
            collect(skin.faceDetails);
            skin.textureCount = paths.size();
        }
        auto published = std::make_shared<const std::vector<SkinProfile>>(std::move(loaded));
        bcn::asset_identity::Map<std::uint64_t> hashes;
        for (const auto& profile : *published) hashes[profile.id] = profile.contentHash;
        const auto count = published->size();
        {
            std::scoped_lock lock(lock_);
            profiles_.swap(published);
            contentHashes_.swap(hashes);
        }
        SKSE::log::info("Body Change NG loaded {} shared texture skin profiles from {}", count, bcn::path_text::Utf8(root));
    }

    bool SkinProfiles::RefreshAsync()
    {
        if (refreshing_.exchange(true, std::memory_order_acq_rel)) return false;
        try {
            if (catalog_refresh::Get().Submit(this, [this] {
                    struct ClearRefreshFlag {
                        std::atomic_bool& flag;
                        ~ClearRefreshFlag() { flag.store(false, std::memory_order_release); }
                    } clear{ refreshing_ };
                    Refresh();
                }, [](std::exception_ptr error) {
                    try { std::rethrow_exception(error); }
                    catch (const std::exception& exception) {
                        SKSE::log::error("Body Change NG skin catalog refresh failed: {}", exception.what());
                    }
                    catch (...) {
                        SKSE::log::error("Body Change NG skin catalog refresh failed with an unknown exception");
                    }
                })) return true;
        } catch (...) {
            // A failed allocation/worker submission must not leave Refresh blocked.
            refreshing_.store(false, std::memory_order_release);
            SKSE::log::error("Body Change NG could not queue skin catalog refresh");
            return false;
        }
        refreshing_.store(false, std::memory_order_release);
        return false;
    }

    std::vector<SkinProfile> SkinProfiles::Snapshot() const
    {
        return *SharedSnapshot();
    }

    std::shared_ptr<const std::vector<SkinProfile>> SkinProfiles::SharedSnapshot() const
    {
        std::scoped_lock lock(lock_);
        return profiles_;
    }

    std::uint64_t SkinProfiles::ContentHash(const std::string_view id) const
    {
        std::scoped_lock lock(lock_);
        const auto found = contentHashes_.find(std::string(id));
        return found == contentHashes_.end() ? 0 : found->second;
    }

    std::optional<SkinProfile> SkinProfiles::Find(const std::string_view id) const
    {
        std::scoped_lock lock(lock_);
        const auto found = bcn::asset_identity::Find(*profiles_, id, &SkinProfile::id);
        return found != profiles_->end() ? std::optional<SkinProfile>{ *found } : std::nullopt;
    }

    std::vector<std::string> SkinProfiles::CompatibleIds(
        const std::vector<std::string>& ids, const SkinSex sex,
        const body_family::Mask actorFamily, const SkinRace actorRace) const
    {
        std::scoped_lock lock(lock_);
        std::vector<std::string> compatible;
        compatible.reserve(ids.size());
        for (const auto& id : ids) {
            const auto found = bcn::asset_identity::Find(*profiles_, id, &SkinProfile::id);
            if (found != profiles_->end() &&
                SkinProfileCompatibility(*found, sex, actorRace, actorFamily).Compatible()) {
                compatible.push_back(id);
            }
        }
        return compatible;
    }

    FutanariSkinProfiles& FutanariSkinProfiles::Get()
    {
        static FutanariSkinProfiles profiles;
        return profiles;
    }

    std::filesystem::path FutanariSkinProfiles::RootPath()
    {
        return std::filesystem::current_path() / "Data" / "Futanari";
    }

    std::vector<FutanariSkinProfile> FutanariSkinProfiles::ScanDirectory(
        const std::filesystem::path& root)
    {
        const auto dataRoot = root.parent_path();
        std::vector<FutanariSkinProfile> loaded;
        std::error_code error;
        if (!std::filesystem::exists(root, error)) return loaded;

        for (std::filesystem::directory_iterator it(root,
                 std::filesystem::directory_options::skip_permission_denied, error), end;
             it != end; it.increment(error)) {
            if (error) {
                error.clear();
                continue;
            }
            std::error_code statusError;
            if (!it->is_directory(statusError) || statusError || loaded.size() >= kMaxProfiles) continue;
            const auto packDirectory = it->path();
            const auto packRelative = RelativeWithin(packDirectory, root);
            if (!packRelative) continue;
            const auto packID = bcn::path_text::GenericUtf8(*packRelative);
            if (packID.empty()) continue;
            const auto name = bcn::path_text::Utf8(packDirectory.filename());

            const auto append = [&](const FutanariSkinType type, const std::string_view suffix,
                const std::optional<std::filesystem::path>& directory,
                const std::string_view stem, const bool ubeNames) {
                if (!directory || loaded.size() >= kMaxProfiles) return;
                auto layers = ubeNames ? AutoUbePart(dataRoot, *directory, stem) :
                    AutoPart(dataRoot, *directory, stem);
                if (layers.empty()) return;
                ContentSignature hash;
                hash.Number(static_cast<unsigned>(type));
                for (const auto& layer : layers) {
                    hash.Number(layer.shaderTextureIndex);
                    hash.Text(layer.path);
                    hash.Number(runtime_assets::SourceContentHash(layer.path));
                }
                loaded.push_back({
                    .id = "futanari:" + packID + ":" + std::string{ suffix },
                    .name = name,
                    .type = type,
                    .layers = std::move(layers),
                    .source = *directory,
                    .contentHash = hash.value
                });
            };

            append(FutanariSkinType::ubeTrx, "ube-trx",
                FindDescendantDirectory(packDirectory, { "Textures", "!UBE", "Body" }),
                "malebody_1", true);
            append(FutanariSkinType::ubeTrxAddon, "ube-trx-addon",
                FindDescendantDirectory(packDirectory, { "Textures", "[TRX] Futa addon UBE" }),
                "schlong", false);
            append(FutanariSkinType::cbbeTrx, "cbbe-trx",
                FindDescendantDirectory(packDirectory,
                    { "Textures", "[TRX] Futa addon", "Regular", "Default" }),
                "schlong", false);
            append(FutanariSkinType::erf, "erf",
                FindDescendantDirectory(packDirectory,
                    { "Textures", "ERF_Futanari", "FairSkinCBBE" }),
                "futanari_schlong", false);
        }
        if (error) {
            SKSE::log::warn("Body Change NG could not scan {}: {}",
                bcn::path_text::Utf8(root), error.message());
        }
        std::ranges::sort(loaded, [](const auto& left, const auto& right) {
            if (left.name != right.name) return left.name < right.name;
            return static_cast<unsigned>(left.type) < static_cast<unsigned>(right.type);
        });
        return loaded;
    }

    void FutanariSkinProfiles::Refresh()
    {
        const auto root = RootPath();
        runtime_assets::InitializeTexturePreparation();
        runtime_assets::ClearGameRelativeSources("Futanari\\");
        std::vector<FutanariSkinProfile> loaded;
        for (const auto& scanRoot : catalog_roots::Discover(root)) {
            for (auto& profile : ScanDirectory(scanRoot)) {
                if (const auto found = bcn::asset_identity::Find(loaded, profile.id,
                        &FutanariSkinProfile::id); found != loaded.end()) {
                    *found = std::move(profile);
                } else {
                    loaded.push_back(std::move(profile));
                }
            }
        }
        std::ranges::sort(loaded, [](const auto& left, const auto& right) {
            if (left.name != right.name) return left.name < right.name;
            return static_cast<unsigned>(left.type) < static_cast<unsigned>(right.type);
        });
        auto published = std::make_shared<const std::vector<FutanariSkinProfile>>(std::move(loaded));
        bcn::asset_identity::Map<std::uint64_t> hashes;
        for (const auto& profile : *published) hashes[profile.id] = profile.contentHash;
        const auto count = published->size();
        {
            std::scoped_lock lock(lock_);
            profiles_.swap(published);
            contentHashes_.swap(hashes);
        }
        SKSE::log::info("Body Change NG loaded {} futanari skin profiles from {}",
            count, bcn::path_text::Utf8(root));
    }

    std::vector<FutanariSkinProfile> FutanariSkinProfiles::Snapshot() const
    {
        return *SharedSnapshot();
    }

    std::shared_ptr<const std::vector<FutanariSkinProfile>> FutanariSkinProfiles::SharedSnapshot() const
    {
        std::scoped_lock lock(lock_);
        return profiles_;
    }

    std::optional<FutanariSkinProfile> FutanariSkinProfiles::Find(const std::string_view id) const
    {
        std::scoped_lock lock(lock_);
        const auto found = bcn::asset_identity::Find(*profiles_, id, &FutanariSkinProfile::id);
        return found == profiles_->end() ? std::nullopt : std::optional<FutanariSkinProfile>{ *found };
    }

    std::uint64_t FutanariSkinProfiles::ContentHash(const std::string_view id) const
    {
        std::scoped_lock lock(lock_);
        const auto found = contentHashes_.find(std::string{ id });
        return found == contentHashes_.end() ? 0U : found->second;
    }
}

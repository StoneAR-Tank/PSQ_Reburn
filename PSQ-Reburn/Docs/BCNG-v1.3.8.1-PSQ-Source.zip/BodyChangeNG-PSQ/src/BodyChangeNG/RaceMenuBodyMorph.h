#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace RE
{
    class Actor;
}

namespace bcn::racemenu
{
    [[nodiscard]] constexpr float PreviewPresetCorrection(
        const float desiredPresetValue, const float replacedValues) noexcept
    {
        return desiredPresetValue - replacedValues;
    }

    [[nodiscard]] constexpr float OutfitTargetCorrection(
        const float target, const float ownedPresetValue) noexcept
    {
        return target - ownedPresetValue;
    }

    enum class ApplyMode : std::uint8_t
    {
        preview,
        commit,
        outfit
    };

    enum class UpdatePolicy : std::uint8_t
    {
        synchronous,
        deferred
    };

    enum class ApplyResult : std::uint8_t
    {
        queued,
        unavailable,
        invalidActor,
        actor3DUnavailable,
        missingPreset,
        emptyPreset,
        incompatibleSex,
        incompatibleBodyFamily,
        noTaskInterface,
        psqTemporaryPresetActive
    };

    void Initialize();
    void ResetSessionState();
    [[nodiscard]] bool IsReady() noexcept;
    [[nodiscard]] std::int32_t RequestPSQEquipmentMorphRefresh(RE::Actor* a_actor);
    [[nodiscard]] std::int32_t PSQEquipmentMorphRefreshStatus(RE::Actor* a_actor, std::int32_t a_request);
    [[nodiscard]] std::uint32_t Version() noexcept;
    // Used by the isolated RaceMenu paint and face-node adapters after the same
    // interface exchange has been runtime-validated here.
    [[nodiscard]] void* QueryInterface(const char* a_name) noexcept;
    [[nodiscard]] std::optional<std::string> CurrentPresetId(const RE::Actor* a_actor);
    // Verifies only BCNG-owned RaceMenu keys. The saved preset ID/signature is
    // checked by ActorRegistry; this call proves that the corresponding live
    // layer survived the current save load without scanning preset XML.
    [[nodiscard]] std::optional<bool> LiveBodyChangeStateMatches(
        const RE::Actor* a_actor, bool a_expectDefault);
    // Cheap key lookup used to avoid scheduling equipment work for actors
    // that have neither an active nor a legacy BCNG outfit correction.
    [[nodiscard]] bool HasOutfitCorrection(const RE::Actor* a_actor);
    // Player-only bridge for the verified CBBE, HIMBO and UBE slider keys.
    // A menu session owns value snapshots and an actor handle, never geometry.
    [[nodiscard]] bool BeginBodySliderEdit(RE::Actor* a_actor);
    void FinishBodySliderEdit(RE::Actor* a_actor);
    [[nodiscard]] bool IsBodySliderEditing(const RE::Actor* a_actor);
    void ForgetActorState(std::uint32_t a_actorFormID);
    [[nodiscard]] bool HasActivePreview(const RE::Actor* a_actor);
    // Optional PSQ-only transient body channel. It never commits a manual body
    // selection or mutates another source; completion follows the live refresh.
    [[nodiscard]] std::int32_t QueuePSQTemporaryPreset(RE::Actor* a_actor,
        std::string a_presetId, bool a_clear);
    [[nodiscard]] std::int32_t PSQTemporaryRequestStatus(const RE::Actor* a_actor,
        std::int32_t a_request);
    [[nodiscard]] bool HasPSQTemporaryPreset(const RE::Actor* a_actor);
    [[nodiscard]] ApplyResult QueueApply(RE::Actor* a_actor, std::string a_presetId, ApplyMode a_mode,
        std::uint64_t a_outfitSignature = 0U,
        UpdatePolicy a_updatePolicy = UpdatePolicy::synchronous);
    // Previews removal of BCNG and OBody/OClothe body/outfit keys without
    // mutating any committed key. QueueCancelPreview restores the
    // entry state by removing only the transient compensating layer.
    [[nodiscard]] ApplyResult QueuePreviewDefault(RE::Actor* a_actor);
    // Refresh surviving committed keys after a geometry rebuild; recommit
    // only if live keys, catalog content or application options changed.
    // forceCommit is reserved for explicit option changes in the settings UI.
    void QueueReapplyCurrent(RE::Actor* a_actor, bool a_forceCommit = false);
    // Event-driven live-key verification; never changes the saved selection
    // or takes ownership from an interactive preview.
    void QueueVerifySavedBody(RE::Actor* a_actor);
    [[nodiscard]] ApplyResult QueueApplyOutfit(RE::Actor* a_actor, std::string a_refitPresetId,
        std::uint64_t a_outfitSignature);
    // Reverts the transient single-click preview on the exact actor that owns
    // it. Safe to call repeatedly when switching actors, tabs, or closing UI.
    void QueueCancelPreview();
    // Detach-safe cleanup of abandoned preview keys; never touches an active
    // preview or committed/foreign morphs, and never forces an actor 3D load.
    void QueueClearInactivePreview(RE::Actor* a_actor);
    void QueueApplyProceduralOutfit(RE::Actor* a_actor, std::uint64_t a_outfitSignature);
    void QueueClearOutfit(RE::Actor* a_actor, std::uint64_t a_outfitSignature);
    void CancelPendingOutfit(RE::Actor* a_actor);
    enum class BodyClearReason { ordinary, explicitReset };
    ApplyResult QueueClearBodyChangeMorphs(RE::Actor* a_actor, bool a_ownedOnly = false,
        BodyClearReason a_reason = BodyClearReason::ordinary);
    [[nodiscard]] bool QueueClearAllBodyChangeMorphs(std::vector<std::uint32_t> a_alreadyReset, bool a_ownedOnly = false);
    // One-shot removal verification, never used by per-frame appearance work.
    [[nodiscard]] std::optional<std::size_t> RemainingOwnedMorphActors();
}

#pragma once

#include "BodyChangeNG/SliderName.h"
#include "BodyChangeNG/TemporaryBodyPreset.h"

#include <array>
#include <string>
#include <string_view>

namespace bcn::racemenu::keys
{
    inline constexpr auto body = "BodyChangeNG";
    inline constexpr auto preview = "BodyChangeNGPreview";
    inline constexpr auto outfit = "BodyChangeNGOutfit";
    // Value-only editor recovery layers travel with SKEE's own serialization.
    inline constexpr auto editorBaseline = "BodyChangeNGEditorBaseline";
    inline constexpr auto editorOffset = "BodyChangeNGEditorOffset";
    inline constexpr auto legacyBody = "BodyChangerNG";
    inline constexpr auto legacyPreview = "BodyChangerNGPreview";
    inline constexpr auto legacyOutfit = "BodyChangerNGOutfit";
    inline constexpr auto obody = "OBody";
    inline constexpr auto oclothe = "OClothe";
    inline constexpr std::array owned{ body, preview, outfit, legacyBody, legacyPreview, legacyOutfit, editorBaseline, editorOffset, temporary_body::key };

    [[nodiscard]] constexpr bool IsOwned(const std::string_view key) noexcept
    {
        for (const auto* candidate : owned) if (key == candidate) return true;
        return false;
    }

    template <class API, class Actor>
    void ClearPreview(API& api, Actor* actor)
    {
        api.ClearBodyMorphKeys(actor, preview);
        api.ClearBodyMorphKeys(actor, legacyPreview);
    }

    template <class API, class Actor>
    void ClearOwned(API& api, Actor* actor)
    {
        for (const auto* key : owned) api.ClearBodyMorphKeys(actor, key);
    }

    // OBody is another base-body provider, not an additive gameplay effect.
    // Explicit BCNG body changes replace these two exact keys as well, but
    // they are not BCNG-owned: preview cancellation must never delete them.
    [[nodiscard]] constexpr bool IsReplacedBody(const std::string_view key) noexcept
    {
        return IsOwned(key) || key == obody || key == oclothe;
    }

    template <class API, class Actor>
    void ClearReplacedBody(API& api, Actor* actor)
    {
        ClearOwned(api, actor);
        api.ClearBodyMorphKeys(actor, obody);
        api.ClearBodyMorphKeys(actor, oclothe);
    }

    // The destructive branch is used only for an accepted preset commit, not
    // preview, cancellation, Default, or outfit-only updates (OBody semantics).
    template <class API, class Actor>
    void BeginPresetCommit(API& api, Actor* actor, const bool preserveOtherMorphs)
    {
        if (preserveOtherMorphs) ClearReplacedBody(api, actor);
        else api.ClearMorphs(actor);
    }

    // Preview cancels the values that a real commit would replace using one
    // temporary delta key. Foreign keys themselves are never changed. Preserve
    // the current BCNG clothing layer only when SFS cannot yet decide its
    // final render state; otherwise replace it with the newly planned refit.
    class PreviewBase final
    {
    public:
        explicit PreviewBase(const bool preserveOtherMorphs, const bool replaceOutfit = true) :
            preserve_(preserveOtherMorphs), replaceOutfit_(replaceOutfit) {}
        void Visit(const char* name, const char* key, const float value)
        {
            if (!name || !*name || !key) return;
            const std::string_view source(key);
            if (source == preview || source == legacyPreview) return;
            if (!replaceOutfit_ && (source == outfit || source == legacyOutfit)) return;
            if (!preserve_ || IsReplacedBody(source)) values[name] += value;
        }
        slider_name::Map<float> values;
    private:
        bool preserve_;
        bool replaceOutfit_;
    };
}

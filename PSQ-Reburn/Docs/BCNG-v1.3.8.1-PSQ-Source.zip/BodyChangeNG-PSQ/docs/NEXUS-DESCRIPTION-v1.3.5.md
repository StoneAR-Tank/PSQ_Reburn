# BODY CHANGE NG

**v1.3.5: Open distribution rules directly, search target lists, and change rule candidates without recreating rules. Also improves face previews, UBE skin effects and futanari detection, with a targeted UBE SE outfit-morph compatibility fix. Correction and randomization options default to OFF.**

### v1.3.5 · Your character. Your choices.

Player-face previews temporarily update RaceMenu face-texture keys as well as the visible skin. Cancelling restores the original keys, and temporary keys are restored before saving. This is not a compatibility patch for simultaneous skin control by RSV or RaceMenu Selector.

Body presets • Skins • Tint masks • Optional futanari skins • Overlays
Native in-game interface • Player and NPC editing • Opt-in NPC distribution

Body Change NG (BCNG) brings appearance selection into one in-game window. Preview installed assets, confirm only what you want to keep, and create NPC rules from the items you select. Body shape and skin are independent; you do not need a prepared mesh set for every combination.

**Changing one NPC does not require distribution rules.** Select that NPC in the actor dropdown, open Body Skins, single-click a compatible pack to preview, and double-click to apply. NPC Distribution is a separate, optional workflow for assigning your selected candidates by rules.

BCNG ships no body meshes, skin packs, tattoo collections, or preset collection. It adds no ESP/ESL and does not require its own MCM. Install the assets and their normal requirements separately.

---

## REQUIREMENTS & GAME VERSIONS

**Required**

- [SKSE64](https://skse.silverlock.org/) built for your exact Skyrim executable version.
- [Address Library for SKSE Plugins](https://www.nexusmods.com/skyrimspecialedition/mods/32444), with the database for that runtime. Choose the appropriate SE/AE package.
- [RaceMenu](https://www.nexusmods.com/skyrimspecialedition/mods/19080), including its matching SKSE plugin and scripts. BCNG uses RaceMenu's BodyMorph, NiOverride, and overlay services.

**Incompatible — do not use together**

- OBody NG
- Racial Skin Variance - SPID (RSV)
- RaceMenu Selector of Skins - Unique Player Character

**Required for the feature you use**

- **Body presets:** a supported morph-enabled body, compatible outfits, and BodySlide preset XMLs. To reproduce the XML's intended shape, build **both the character body and the outfits you use** in [BodySlide](https://www.nexusmods.com/skyrimspecialedition/mods/201) with the matching **Zeroed Sliders** preset and **Build Morphs checked**. Install the generated meshes and TRI files together. Building only the body is not sufficient for outfits to follow correctly.
- **Skins and tint masks:** compatible loose DDS files, arranged as shown below.
- **Overlays:** installed RaceMenu paint registrations and textures, or SlaveTats collection JSONs and textures. Enable the relevant overlays in RaceMenu's configuration; BCNG does not increase its slot limit.
- **Genital-addon skins:** the appropriate SOS or TNG setup, its supported addon, and compatible textures. Female futanari skins require a supported female addon; ordinary male addons do not enable this feature.

**Explicitly supported runtime targets**

```text
Skyrim SE: 1.5.97
Skyrim AE: 1.6.317 / 1.6.318 / 1.6.323 / 1.6.342 / 1.6.353
           1.6.629 / 1.6.640 / 1.6.659 / 1.6.1130
           1.6.1170 / 1.6.1179
```

Here, SE/AE refers to the executable version, not whether you purchased the Anniversary Upgrade. **Skyrim VR, LE, Epic 1.6.678, Microsoft Store/Game Pass, and unlisted runtimes—including 1.7.x—are not supported.**

**Do not blindly install the newest SKSE or RaceMenu file.** Use releases made for your game version, including the correct Steam/GOG variant. BCNG handles the known older and newer RaceMenu interfaces rather than requiring one product version; it cannot make a mismatched RaceMenu DLL load.

### Skyrim 1.5.97 — recommended UBE installation

**Even on Skyrim 1.5.97, select UBE's DLL-free 1.6.x / AE option and use skee64backports with RaceMenu for 1.5.97 (official 0.4.16).** This is the UBE installer option—not an instruction to install the AE version of RaceMenu.

Check MO2's Data/conflict view: **SKSE\Plugins\skee64.dll should come from the 1.5.97 RaceMenu installation, not UBE's bundled SE DLL.** Ensure skee64backports is enabled in the same profile. This configuration worked with the UBE body and outfit checked during testing.

UBE's bundled SE DLL can cause outfits to appear inflated by applying morphs on top of an already-deformed shape. BCNG 1.3.5 also includes a targeted compatibility fix for the identified bundled DLL; the recommended setup above does not require that fix to activate.

**Fully exit and restart the game after changing DLLs.** Build both body and outfits with **Zeroed Sliders + Build Morphs**; changing DLLs does not remove a preset already baked into a mesh.

---

## INSTALLATION & FIRST USE

1. Install the matching requirements and the bodies/assets you want to use.
1. Install BCNG with your mod manager. Its DLL must resolve to **Data\SKSE\Plugins\BodyChangeNG.dll**. Keep only one active BCNG DLL.
1. For a normal skin pack, copy its entire installed mod folder into BodySkin, as shown below. MO2's mod root corresponds to the game's Data folder: inside an MO2 mod, start with **BodySkin**, **Futanari**, or **CalienteTools**—do not add another Data folder.
1. Launch through SKSE, using the same mod-manager profile.
1. Press **F7**. The window opens with the player selected. Use **Refresh actors** and the actor dropdown to choose a loaded NPC.
1. Choose a tab, single-click to preview, and **double-click to confirm**. Close without confirming to restore the previously committed selection.

**Tab order:** Body Presets → Body Skins → Tint Masks → Futanari Skin → Overlays.
The Futanari Skin tab is hidden when no supported female addon is installed and loaded.

**Add or replace files without closing the game:** You can add or replace body-preset XML files and body-skin, tint-mask, and futanari-skin packs at the full paths documented below while the game is running. Finish copying the files, press **Refresh** in the corresponding tab, then select the updated entry again to preview it and double-click to apply. Refresh updates the catalog; it does not automatically reapply a replacement to actors. With MO2, use the BCNG mod or a content mod already connected to the running game. The files must be accessible to that game process; restart after enabling a new mod or installing an ESP, DLL, or addon. This does not cover installing overlay mods.

### Choosing nearby or distant NPCs

The normal actor dropdown lists nearby, living, enabled NPCs with loaded 3D and a usable name, within 4,096 game units and up to the nearest 32 NPCs. Hostile and non-hostile NPCs—including bandits—are allowed. An eligible actor under the crosshair may also be included when opening the UI. This local list is not the scope of automatic distribution.

Open the actor dropdown, enter a **name or hexadecimal RefID** in its search field, and press **Enter** to search beyond the nearby distance/32-NPC limit. The number beside an actor's name is its reference ID, not the NPC BaseID. Use the individual actor's RefID for a specific actor; names can match multiple references.

Search finds actor references that already exist in the current game. It does not spawn NPCs, load cells, or guarantee that every NPC base in an installed plugin already has a searchable reference. Use distribution rules for NPCs that have not spawned yet. Name searches still exclude dead, disabled, unnamed, and non-NPC entries.

For an unloaded actor, compatible **body, skin, futanari-skin, and overlay choices** can be confirmed and stored without a live preview. When that actor's 3D loads, BCNG rechecks compatibility and processes the saved choice. **Save the game** to retain pending choices across sessions. Eligibility requirements still apply; Tint Masks remains player-only.

### BodySlide preparation — before launching the game

1. Open BodySlide through the same mod-manager profile and select the **Zeroed Sliders** preset appropriate for your installed body family.
1. Check **Build Morphs**. Build the character body and its matching parts, then use **Batch Build** for the compatible outfits you will wear, keeping the same zeroed base and Build Morphs enabled.
1. Enable the generated mesh and TRI output in that profile. Ensure another mod does not overwrite it with a body or outfit built to a different shape.

**Why this matters:** BCNG applies the selected XML's morph values on top of the installed mesh. If another preset's shape is already baked into that mesh, the result will not match the XML's intended shape. **Zeroed Sliders + Build Morphs is required for both body and outfits**; checking Build Morphs alone does not remove a shape already baked into the mesh. The XML sliders must also match the body/outfit's morph data.

### Controls

- **F7:** open/close; configurable in Mod Settings, including modifier combinations.
- **Single click / Up–Down / W–S / D-pad Up–Down:** move through rows and preview.
- **Double click / Enter / your configured Activate input:** confirm the focused item. Keyboard and gamepad both follow Skyrim's current gameplay Activate binding.
- **Left–Right / A–D / D-pad Left–Right:** switch tabs when not editing text or interacting with a popup.
- **Right-mouse drag over the character side:** rotate the character. On a gamepad, hold **LT** and move **RS left/right**.
- **Your configured menu Cancel key (keyboard) / Cancel button (gamepad):** dismiss the active popup first, or close the main UI if no popup is open. BCNG reads each device's current menu Cancel binding instead of requiring a fixed key/button. Close, X, and Escape also work; closing the main UI restores unconfirmed catalog previews.

The camera and character presentation are restored when the UI closes. Search is available across the catalogs; stars and the Favorites filter are available for body presets, body skins, tint packs, futanari skins, and overlays.

The character-rotation hint is right-aligned on the main title bar, immediately **left of X**: right-mouse drag or **LT+RS left/right**. Long hints scale to fit without shortening or truncation.

---

## USING EACH TAB

### Body Presets

Select a BodySlide shape for the player or an NPC. Live preview requires loaded 3D; the actor-search workflow above also supports pending choices for unloaded actors. The list uses the selected actor's sex and detected body family. XML Preset/set and Group metadata help distinguish CBBE 3BA, BHUNP/UNP, UBE, HIMBO, and SAM; renaming an XML does not convert its sliders.

Actor detection prioritizes the live skin geometry and texture layout over stale form or folder labels. Only race-compatible body, hand, and foot addons contribute addon metadata; installing UBE alongside a conventional body does not override a confirmed conventional layout. A custom NPC is not excluded simply because it comes from another mod. This does not convert incompatible meshes or sliders.

The first **Default Body** row clears the selected BCNG preset and old BCNG keys, plus the exact OBody and OClothe keys. Enabled outfit correction is an independent layer: it can still follow clothing on a Default body, including after loading a save or closing RaceMenu. Use the correction options to disable it; explicit actor reset and mod-removal cleanup clear their owned layers. Default Body leaves all other morph keys alone regardless of the preservation option. It does not replace installed meshes or turn a custom body into a vanilla mesh. Your body and outfit must contain the corresponding morph data to show a change.

Saved BCNG morph layers are checked when actors load or their 3D updates. Missing layers are restored from the saved selection without rerolling distribution or interrupting an active preview. This does not stop another body controller from writing its own morphs.

#### How preset morphs are calculated

BCNG reads the XML's small (weight 0) and big (weight 100) values for each slider. With w = actor weight / 100, the recorded morph is:

```text
morph = (small × (1 - w) + big × w) / 100

```

For example, small 20 and big 80 at weight 25 produce 0.35 (35%). Negative values and values above 100% are retained, not clamped to the 0–100% range. BCNG does not subtract other mods' morphs from this XML value when applying the preset.

Slider names are case-insensitive: Breasts and breasts identify the same morph. Low/high entries merge within each preset; another preset's zero values do not change the selected preset. Previews and outfit correction use the same name matching. Original XML files and authored values are not rewritten.

UNP-family presets have a small set of reverse-defined base sliders, including Breasts and NippleDistance. BCNG converts those endpoints with 1 - (XML value / 100) before interpolation; it does not reverse every slider. Optional female nipple/genital randomization can separately replace its selected anatomical sliders for both the player and NPCs.

**UBE preset values:** UBE preset endpoints also use XML value / 100, followed by the same weight interpolation. BCNG does not subtract UBE OSP build defaults or synthesize absent sliders. A missing endpoint starts at zero; duplicate endpoints retain the first non-zero parsed value. Zero, negative and over-100 XML values remain valid. Empty UBE Zeroed presets clear the replaced preset layers without inventing morphs. Use matching UBE body/outfit meshes and TRI files; XML numbers cannot supply a morph absent from the TRI.

With **Preserve other mods' morphs** on, BCNG's previous preset/correction keys and the exact OBody/OClothe keys are removed before application; other morph keys remain preserved; preserved keys can also affect the final shape according to RaceMenu's morph-combination setting. With it off, confirming a preset clears existing RaceMenu body morph keys before writing the new values. Previewing does not permanently delete those keys; closing without confirmation restores the committed state.

Clothed breast/nipple correction is a separate layer. The built-in correction uses either a target minus BCNG's preset value, or a weight-interpolated offset added to it. An explicitly selected outfit-correction preset supplies its own correction values instead. These corrections do not rewrite the source XML. To reproduce the intended baseline, build both the body and outfits with **Zeroed Sliders** and **Build Morphs**.

### Body Skins

UBE body skins replace only the six head/body _d, _n and _sk base maps. Installed loose RFAOS/wet maps are preserved only when they exist beside the original default normal map in its Head or Body folder. BCNG keeps the MO2-winning files and does not borrow effects from the selected skin pack or the parent !UBE folder. Original DDS files and effect settings remain unchanged.

Choose a texture pack independently of the body preset. **Select the actor → Body Skins → single-click to preview → double-click to apply.** You do not need to create NPC rules or select Default between every pair of custom packs. If distribution checkboxes are showing, press **Cancel distribution** to return to ordinary direct editing.

**Custom followers and unidentified body families:** BCNG permits direct skin selection when the actor's BodySlide family cannot be identified. The list shows sex/race-compatible packs with an unknown-family hint; choose the correct 3BA/UBE layout yourself. A known incompatible layout is still blocked. This manual allowance does not loosen automatic distribution or make incompatible UVs work.

NPC face matching uses the actual loaded FaceGen subtree, including an unambiguous skin-material target whose mesh name differs from its HeadPart name. Body-only packs do not require a face target unless an earlier face change still needs restoration. Missing or ambiguous face geometry is not replaced by a guessed target.

- Body, hands, and feet use a private native Skin Armor/ARMA/TXST setup. The face uses separate NiOverride skin-texture channels—not a tattoo overlay and not a HeadPart/NIF swap.
- If a body/hand/foot addon keeps its skin textures only in the NIF, BCNG reads the actual skin-material baseline and creates private native targets. Custom paths and normal-map conventions are retained; distinct atlases stay separate. Face-only packs leave the body unchanged and do not prevent later body-skin selection.
- Diffuse, normal, skin/subsurface, specular, and recognized detail channels are used where the pack and target provide them. A partial pack is valid; optional genital/anal textures do not have to exist on the current body for its ordinary skin to apply.
- For recognized race, elder, or vampire variants, a matching file in the selected pack takes priority. If absent, the selected pack's ordinary matching channel is used; if that is also absent, the underlying skin provider's channel is retained.
- Conventional feet may use the body's atlas when that is their native layout; hands and genuinely separate atlases keep their own routes. UBE uses its own atlas layout.
- Male SOS/TNG addon textures can be included in a male BodySkin pack. They require a compatible addon and an available native genital backend.
- The first **Default Skin** row restores the underlying skin instead of another BCNG pack, such as the vanilla skin or an installed texture replacer. This does not prevent another mod from reapplying its own skin changes; see the incompatible mods below.

When the actor's layout is known, the catalog separates UBE from conventional skins; sex and applicable race filters remain in effect. An unknown family is handled by the manual-choice workflow above, not silently reclassified from BCNG's cached filenames. A conventional listing is **not a UV conversion**: choose CBBE or UNP textures for the mesh you actually use. Likewise, a male SOS texture pack must fit your HIMBO/SOS mesh and addon.

### Tint Masks — player only

Tint masks share the **BodySkin** pack folder. A pack containing both skin DDS and recognized tint masks can appear in both tabs; applying the skin does not automatically select its makeup.

Choose a pack, then a supported tint layer/entry. Preview and confirm as above; use the detail/color controls to adjust color and intensity. Recognized layers include lips, cheeks, eyeliner, eye sockets, freckles, warpaint, and other supported facial tint types. Existing player tint layers determine what can be edited. Lists are filtered for sex and UBE/conventional compatibility using filenames and pack/path information; recognized COtR packs may be shared.

Use the restore entries/controls to restore captured pre-BCNG tint values. **Tint Masks has no NPC distribution.** Arbitrary DDS files without a recognized tint filename are not automatically turned into new RaceMenu layers.

Color and opacity can be edited during a preview. While the main UI stays open, BCNG remembers edits per pack/layer across item and tab changes. Confirm the catalog selection to keep it on the player; closing the main window without confirmation restores the committed tint and clears temporary edits.

### Futanari Skin — optional addon support

- The tab is enabled by installed, loaded **supported female SOS/TNG addons**, including recognized TRX, ERF, and UBE variants. It does not require an eligible actor to be present just to expose the tab and rule tools.
- Manual editing requires the selected female actor to be registered with a supported futanari addon in SOS/TNG. Male actors and unregistered female actors show **Not eligible**.
- Selecting a skin does not register an actor as futanari, equip an addon, or install its mesh. Set that up in SOS/TNG first.
- The list matches the registered addon type and body layout. A skin selected for an eligible actor remains independent of the ordinary body skin, including across a temporary disappearance of its addon geometry.
- The first default row restores the addon's own textures. NPC rules are locked to eligible female futanari NPCs.

**SOS/TNG size or addon changes:** BCNG changes supported textures, not the addon's size or mesh. Set size in SOS/TNG. Addon reselection can rebuild 3D, so the saved compatible skin is restored through the normal update path. Default restoration also restores BCNG's retained private texture paths that a provider may still reference. This does not convert ERF/TRX/UBE textures or make different addons interchangeable. If a texture breaks, check the addon and source pack, keep a backup save, and do not delete the cache as a repair attempt.

### Overlays — Face / Body / Hands / Feet

One scrolling catalog contains four expandable sections. Open an arrow to see installed RaceMenu paints and SlaveTats entries for that area. You do not need to open RaceMenu to populate BCNG's list.

- Single-click previews. **Double-click adds an overlay; double-click an already applied entry to remove it.** Multiple confirmed overlays can coexist in each area.
- A new preview replaces the temporary preview, not the confirmed stack. Closing without confirmation restores the committed stack.
- Selecting an area's first-row Default restores the normal body-skin camera framing. Confirming it removes only that area's BCNG overlays, not other mods' overlays.
- **Applied 2/14** means two confirmed BCNG overlays, out of 14 slots available to BCNG. The denominator is RaceMenu's normal slot capacity minus slots occupied/reserved by other mods. A preview does not increase the count.
- Select an entry and use the fixed bottom **Adjust color and opacity** controls. Color changes on a preview remain preview changes; changes to an already committed overlay update that overlay. The color popup is not a second Apply/Cancel transaction.
- Preview colors are remembered per actor, area, and entry until the main window closes. While **NPC Distribution** checkboxes are visible, checked entries accumulate as a temporary preview stack across all areas; unchecking an entry removes only its preview. The focused row selects which candidate's color/opacity you edit. An unchecked candidate can retain a draft color, but is not previewed until checked. Other mods' occupied slots are never overwritten; checked candidates beyond the available preview slots remain in the distribution pool. These distribution edits do not change the selected actor's committed overlays. Click **Distribute to loaded NPCs now** or **Distribute next game launch** to save the checked candidates and their individual colors with the rules. Automatic distribution selects one candidate per configured area and applies that candidate's color.
- Star entries to favorite them. Long secondary paths are shortened with an ellipsis.

Saved manual overlay stacks restore their individual entries and colors into separate available slots while respecting other mods' occupied slots.

Released SlaveTats / SlaveTats NG slots are reusable when only the recognized blank texture remains. Registered texture, tint or alpha overrides—including invisible tattoos—still reserve their slots. BCNG does not increase RaceMenu's configured capacity or erase another mod's active tattoos.

Slot capacity is read from RaceMenu and depends on your configuration. An invisible or transparent foreign overlay can still reserve a slot. BCNG does not automatically clear it to make room.

---

## NPC DISTRIBUTION — CREATE AND EDIT RULES

Available in **Body Presets, Body Skins, Futanari Skin, and Overlays**, not Tint Masks. New installations have **no rules**; BCNG does not randomly distribute the entire installed catalog.

### Open the editor

- **Distribution conditions:** open the conditions editor directly on the current feature's tab. No need to select candidates or create a rule first.
- **NPC distribution:** check candidates in the catalog, then press **Distribute** to open the editor with that selection. **Select all / Clear selection** affect visible eligible entries; default/reset rows are not candidates. For body/skin pools, first set the female/male NPC distribution body type in Mod Settings.

### Edit and save

1. Choose a feature tab and an existing rule, or use **+ Add rule**. Use **Delete rule / Up / Down** to manage rules and priority. List labels identify each rule's feature.
1. Set the sex and target conditions. Open **plugin, race, faction, keyword, or class** dropdowns to search by name, EditorID, plugin, or FormID. English letter case does not matter. Missing faction EditorIDs are also looked up in the plugin.
1. Press **Edit items** beside the candidate count. Use search, checkboxes, **Select all / Clear selection** to change candidates. **Save** in this picker updates the pending rule; **Close** cancels that item's pending edits. This picker does not apply appearance previews.
1. Press **Save next to Close in the conditions window** to save and activate the rules. The result appears beside the feature tabs. This does not run an immediate pass over loaded NPCs.
1. Use **Distribute to loaded NPCs now** to also process loaded NPCs immediately, or **Distribute next game launch** to save without changing this session's active rules.

**The item picker's Save is not the final rule save. Finish with Save in the conditions window. Closing the conditions window does not save pending edits.**

### Distribution previews

**Female / Male** controls the distribution sex and selects a nearby eligible NPC for preview, falling back to the player when none is available. Changing sex clears previous checkmarks and previews. Futanari Skin is female-only; NPC previews require a registered SOS/TNG addon. Preset/skin pools follow the configured NPC body type, not the preview actor's body.

Automatic NPC preview selection uses recognized **Nord, Breton, Imperial, Redguard, High Elf, Wood Elf, Dark Elf, and Orc** families, including recognizable custom variants. Khajiit, Argonians, other/unrecognized races, custom followers, and elders are excluded from this automatic selection. **These filters do not change manual actor selection or actual distribution rules.**

In distribution mode, actor controls are replaced by **Distribute selected items to world NPCs within a chosen scope**. The displayed actor is only a preview target, not the rule's scope. **Cannot preview on the current actor** does not prevent checking a candidate for compatible NPCs. A body-preset preview on a nearby actor is labelled **Previewing distribution item on a nearby actor**.

Rules are evaluated in order independently for each feature, and independently for each overlay area. A single compatible candidate gives a fixed assignment; several candidates form a stable per-NPC random pool. **Automatic overlay distribution picks one candidate per configured area; it does not apply every checked overlay at once.** Manual overlay editing supports the multi-overlay stack.

Automatic body-preset pools follow the configured NPC body type, including UBE. Candidates must also match the receiving NPC's known body family and sex; this does not convert a 3BA NPC into UBE or add simultaneous per-family settings. Body-skin, futanari-skin and overlay automatic pools retain their existing conventional/non-UBE restrictions. Futanari rules require registered female futanari NPCs and match the addon type. Manual confirmed choices, including Default choices, take priority over automatic distribution. NPCs sharing an ActorBase also share its native body-skin assignment; BCNG does not create a separate ActorBase for every spawned reference.

The two All NPCs exclusion checkboxes are target filters, not separate blacklist rules. They do not silently exclude a specifically named or individually targeted NPC. The nearby actor dropdown's radius and 32-NPC limit do not limit rule matching; eligible actors can receive saved rules when they load.

In body-preset, body-skin, and futanari-skin distribution lists, clicking a checkbox or row, or navigating with the keyboard/gamepad, previews the last compatible item on the selected actor. Only one item from each of these categories is previewed at a time; checkbox choices remain the distribution pool. Incompatible candidates may stay checked but are not rendered on that actor. Cancel distribution, Clear selection, entering the conditions popup, switching actors/tabs, or closing restores the committed appearance. The normal Futanari Skin list shows only the actor's registered ERF/TRX/UBE TRX type; the distribution pool can mix conventional ERF and TRX candidates, which are matched to each NPC's registered addon.

---

## FILE PATHS — KEEP THE ORIGINAL TEXTURE TREE

**All paths below start at the game's Data folder.** In MO2, omit the initial Data\ inside the mod directory. Replace the example pack names with your own. The examples show complete paths; entries ending in a backslash identify a directory.

Skin, futanari-skin, overlay and tint asset IDs, recognized DDS filenames/extensions and texture paths ignore ASCII letter case. Both slash styles identify the same texture path. Existing saved spelling is kept, so a capitalization-only difference does not lose favorites, preview colors or restoration state. This does not make different UV layouts compatible or turn an unregistered DDS into a RaceMenu overlay.

**The normal method: copy the whole installed skin-mod folder into BodySkin.** You do not need to extract individual DDS files or rebuild the inner folders.

For example, copy the installed **My Skin Pack** folder from MO2's mods directory into **Body Change NG\BodySkin**. Keep its existing Textures directory and all its contents.

```text
Before — relative to your MO2 installation:
mods\My Skin Pack\Textures\actors\character\female\femalehead.dds

After — inside the BCNG mod:
mods\Body Change NG\BodySkin\My Skin Pack\Textures\actors\character\female\femalehead.dds

The game sees:
Data\BodySkin\My Skin Pack\Textures\actors\character\female\femalehead.dds
```

Alternatively, keep your packs in a separate MO2 content mod with BodySkin at its top level, so replacing the BCNG plugin mod does not replace your packs. Keep each skin mod in its own folder.

“Installed mod folder” means the result after choosing FOMOD options, not the unprocessed download archive containing competing installer options. Extra meshes/scripts/plugins nested in BodySkin are not activated as a gameplay mod by BCNG; install any required body/addon plugin normally. If the original skin mod is only a texture replacer, keeping it enabled determines the underlying default skin independently of the copied BCNG pack.

### BodySlide XMLs

**Full directory: Data\CalienteTools\BodySlide\SliderPresets\**
A normal preset mod can stay installed normally: BCNG reads its XML files at this standard location.

```text
Data\CalienteTools\BodySlide\SliderPresets\My Presets.xml
```

UBE and conventional presets use the same location. TRI/mesh build output stays in its normal body/outfit paths; it does not belong under BodySkin.

### Conventional female skin — example

```text
Data\BodySkin\My CBBE Skin\Textures\actors\character\female\femalebody_1.dds
Data\BodySkin\My CBBE Skin\Textures\actors\character\female\femalebody_1_msn.dds
Data\BodySkin\My CBBE Skin\Textures\actors\character\female\femalebody_1_sk.dds
Data\BodySkin\My CBBE Skin\Textures\actors\character\female\femalebody_1_s.dds
Data\BodySkin\My CBBE Skin\Textures\actors\character\female\femalehands_1.dds
Data\BodySkin\My CBBE Skin\Textures\actors\character\female\femalehead.dds
```

Keep the matching hand/head maps and any recognized conditional subfolders too. For UNP, use the UNP version in another named pack; do not rename its DDS files to simulate CBBE compatibility.

### Conventional male skin and male SOS/TNG addon textures

```text
Data\BodySkin\My Male Skin\Textures\actors\character\male\malebody_1.dds
Data\BodySkin\My Male Skin\Textures\actors\character\male\malehands_1.dds
Data\BodySkin\My Male Skin\Textures\actors\character\male\malehead.dds
Data\BodySkin\My Male Skin\Textures\actors\character\SOS\SmurfAverage\malegenitals_1.dds
```

Keep the original addon directory and companion maps from your selected variant. SmurfAverage is an example, not a required rename. Ordinary male genital textures belong in **BodySkin**, not the female Futanari catalog.

### UBE body and face — example

```text
Data\BodySkin\My UBE Skin\Textures\!UBE\Body\femalebody_1_d.dds
Data\BodySkin\My UBE Skin\Textures\!UBE\Body\femalebody_1_n.dds
Data\BodySkin\My UBE Skin\Textures\!UBE\Body\femalebody_1_sk.dds
Data\BodySkin\My UBE Skin\Textures\!UBE\Head\femalehead_d.dds
Data\BodySkin\My UBE Skin\Textures\!UBE\Head\femalehead_n.dds
Data\BodySkin\My UBE Skin\Textures\!UBE\Head\femalehead_sk.dds
```

Keep UBE and conventional atlases in separate top-level packs. Preserve the actual !UBE tree.

### Tint masks — inside the same BodySkin pack

```text
Data\BodySkin\My CBBE Skin\Textures\actors\character\character assets\tintmasks\FemaleHeadLips.dds
```

This is a naming example for a recognized lip tint; preserve your pack's original recognizable filenames and tintmasks directory. A tint-only pack may use the same structure without body DDS files. **Do not use the old Data\TintMask root.** Skin scanning excludes tint masks, while the Tint Masks tab scans them separately.

### Female futanari skins — copy the entire skin-mod folder

**Copy the whole installed futanari-skin mod folder into Data\Futanari\.** Keep its Textures tree intact, exactly as with BodySkin.

```text
Before — relative to your MO2 installation:
mods\My ERF Skin\Textures\ERF_Futanari\FairSkinCBBE\futanari_schlong.dds

After — inside the BCNG mod:
mods\Body Change NG\Futanari\My ERF Skin\Textures\ERF_Futanari\FairSkinCBBE\futanari_schlong.dds

The game sees:
Data\Futanari\My ERF Skin\Textures\ERF_Futanari\FairSkinCBBE\futanari_schlong.dds
```

This copies a skin pack, not the SOS/TNG addon registration. Install the actual addon and its requirements normally. You can use a separate MO2 content mod with Futanari at its top level to keep copied skins separate from the plugin.

**Full DDS path examples for supported layouts:**

```text
Data\Futanari\My UBE Addon Skin\Textures\!UBE\Body\malebody_1_d.dds
Data\Futanari\My UBE TRX Skin\Textures\[TRX] Futa addon UBE\schlong.dds
Data\Futanari\My TRX Skin\Textures\[TRX] Futa addon\Regular\Default\schlong.dds
Data\Futanari\My ERF Skin\Textures\ERF_Futanari\FairSkinCBBE\futanari_schlong.dds
```

Native UBE and TRX UBE are separate skin types; only the type matching the actor's registered/equipped addon is listed. Keep each variant's full tree and maps: native UBE commonly uses _d, _n, _sk; TRX/ERF commonly use diffuse, _msn, _sk, _s. Keep optional wet companion textures if supplied. An ERF DDS cannot be made into a TRX/UBE skin by changing its filename.

### Overlays — install the original collection normally

```text
Data\Textures\Actors\Character\Overlays\       (a common RaceMenu texture location)
Data\Textures\Actors\Character\SlaveTats\*.json  (SlaveTats collection definitions)
Data\Textures\Actors\Character\SlaveTats\     (collection textures)
```

RaceMenu paints are discovered from their registrations; textures alone are not sufficient. A mod can legitimately register another texture path. SlaveTats entries are read from collection JSON and their referenced DDS files. There is **no BCNG Overlay pack root**; do not move these collections into BodySkin or Futanari.

**Refresh after adding or replacing files:** Once copying finishes, press Refresh in Body Presets, Body Skins, Tint Masks, or Futanari Skin. Reselect the updated entry to preview it and double-click to apply it. The files must be accessible to the running game at the full paths above; Refresh does not load new plugins or newly enabled mod-manager virtual paths.

---

## SETTINGS, SAVES & RESET

```text
Data\SKSE\Plugins\BodyChangeNG\settings.json
Data\SKSE\Plugins\BodyChangeNGdistribution.json
Data\Textures\BodyChangeNG\Cache\
Data\SKSE\Plugins\OBody_presetDistributionConfig.json  (optional ORefit input)
```

- **settings.json:** UI, hotkey, language, favorites, outfit-correction, and related options.
- **BodyChangeNGdistribution.json:** explicitly saved NPC rules. There are no Import/Export buttons. Back up or copy this file with the game closed; a valid file at the full path above is loaded automatically on the next game launch. Eligible NPCs are processed as they load, unless removal mode is active; manual choices still take priority. Referenced packs/plugins must remain available. Keep your customized file when upgrading; the installer starter is empty.

- **Runtime texture cache:** generated DDS copies under Data\Textures\BodyChangeNG\Cache\. This is output, not your source-pack folder. Keep it available to the same mod-manager profile. Older saves can still reference these paths even when the current actor uses another skin; do not bulk-delete the cache. Use the optional offline maintenance tool below to reclaim eligible duplicate storage without removing DDS paths.
- **OBody ORefit JSON:** use [ORefit JSON Master List](https://www.nexusmods.com/skyrimspecialedition/mods/105052) for outfit-correction rules, then click **Register ORefit outfit-correction rules** in BCNG.
- **Actor selections:** confirmed manual and automatic results are stored with the save through SKSE serialization. Keep the matching .skse co-save beside its .ess save; copying settings.json alone does not copy an actor's selections.
- **Tint saves:** the confirmed pack, per-layer color/opacity, restored layers, and captured original DDS/color are stored in that save's co-save. Original tints are not borrowed from another character's shared settings.



MO2 may place generated files in Overwrite or a configured output mod. Check the winning virtual Data path rather than assuming every generated file is physically inside the BCNG mod.

**Mod Settings** includes the opening hotkey, UI language (English/Korean/Simplified Chinese), text/UI scale, character placement, optional game pause, morph preservation, NPC body types, and performance mode. Defaults are **character on the left**, **game pause off**, **performance mode off**, and **Preserve other mods' morphs on**. Existing saved preferences are kept. Performance mode changes automatic-work spacing, not the intended selection.

**Preserve other mods' morphs** controls which existing morph keys BCNG replaces. On: applying a body preset removes BCNG and OBody/OClothe keys before applying the new preset, while preserving other morph keys. Off: applying a body preset clears all of that actor's RaceMenu body morph keys first. In either mode, BCNG writes the family-adjusted XML values, interpolated for actor weight, to its own key without subtracting other mods' values. Preserved morphs can therefore add to the visible result. Single-click previews simulate the chosen policy without deleting persistent keys; cancelling restores the committed state. Changing the option does not immediately reset every actor.

**Reset selected actor settings** and **Reset all actor settings** restore BCNG-managed body morphs, body skin including supported male-addon skin, separate futanari skin, overlays, and player tint values. “All” includes BCNG's recorded actor states and the player; it is not a deletion of every other mod's appearance data. Reset is saved as an explicit Default choice, so old automatic assignments do not immediately return. It does not delete asset folders or your NPC rule file.

### Preview restoration and large catalogs

Unconfirmed previews remain temporary. Cancellation is retained if an NPC unloads; player body/skin/overlay undo waits while RaceMenu is editing the player and resumes after it closes. A newer selection takes priority over older pending work. Default Skin completes only after both the owned body state and face cleanup finish.

Preset, skin, futanari, and tint lists reuse catalog data and avoid drawing off-screen rows while retaining keyboard navigation and distribution checkboxes. Mouse buttons and wheel input follow Skyrim's input stream and game cursor. These changes reduce repeated list work and missed-input paths; they do not make texture loading instantaneous.

### Prepare for mod removal

1. Back up your save and its matching .skse co-save while BCNG is still installed.
1. Open **Mod Settings → Prepare for removal... → Start cleanup**. This resets BCNG selections and restores its managed appearance, and persistently suspends automatic distribution and corrections.
1. Wait for **Cleanup verified**. Do not save or uninstall while cleanup is in progress. If it reports incomplete, leave BCNG installed, let pending updates finish or load the remaining actors, then retry.
1. After verification, close BCNG, save to a **new slot**, fully exit Skyrim, and uninstall.

Your rule file and other mods' morph keys are kept. Removal mode persists in **Data\SKSE\Plugins\BodyChangeNG\settings.json**. If you decide to keep the mod, **Resume BCNG** exits that mode; it does not recover selections already erased by cleanup. An older save has its own state and must be cleaned separately before removal. This is not a general damaged-save repair tool and does not make old cache paths disposable.

### Safe cache maintenance — optional, outside the game

The release includes **Tools\BodyChangeNGCache.exe** and **Tools\BodyChangeNGCache-README.txt**. After installation these correspond to **Data\Tools\BodyChangeNGCache.exe** and **Data\Tools\BodyChangeNGCache-README.txt**; in MO2, open the installed mod's physical Tools folder.

1. Close Skyrim and texture editors.
1. Run **BodyChangeNGCache.exe directly**, not through MO2.
1. Select the physical MO2 Overwrite/output folder, or its **textures\BodyChangeNG\Cache** directory.
1. Review the read-only scan. Choose **Yes** to compact eligible duplicates; **No** is the default.

Only byte-identical DDS copies with matching modification times are combined into NTFS hard links. Every DDS path and its content are preserved, including paths used by older saves. Unique textures are not deleted just because they are old or not currently selected. Only recognized unpublished preparation/link temporary files are removed.

The tool skips external hard links, read-only/locked files, junctions and unknown layouts. It does not edit source packs, saves, settings or rules, and never runs automatically during gameplay. Windows 10/11 and NTFS are required for compaction. Savings depend on eligible duplicates; Explorer's folder-size total may still look unchanged.

**Do not edit compacted cache DDS files directly.** Edit the original BodySkin/Futanari pack and use Refresh, then reselect and confirm in BCNG. Cache files can share physical storage after compaction. This tool is not a scanner of every save's references and is not a bulk cache-delete function.

### Outfit correction & randomization

Outfit/breast correction, nipple correction, female genital randomization and female nipple randomization all default to OFF. Enable only the features you want; explicitly saved settings are preserved.

The **Outfit · randomization** popup provides **Outfit correction while clothed** and a dependent **Correct nipples while clothed** switch. CBBE 3BA and BHUNP/UNP use breast/body correction with optional nipple correction. UBE 2.0/Necoco use eight breast-correction sliders, plus six nipple/UV-correction sliders when nipple correction is enabled. Offsets are interpolated by actor weight and added to, not substituted for, the selected body preset. Turning nipple correction off keeps the breast offsets; turning the main switch off or undressing removes the whole outfit layer and restores the uncorrected preset result. Each actor's actual body family controls the recipe, independently of the player's body.
CBBE 3BA/BHUNP refit combines target adjustments and fixed offsets: targets subtract only BCNG's own preset value, while fixed offsets remain additive. The UBE/Necoco recipe is additive only: it neither cancels the preset's nipple values nor subtracts RaceMenu or other mods' morphs. These corrections do not change how ordinary preset XML is parsed. Matching body/outfit TRI morphs are required, and results vary with the starting body and outfit. Body-preset previews use the same outfit-rule decision without changing committed morphs; disabling other-morph preservation also previews the absence of those values after confirmation.
Female nipple randomization supports CBBE 3BA/BHUNP/UNP and UBE/Necoco. UBE/Necoco use the same independent chance and branch rules with their own sliders and ranges, not mutually exclusive shape classes. Female genital randomization uses the existing CBBE 3BA/BHUNP/UNP recipe and a separate correlated Innie/Average/Outie recipe (20%/60%/20%) for UBE/Necoco. UBE leaves AnusSpread unchanged; Necoco genital extras require matching loaded TRI morphs. Both options include female players and NPCs when BCNG commits a body preset, directly or through NPC distribution. Distribution rules are optional; enabling an option alone does not randomize every world NPC, and previews do not reroll anatomy. Turn an option off and reapply the preset to restore its original values. These are morph adjustments, not genital-addon registration.

The outfit popup opens centered on first use instead of jumping to the top of the screen. Outfit, settings, NPC-condition, and color popups remember their individual positions for the next time you open them.

**Register ORefit outfit-correction rules** reads only the outfit-correction information in the OBody ORefit JSON at the full path above. If several MO2 mods provide that file, BCNG reads the winning file. It does not import NPC distribution rules or modify the source JSON.
Outfit-name, plugin and FormID exclusions are shared by CBBE 3BA, BHUNP/UNP and UBE/Necoco: an excluded outfit does not activate either breast or nipple correction. Existing explicit force-refit rules can still activate correction, as can another eligible torso item. With SFS, these rules use the final visible outfit; without SFS, they use worn equipment.

#### Skyrim Fitting System integration — correction follows the displayed outfit

[Skyrim Fitting System SE-AE (SFS)](https://www.nexusmods.com/skyrimspecialedition/mods/187128) lets you hide actual equipment or show a separately registered outfit while keeping the actual equipment's stats and effects.

With SFS's Rendered Outfit API v1, BCNG automatically bases breast/nipple correction on the final displayed outfit, including ORefit exclusions, force-refit rules, and outfit-specific presets:

- **Actual equipment visible:** use that equipment's name, FormID, and plugin.
- **Registered appearance visible:** use that appearance's name, FormID, and plugin—not the hidden equipment underneath.
- **Both visible:** evaluate the visible items together. Hidden items never contribute their rules.
- **All correction-relevant clothing hidden:** remove both breast and nipple correction.

SFS is optional. This integration requires an SFS build providing Rendered Outfit API v1; without SFS or that API, BCNG keeps its normal actual-equipment behavior.

---

## COMPATIBILITY & TROUBLESHOOTING

### INCOMPATIBLE MODS — DO NOT USE TOGETHER

These mods overlap with BCNG's appearance control. Choose one controller for the affected features.

- **OBody NG (OBody Next Generation):** Body-preset distribution and breast/nipple outfit correction overlap with BCNG. Both controllers can reapply their own morphs to the same actor, overwriting or stacking results. BCNG's OBody/OClothe key cleanup does not stop OBody from running or distributing again.
- **Racial Skin Variance - SPID (RSV)**: Incompatible with BCNG skin control. RSV can reapply its face textures after a character's 3D is rebuilt, overwriting the BCNG face while the body keeps the selected skin. This can cause a darker face, a visible neck seam, or a body/face mismatch during preview or after a later refresh. Do not use RSV and BCNG to control skins together.
- **RaceMenu Selector of Skins - Unique Player Character**: Incompatible with BCNG skin control. Selector reapplies its player Skin Armor and face textures on player 3D load or settings reapplication. This can overwrite a BCNG selection or leave a subsequent skin switch appearing unchanged. Do not use Selector and BCNG to control skins together.

**BCNG does not suspend RSV or Selector, and includes neither built-in conflict prevention nor a separate compatibility patch for them.** A successful preview or double-click confirmation does not make these combinations compatible: a later reapplication can bring the conflict back. Default Skin is a restoration action, not a compatibility workaround.
**[ORefit JSON Master List](https://www.nexusmods.com/skyrimspecialedition/mods/105052) can be used with BCNG.** Install its outfit-correction JSON, then click **Register ORefit outfit-correction rules** in BCNG.

**RaceMenu itself is still required**; the skin Selector above is a separate mod.

### Other compatibility notes and troubleshooting

- **Ordinary texture replacers:** a BCNG skin replaces supported channels while selected; Default Skin restores the underlying skin. This is not simultaneous blending of two complete skin packs or compatibility with another active skin controller.
- **Custom outfits:** native skin routing is used where the mesh draws from that skin. An outfit's own hard-coded textures or incompatible UV layout are not automatically converted.
- **Other body controllers:** avoid having two systems continuously assign the same actor's morphs or texture channels.
- **F7 does nothing:** verify the active DLL, exact game/SKSE/RaceMenu combination, and SKSE logs. Do not install a 1.7.x dependency merely because it is labelled latest.
- **A preset appears but does not change the body/outfit, or its shape differs from the XML:** rebuild both the character body and the outfits with the matching Zeroed Sliders preset and Build Morphs checked. Verify the winning mesh/TRI output and matching preset slider names; a different baked-in base shape remains underneath BCNG's morphs.
- **UBE preset looks flat or Zeroed:** Actor weight matters even when naked. A preset that defines only big values can be zeroed at weight 0 because its omitted small values are zero. Compare at the preset author's intended weight; BCNG does not force weight 100 or invent the missing endpoint. UBE sliders are applied by their XML names and require matching morphs in the winning body/outfit TRI files.
- **A skin or tint pack is missing:** check the selected actor's sex/layout, the top-level pack folder, resolved Textures tree, and recognized DDS names. Remove accidental Data\Data or Textures\Textures nesting from the installation layout.
- **Purple face or wrong texture:** check the selected pack, missing/corrupt DDS files, winning mod-manager paths, and conflicting face overrides. Include the selection sequence and versions in a report; a screenshot alone cannot establish the cause.
- **Overlay unavailable or color has little effect:** check the area's RaceMenu enable/count settings, foreign reserved slots, and the texture itself. A colored texture will not necessarily tint like a grayscale mask.
- **Futanari tab missing / Not eligible:** distinguish supported female-addon installation from the actor's SOS/TNG registration. Neither an ordinary male addon nor a texture-only pack satisfies both conditions.

The log is **BodyChangeNG.log** in SKSE's log directory, commonly under Documents\My Games\Skyrim Special Edition\SKSE; the location can differ by game edition/setup. For reports, include game/SKSE/RaceMenu versions, body/addon type, pack path, reproduction steps, and the log. v1.3.5 passed its Release build and 43 offline regression executables.

---

## UPDATING FROM EARLIER VERSIONS

- A new game or save cleaning is not required for v1.3.5. Existing co-save formats are retained. Keep settings, customized rules, asset packs, favorites, and the runtime texture cache. Do not run removal preparation merely to update BCNG.
- Exit Skyrim and back up your saves with matching SKSE co-saves, settings, customized distribution JSON, and asset packs before replacing the plugin.
- If you previously activated removal mode but are continuing with BCNG, use Resume BCNG in Mod Settings. Updating the DLL alone does not clear that saved setting.
- Keep your existing BodySkin and Futanari packs. Move old standalone tint packs into **Data\BodySkin\Your Pack\Textures\actors\character\character assets\tintmasks\**, retaining their original inner texture tree. Do not leave them only under the obsolete TintMask root.
- Do not overwrite your customized rule file with the empty installer starter. The updated schema-8 DLL backs up schemas 3–7 before converting to named references. Existing legacy exclusion cleanup remains; unresolved old asset IDs are preserved.
- **Changed confirmation behavior:** closing the picker now cancels an unconfirmed preview. Closing the NPC rule popup now cancels unsaved rule edits instead of auto-saving a next-launch draft.
- Do not rely on a renamed/deleted pack retaining its previous selection ID. Keep pack names/paths stable when possible. Downgrading a save written by v1.3.5 is not guaranteed.

---

## CREDITS & SOURCE

Thanks to the SKSE team, expired6978/RaceMenu, CommonLibSSE-NG contributors, Dear ImGui, pugixml, and the authors of the body, texture, addon, and overlay assets you choose to install.

[Body Change NG source repository](https://github.com/compilecraftworks/Body-Change-NG) · GPL-3.0; see LICENSE and THIRD_PARTY_NOTICES.md.
Third-party assets keep their own licenses and are not bundled with BCNG.

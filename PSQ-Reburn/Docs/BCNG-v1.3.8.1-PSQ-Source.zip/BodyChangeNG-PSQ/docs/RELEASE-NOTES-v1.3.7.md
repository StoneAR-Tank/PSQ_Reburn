# Body Change NG v1.3.7

## English

- Add a default-on Exclude children checkbox beside the elder exclusion in All NPCs rules for body presets, body skins, futa skins and overlays. Existing rules without this option also exclude children, using the game's child check. This prevents future matches; it does not automatically reset previously applied appearances.
- Fix a file-handle conflict when automatically upgrading older distribution JSON files at the same path. Existing rules and comments are preserved; save-error UI is unchanged.
- Show the applied CBBE/3BA, HIMBO or UBE shape in its supported RaceMenu body sliders and retain subsequent edits in BCNG. Keep other mods' morphs and clothing correction separate, including when saving during editing. Requires additive RaceMenu iBodyMorphMode=0.
- Explain why overlays are unavailable instead of showing an ambiguous 0/0: target loading, unavailable RaceMenu, disabled slots or slots reserved by other mods. Add Korean, English and Chinese guidance while preserving the SlaveTats blank-slot fix and other mods' overlays.
- Check body, hand and foot skin resources after rebuilding. Missing textures or stale BCNG cache paths no longer count as successful application; retry eligible failed selections up to twice without taking over other mods' skin changes.

### Updating

Fully exit the game before updating. Preserve customized distribution rules, settings, favorites, skin packs and texture caches. Supported runtimes and the distribution schema remain unchanged.

## 한국어

- 바디프리셋·바디스킨·후타스킨·오버레이의 전체 NPC 배포 조건에 기본으로 켜진 ‘어린이 제외’를 추가했습니다. 기존 규칙에 새 항목이 없어도 게임의 어린이 판정에 따라 제외합니다. 이후 배포 대상에서 제외하는 기능이며 이미 적용된 외형을 자동 초기화하지는 않습니다.
- 이전 형식의 배포 JSON을 같은 경로에서 자동 변환할 때 발생하던 파일 접근 충돌을 수정했습니다. 기존 규칙과 주석은 보존하며 저장 실패 안내 UI는 변경하지 않았습니다.
- CBBE/3BA·HIMBO·UBE의 적용 체형을 지원하는 RaceMenu 바디 슬라이더에 표시하고, 이후 편집값을 BCNG에 유지합니다. 편집 중 저장할 때도 다른 모드의 모프와 의상 보정은 분리해 보존합니다. RaceMenu 기본 합산 설정 iBodyMorphMode=0을 사용합니다.
- 오버레이를 사용할 수 없는 이유를 단순한 0/0 대신 대상 로딩·RaceMenu 미연결·슬롯 비활성·다른 모드 점유로 구분하고 한·영·중 안내를 추가했습니다. 기존 SlaveTats 빈 슬롯 수정과 다른 모드의 오버레이는 유지합니다.
- 몸·손·발 스킨 재생성 후 텍스처 상태를 확인합니다. 누락 텍스처나 이전 BCNG 캐시 경로를 적용 성공으로 처리하지 않고, 복구 가능한 경우 최대 두 번 재시도합니다. 다른 모드가 변경한 스킨은 덮어쓰지 않습니다.

### 업데이트 안내

게임을 완전히 종료한 뒤 업데이트하세요. 사용자 배포 규칙·설정·즐겨찾기·스킨팩·텍스처 캐시는 보존하세요. 지원 게임 버전과 배포 규칙 형식은 그대로입니다.

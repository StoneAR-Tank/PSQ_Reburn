#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <algorithm>
#include <filesystem>
#include <mutex>
#include <unordered_set>
#include <vector>
#include "VisibilityPolicy.h"

namespace {
std::mutex lock;
std::uint64_t generation{};
bool ready{};
// Only game-thread tasks touch owned scene objects. No raw pointers survive
// a task and the references are released on exit/load/new game or replacement.
psq::visibility::Ownership<RE::NiPointer<RE::NiAVObject>> ownership;
void RestoreOwned() {
 ownership.Reset();
}
using IDs=std::unordered_set<RE::FormID>;
IDs Convert(const std::vector<RE::TESForm*>& forms) {
 IDs out;for(auto* form:forms)if(form)out.insert(form->GetFormID());return out;
}
void Apply(RE::Actor* actor,const IDs& originals,const IDs& protectedItems,const IDs& selected) {
 if(!actor || !actor->Is3DLoaded()){RestoreOwned();return;}
 std::vector<RE::NiPointer<RE::NiAVObject>> candidates;
 std::unordered_set<RE::NiAVObject*> blocked;
 auto* skin=actor->GetSkin();
 for(bool first:{false,true}) {
  if(auto* root=actor->Get3D(first))blocked.insert(root);
  const auto& biped=actor->GetBiped(first);if(!biped)continue;
  for(std::size_t slot{};slot<32U;++slot) {
   const auto& entry=biped->objects[slot];auto* node=entry.partClone.get();if(!node)continue;
   const auto* armor=entry.item?entry.item->As<RE::TESObjectARMO>():nullptr;
   const auto id=armor?armor->GetFormID():0U;
   if(armor && psq::visibility::Eligible(static_cast<std::uint32_t>(armor->GetSlotMask().underlying()),originals.contains(id),selected.contains(id),protectedItems.contains(id),armor==skin))candidates.push_back(entry.partClone);
   else blocked.insert(node);
  }
 }
 // Never cull a common parent containing any protected/new/skin part.
 auto protectedRoots=blocked;
 for(auto* node:protectedRoots) {
  auto* parent=node->parent;
  for(unsigned depth{};parent && depth<128U;++depth,parent=parent->parent)blocked.insert(parent);
 }
 ownership.Reconcile(candidates,blocked);
}
bool IsReady(RE::StaticFunctionTag*) {return ready && SKSE::GetTaskInterface()!=nullptr;}
std::int32_t GetVersion(RE::StaticFunctionTag*) {return 1;}
bool SetHidden(RE::StaticFunctionTag*,RE::Actor* actor,std::vector<RE::TESForm*> originals,std::vector<RE::TESForm*> protectedItems,std::vector<RE::TESForm*> selected) {
 if(!IsReady(nullptr) || !actor || actor!=RE::PlayerCharacter::GetSingleton())return false;
 auto ids=Convert(originals),protection=Convert(protectedItems),parts=Convert(selected);
 const auto actorID=actor->GetFormID();std::uint64_t ticket;
 {std::scoped_lock guard(lock);ticket=++generation;}
 SKSE::GetTaskInterface()->AddTask([ticket,actorID,ids=std::move(ids),protection=std::move(protection),parts=std::move(parts)]{
  std::scoped_lock guard(lock);if(!psq::visibility::Current(ticket,generation))return;
  Apply(RE::TESForm::LookupByID<RE::Actor>(actorID),ids,protection,parts);
 });return true;
}
bool Restore(RE::StaticFunctionTag*) {
 if(!IsReady(nullptr))return false;
 std::uint64_t ticket;{std::scoped_lock guard(lock);ticket=++generation;}
 SKSE::GetTaskInterface()->AddTask([ticket]{std::scoped_lock guard(lock);if(psq::visibility::Current(ticket,generation))RestoreOwned();});return true;
}
bool Register(RE::BSScript::IVirtualMachine* vm) {
 vm->RegisterFunction("GetVersion","PSQAppearance",GetVersion);
 vm->RegisterFunction("IsReady","PSQAppearance",IsReady);
 vm->RegisterFunction("SetHidden","PSQAppearance",SetHidden);
 vm->RegisterFunction("Restore","PSQAppearance",Restore);return true;
}
void OnMessage(SKSE::MessagingInterface::Message* message) {
 if(message->type==SKSE::MessagingInterface::kPreLoadGame || message->type==SKSE::MessagingInterface::kNewGame || message->type==SKSE::MessagingInterface::kPostLoadGame){
  std::scoped_lock guard(lock);++generation;RestoreOwned();
 }
}
}
SKSEPluginLoad(const SKSE::LoadInterface* skse) {
 SKSE::Init(skse);
 const auto version=skse->RuntimeVersion().string();
 std::error_code error;
 ready=std::filesystem::is_regular_file("Data/SKSE/Plugins/version-"+version+".bin",error);
 if(!ready){error.clear();ready=std::filesystem::is_regular_file("Data/SKSE/Plugins/versionlib-"+version+".bin",error);}
 auto* papyrus=SKSE::GetPapyrusInterface();auto* messages=SKSE::GetMessagingInterface();
 if(!papyrus || !messages || !SKSE::GetTaskInterface())return false;
 return papyrus->Register(Register) && messages->RegisterListener(OnMessage);
}


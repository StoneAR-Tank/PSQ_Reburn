#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <mutex>
#include <unordered_set>
#include <vector>
#include "VisibilityPolicy.h"
#include "BodyQueryPolicy.h"

namespace {
std::mutex lock;
std::uint64_t generation{};
bool ready{};
// Only game-thread tasks touch owned scene objects. No raw pointers survive
// a task and the references are released on exit/load/new game or replacement.
psq::visibility::Ownership<RE::NiPointer<RE::NiAVObject>> ownership;
void RestoreOwned() {
 ownership.Reset();
}
using IDs=std::unordered_set<RE::FormID>;
IDs Convert(const std::vector<RE::TESForm*>& forms) {
 IDs out;for(auto* form:forms)if(form)out.insert(form->GetFormID());return out;
}
void Apply(RE::Actor* actor,const IDs& originals,const IDs& protectedItems,const IDs& selected) {
 if(!actor || !actor->Is3DLoaded()){RestoreOwned();return;}
 std::vector<RE::NiPointer<RE::NiAVObject>> candidates;
 std::unordered_set<RE::NiAVObject*> blocked;
 auto* skin=actor->GetSkin();
 for(bool first:{false,true}) {
  if(auto* root=actor->Get3D(first))blocked.insert(root);
  const auto& biped=actor->GetBiped(first);if(!biped)continue;
  for(std::size_t slot{};slot<32U;++slot) {
   const auto& entry=biped->objects[slot];auto* node=entry.partClone.get();if(!node)continue;
   const auto* armor=entry.item?entry.item->As<RE::TESObjectARMO>():nullptr;
   const auto id=armor?armor->GetFormID():0U;
   if(armor && psq::visibility::Eligible(static_cast<std::uint32_t>(armor->GetSlotMask().underlying()),originals.contains(id),selected.contains(id),protectedItems.contains(id),armor==skin))candidates.push_back(entry.partClone);
   else blocked.insert(node);
  }
 }
 // Never cull a common parent containing any protected/new/skin part.
 auto protectedRoots=blocked;
 for(auto* node:protectedRoots) {
  auto* parent=node->parent;
  for(unsigned depth{};parent && depth<128U;++depth,parent=parent->parent)blocked.insert(parent);
 }
 ownership.Reconcile(candidates,blocked);
}
bool IsReady(RE::StaticFunctionTag*) {return ready && SKSE::GetTaskInterface()!=nullptr;}
std::int32_t GetVersion(RE::StaticFunctionTag*) {return 3;}
// These queries are ordinary main-thread Papyrus natives. Never register them
// as callable from tasklets: the actor and ARMA records can change at runtime.
bool UsesUBEModel(const RE::TESObjectARMO* armor, bool skin) {
 if(!armor)return false;
 return psq::body::HasModel(armor->armorAddons.size(),[&](std::size_t index)->std::string_view {
  const auto* addon=armor->armorAddons[static_cast<std::uint32_t>(index)];
  if(!addon)return {};
  const auto* path=addon->bipedModels[RE::SEXES::kFemale].GetModel();
  return path?std::string_view(path):std::string_view{};
 },skin);
}
std::int32_t IsUBEActor(RE::StaticFunctionTag*,RE::Actor* actor) {
 if(!IsReady(nullptr) || !actor || actor!=RE::PlayerCharacter::GetSingleton())return -1;
 const auto* race=actor->GetRace();if(!race)return 0;
 // The player normally has no leveled-creature template. Leave any such
 // unusual case to the original GetLeveledActorBase Papyrus implementation.
 if(actor->extraList.GetByType<RE::ExtraLeveledCreature>())return -1;
 auto* data=RE::TESDataHandler::GetSingleton();if(!data)return -1;
 RE::TESObjectARMO* knownSkin{};
 const auto* plugin=data->LookupModByName("UBE_AllRace.esp");
 if(plugin && plugin->compileIndex!=0xFF) {
  // UBE's skin local ID predates light plugins. Keep any compacted/light
  // edition on the existing game's GetFormFromFile route rather than guess.
  if(plugin->IsLight())return -1;
  knownSkin=data->LookupForm<RE::TESObjectARMO>(83175,"UBE_AllRace.esp");
 }
 const auto* base=actor->GetActorBase();
 return psq::body::FromSkins(race->skin,knownSkin,base?base->skin:nullptr,
  [](const RE::TESObjectARMO* skin){return UsesUBEModel(skin,true);})?1:0;
}
std::int32_t IsUBEEquipment(RE::StaticFunctionTag*,RE::TESObjectARMO* armor) {
 if(!IsReady(nullptr))return -1;
 return UsesUBEModel(armor,false)?1:0;
}
bool SetHidden(RE::StaticFunctionTag*,RE::Actor* actor,std::vector<RE::TESForm*> originals,std::vector<RE::TESForm*> protectedItems,std::vector<RE::TESForm*> selected) {
 if(!IsReady(nullptr) || !actor || actor!=RE::PlayerCharacter::GetSingleton())return false;
 auto ids=Convert(originals),protection=Convert(protectedItems),parts=Convert(selected);
 const auto actorID=actor->GetFormID();std::uint64_t ticket;
 {std::scoped_lock guard(lock);ticket=++generation;}
 SKSE::GetTaskInterface()->AddTask([ticket,actorID,ids=std::move(ids),protection=std::move(protection),parts=std::move(parts)]{
  std::scoped_lock guard(lock);if(!psq::visibility::Current(ticket,generation))return;
  Apply(RE::TESForm::LookupByID<RE::Actor>(actorID),ids,protection,parts);
 });return true;
}
bool Restore(RE::StaticFunctionTag*) {
 if(!IsReady(nullptr))return false;
 std::uint64_t ticket;{std::scoped_lock guard(lock);ticket=++generation;}
 SKSE::GetTaskInterface()->AddTask([ticket]{std::scoped_lock guard(lock);if(psq::visibility::Current(ticket,generation))RestoreOwned();});return true;
}
// API 3: ordinary main-thread read-only batches. Never restore values or
// mutate an actor from this helper; Papyrus retains transaction ownership.
std::vector<float> ReadPoolValues(RE::StaticFunctionTag*, RE::Actor* actor) {
 if(!IsReady(nullptr) || !actor)return {};
 std::vector<float> values(6);
 const RE::ActorValue names[]{RE::ActorValue::kHealth,RE::ActorValue::kMagicka,RE::ActorValue::kStamina};
 for(std::size_t i=0;i<3;++i) {
  values[i]=actor->AsActorValueOwner()->GetActorValue(names[i]);
  values[i+3]=actor->GetActorValueMax(names[i]);
  if(!std::isfinite(values[i]) || !std::isfinite(values[i+3]))return {};
 }
 return values;
}
std::int32_t CheckStatEffects(RE::StaticFunctionTag*, RE::Actor* actor, RE::SpellItem* ability, std::vector<float> magnitudes) {
 if(!IsReady(nullptr))return -1;
 if(!actor || !ability || !actor->HasSpell(ability) || ability->effects.size()<3)return 0;
 for(std::size_t i=0;i<3;++i) {
  const auto* effect=ability->effects[static_cast<std::uint32_t>(i)];
  if(!effect || !effect->baseEffect)return 0;
  const float magnitude=magnitudes.size()>=3?magnitudes[i]:effect->effectItem.magnitude;
  if(magnitude!=0.0f && !actor->AsMagicTarget()->HasMagicEffect(effect->baseEffect))return 0;
 }
 return 1;
}
std::int32_t CheckEquipmentContext(RE::StaticFunctionTag*, RE::Actor* actor, RE::TESRace* expected, RE::TESRace* planned, std::int32_t body) {
 if(!IsReady(nullptr) || !actor)return -1;
 const auto* race=actor->GetRace();
 if((expected && race!=expected) || race!=planned)return 0;
 const auto kind=IsUBEActor(nullptr,actor);
 if(kind<0)return -1;
 return body==kind?1:0;
}
bool Register(RE::BSScript::IVirtualMachine* vm) {
 vm->RegisterFunction("CheckEquipmentContext","PSQAppearance",CheckEquipmentContext);
 vm->RegisterFunction("ReadPoolValues","PSQAppearance",ReadPoolValues);
 vm->RegisterFunction("CheckStatEffects","PSQAppearance",CheckStatEffects);
 vm->RegisterFunction("GetVersion","PSQAppearance",GetVersion);
 vm->RegisterFunction("IsReady","PSQAppearance",IsReady);
 vm->RegisterFunction("IsUBEActor","PSQAppearance",IsUBEActor);
 vm->RegisterFunction("IsUBEEquipment","PSQAppearance",IsUBEEquipment);
 vm->RegisterFunction("SetHidden","PSQAppearance",SetHidden);
 vm->RegisterFunction("Restore","PSQAppearance",Restore);return true;
}
void OnMessage(SKSE::MessagingInterface::Message* message) {
 if(message->type==SKSE::MessagingInterface::kPreLoadGame || message->type==SKSE::MessagingInterface::kNewGame || message->type==SKSE::MessagingInterface::kPostLoadGame){
  std::scoped_lock guard(lock);++generation;RestoreOwned();
 }
}
}
SKSEPluginLoad(const SKSE::LoadInterface* skse) {
 SKSE::Init(skse);
 const auto version=skse->RuntimeVersion().string();
 std::error_code error;
 ready=std::filesystem::is_regular_file("Data/SKSE/Plugins/version-"+version+".bin",error);
 if(!ready){error.clear();ready=std::filesystem::is_regular_file("Data/SKSE/Plugins/versionlib-"+version+".bin",error);}
 auto* papyrus=SKSE::GetPapyrusInterface();auto* messages=SKSE::GetMessagingInterface();
 if(!papyrus || !messages || !SKSE::GetTaskInterface())return false;
 return papyrus->Register(Register) && messages->RegisterListener(OnMessage);
}


// Explicit fourth component distinguishes this helper from the API 1 build.
SKSEPluginInfo(
 .Version = {1,0,0,3},
 .Name = "PSQ Appearance",
 .Author = "PSQ Reburn contributors",
 .SupportEmail = "",
 .StructCompatibility = SKSE::StructCompatibility::Independent,
 .RuntimeCompatibility = SKSE::VersionIndependence::AddressLibrary
)

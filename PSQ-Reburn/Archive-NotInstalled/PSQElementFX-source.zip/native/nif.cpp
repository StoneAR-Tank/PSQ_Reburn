#include "tint.h"
#include <set>
namespace psq {
namespace {
struct Reader {
    const Bytes& bytes; size_t pos=0;
    template<class T>T number(){auto v=at<T>(bytes,pos);pos+=sizeof(T);return v;}
    void advance(size_t n){if(pos>bytes.size()||n>bytes.size()-pos) throw std::runtime_error("truncated NIF");pos+=n;}
    std::string str(){auto n=number<uint32_t>();advance(n);return std::string(reinterpret_cast<const char*>(bytes.data()+pos-n),n);}
};
void copy(Bytes& to,const Bytes& from,size_t first,size_t last){
    if(last<first||last>from.size())throw std::runtime_error("invalid NIF block");
    to.insert(to.end(),from.begin()+first,from.begin()+last);
}
void stringTo(Bytes& to,const std::string& s){
    auto start=to.size();to.resize(start+4);put(to,start,uint32_t(s.size()));to.insert(to.end(),s.begin(),s.end());
}
void tintRGB(Bytes& b,size_t p,bool force=false) {
    float r=at<float>(b,p),g=at<float>(b,p+4),blue=at<float>(b,p+8);
    if(!(r>=0 && g>=0 && blue>=0) || std::max({r,g,blue})>65536) return;
    if(!force && std::max({r,g,blue})-std::min({r,g,blue})<.002f)return;
    auto c=pink(r,g,blue);
    for(int i=0;i<3;++i)put(b,p+4*i,c[i]);
}
struct Block{std::string type;Bytes data;};
size_t shaderStart(const Bytes& b){return 36+4ull*at<uint32_t>(b,4);}
bool usesPalette(const Bytes& b){
    size_t offset=shaderStart(b),base=offset+4+at<uint32_t>(b,offset);
    return (at<uint32_t>(b,offset-24)&16) && at<uint32_t>(b,base+44);
}
std::string forward(std::string original,const TextureLookup& lookup){
    if(original.empty())return original;
    std::string name=original;for(auto& c:name){if(c>='A'&&c<='Z')c+=32;if(c=='/')c='\\';}
    if(name=="textures\\psq\\pinkparticles\\effects\\roseicecrystal.dds" || name=="textures\\psq\\pinkparticles\\effects\\icespellbacklight.dds")return original;
    if(name.ends_with("_n.dds")||name.ends_with("_msn.dds")||name.ends_with("_sk.dds")||name.find("cubemaps\\")!=std::string::npos)return original;
    auto changed=lookup(original);
    if(!changed)throw std::runtime_error("unavailable shader texture");
    return "textures\\"+*changed;
}
}
Bytes tintNif(const Bytes& src,const TextureLookup& mapTexture){
    auto line=std::find(src.begin(),src.end(),'\n');
    if(line==src.end() || line-src.begin()>120) throw std::runtime_error("missing NIF header");
    Reader r{src,size_t(line-src.begin()+1)};
    if(r.number<uint32_t>()!=0x14020007||r.number<uint8_t>()!=1||r.number<uint32_t>()!=12)throw std::runtime_error("unsupported NIF");
    unsigned n=r.number<uint32_t>();
    const auto version=r.number<uint32_t>();
    if(!n||n>100000 || (version!=100 && version!=83)) throw std::runtime_error("unsupported NIF stream");
    for(int i=0;i<3;++i)r.advance(r.number<uint8_t>());
    std::vector<std::string> types(r.number<uint16_t>());for(auto& k:types)k=r.str();
    std::vector<unsigned> indices(n);for(auto& i:indices)i=r.number<uint16_t>();
    const auto sizesAt=r.pos;std::vector<unsigned> sizes(n);for(auto& s:sizes)s=r.number<uint32_t>();

    const auto namesAt=r.pos;
    auto ns=r.number<uint32_t>();r.advance(4);
    if(ns>(src.size()-r.pos)/4)throw std::runtime_error("invalid NIF strings");
    std::vector<std::string> names;names.reserve(ns);
    for(unsigned i=0;i<ns;++i)names.push_back(r.str());
    const auto namesEnd=r.pos;
    r.advance(4ull*r.number<uint32_t>());
    Bytes out(src.begin(),src.begin()+r.pos);
    std::vector<Block> blocks;blocks.reserve(n);
    for(unsigned i=0;i<n;++i){auto start=r.pos;r.advance(sizes[i]);blocks.push_back({types.at(indices[i]),Bytes(src.begin()+start,src.begin()+r.pos)});}
    // Do not transplant invalid controllers into another model. An authored
    // replacement can retain sequence blocks for glow geometry it deleted.
    for(auto& node:blocks){
        if((node.type=="BSEffectShaderPropertyColorController" || node.type=="BSEffectShaderPropertyFloatController") &&
           at<int32_t>(node.data,22)<0)
            throw std::runtime_error("missing target on "+node.type);
    }
    // Only follow actual shader-color controller links; animated positions and palette coordinates are not colors.
    std::set<int> controllers, interps, keys;
    for(unsigned i=0;i<n;++i){auto& node=blocks[i];if(node.type!="BSEffectShaderPropertyColorController")continue;
        int target=at<int32_t>(node.data,22);if(target<0||blocks.at(target).type!="BSEffectShaderProperty"||usesPalette(blocks.at(target).data))continue;
        controllers.insert(i);int j=at<int32_t>(node.data,26);if(j>=0)interps.insert(j);
    }
    for(auto& node:blocks)if(node.type=="NiControllerSequence"){
        unsigned count=at<uint32_t>(node.data,4);if(count>node.data.size()/29)throw std::runtime_error("invalid controller sequence");
        for(unsigned j=0;j<count;++j){int ip=at<int32_t>(node.data,12+29*j),ctl=at<int32_t>(node.data,16+29*j);if(ip>=0 && controllers.contains(ctl))interps.insert(ip);}
    }
    for(int i:interps){auto& item=blocks.at(i);if(item.type=="NiPoint3Interpolator"){
        tintRGB(item.data,0);int key=at<int32_t>(item.data,12);if(key>=0)keys.insert(key);
    }}
    for(int i:keys){auto& item=blocks.at(i);if(item.type!="NiPosData")continue;
        auto count=at<uint32_t>(item.data,0);if(!count)continue;auto mode=at<uint32_t>(item.data,4);
        size_t stride=mode==1?16:mode==2?40:mode==3?28:0;if(!stride||8ull+stride*count!=item.data.size())throw std::runtime_error("unsupported animation");
        for(unsigned j=0;j<count;++j)tintRGB(item.data,12+j*stride);
    }
// Invoked on the decoded local NIF block graph, before serializing it.
// This ice glaze uses a normal map in its diffuse slot and has zero emission.
// Convert only those known PSQ ice surfaces; slot 1 is always the original normal.
{
    std::set<int> shells;
    int blend=-1;
    for(size_t i=0;i<blocks.size() && blend<0;++i){
        const auto& b=blocks[i].data;
        if(blocks[i].type!="NiAlphaProperty" || b.size()!=15 || at<int32_t>(b,8)!=-1)continue;
        auto flags=at<uint16_t>(b,12);
        if((flags&1) && ((flags>>1)&15)==6 && !(flags&512))blend=int(i);
    }
    auto norm=[](std::string path){
        for(auto& c:path){if(c=='/')c='\\';if(c>='A'&&c<='Z')c+=32;}
        return path;
    };
    for(size_t i=0;i<blocks.size();++i){
        auto& b=blocks[i].data;
        if(blocks[i].type!="BSLightingShaderProperty")continue;
        size_t fl=16ull+4ull*at<uint32_t>(b,8),rgb=fl+28;
        int t=at<int32_t>(b,rgb-4);
        if(t<0||blocks.at(t).type!="BSShaderTextureSet")continue;
        Bytes& ts=blocks[t].data;
        Reader tr{ts};unsigned cnt=tr.number<uint32_t>();
        if(cnt>16)throw std::runtime_error("invalid ice surface texture count");
        std::vector<std::string> maps;for(unsigned j=0;j<cnt;++j)maps.push_back(tr.str());
        if(tr.pos!=ts.size())throw std::runtime_error("invalid ice texture data");
        constexpr auto glacier="textures\\effects\\glacierslabsmall_n.dds";
        constexpr auto shell="textures\\PSQ\\PinkParticles\\effects\\RoseIceCrystal.dds";
        if(cnt<2||norm(maps[1])!=glacier)continue;
        bool change=false;
        if(cnt>7 && norm(maps[7])=="textures\\effects\\icespellbacklight.dds"){
            maps[7]="textures\\PSQ\\PinkParticles\\effects\\icespellbacklight.dds";change=true;
        }
        if((norm(maps[0])==glacier || norm(maps[0])==norm(shell)) && (at<uint32_t>(b,fl)&(1u<<15))){
            maps[0]=shell;change=true;
            put(b,fl,(at<uint32_t>(b,fl)&~((1u<<15)|(1u<<16)))|(1u<<22));
            put(b,fl+4,at<uint32_t>(b,fl+4)&~1u);
            put(b,rgb,.50f);put(b,rgb+4,.045f);put(b,rgb+8,.23f);put(b,rgb+12,.85f);
            put(b,rgb+20,.80f);put(b,rgb+24,0.f);
            put(b,rgb+32,1.f);put(b,rgb+36,.36f);put(b,rgb+40,.67f);
            shells.insert(int(i));
        }
        if(change){Bytes outTex(4);put(outTex,0,cnt);for(auto& p:maps)stringTo(outTex,p);ts.swap(outTex);}
    }
    for(auto& item:blocks){
        if(item.type!="BSTriShape")continue;
        auto& b=item.data;size_t off=92ull+4ull*at<uint32_t>(b,4);
        if(shells.contains(at<int32_t>(b,off)) && at<int32_t>(b,off+4)<0){
            if(blend<0)throw std::runtime_error("no matching ice transparency property");
            put(b,off+4,int32_t(blend));
        }
    }
}


    // A BSValueNode calls a globally registered addon particle; it is also
    // valid for an entire impact model to consist only of these nodes.
    constexpr uint32_t mapped[]={ 0,4,5,6,9,10,11,14,15,18,23,24,25,26,33,34,35,36,45,64,65,66,72,73,74,80,81,88 };
    bool shade=false, changedName=false;
    for(auto& node:blocks){
        if(node.type!="BSValueNode")continue;
        auto& b=node.data;
        if(b.size()<85)throw std::runtime_error("invalid addon-node layout");
        const auto old=at<uint32_t>(b,b.size()-5);
        if(std::find(std::begin(mapped),std::end(mapped),old)==std::end(mapped))
            throw std::runtime_error("unsupported addon index "+std::to_string(old));
        put(b,b.size()-5,old+2840u);
        const auto name=at<uint32_t>(b,0);
        if(name!=UINT32_MAX){
            auto& target=names.at(name);
            const auto standard="addonnode"+std::to_string(old);
            if(target.size()==standard.size() && std::equal(target.begin(),target.end(),standard.begin(),
                    [](char a,char b){return (a>='A'&&a<='Z'?a+32:a)==b;})){
                target="AddOnNode"+std::to_string(old+2840u);
                changedName=true;
            }
        }
        shade=true;
    }
    if(changedName){
        Bytes header(out.begin(),out.begin()+namesAt);
        auto at=header.size();header.resize(at+8);
        put(header,at,ns);
        uint32_t maximum=0;
        for(auto& name:names){maximum=std::max(maximum,uint32_t(name.size()));stringTo(header,name);}
        put(header,at+4,maximum);
        copy(header,out,namesEnd,out.size());out.swap(header);
    }
    for(unsigned i=0;i<n;++i){auto& type=blocks[i].type;auto& b=blocks[i].data;
        if(type=="BSEffectShaderProperty"){
            const size_t sp=shaderStart(b);Reader br{b,sp};auto srcName=br.str();auto base=br.pos;br.advance(44);auto pal=br.str();
            if(br.pos!=b.size())throw std::runtime_error("unexpected shader layout");
            if(!usesPalette(b)){if(!(at<uint32_t>(b,sp-24)&(1u<<15)))srcName=forward(srcName,mapTexture);tintRGB(b,base+20,true);}
            pal=forward(pal,mapTexture);Bytes nb;copy(nb,b,0,sp);stringTo(nb,srcName);copy(nb,b,base,base+44);stringTo(nb,pal);b=std::move(nb);shade=true;
        } else if(type=="BSShaderTextureSet"){
            Reader br{b,4};auto count=at<uint32_t>(b,0);Bytes nb(b.begin(),b.begin()+4);
            if(count>16)throw std::runtime_error("invalid texture slots");
            for(unsigned s=0;s<count;++s){auto name=br.str();if(s==0||s==2||s==3)name=forward(name,mapTexture);stringTo(nb,name);}
            if(br.pos!=b.size())throw std::runtime_error("invalid texture set");b=std::move(nb);shade=true;
        } else if(type=="BSLightingShaderProperty"){
            auto off=44ull+4ull*at<uint32_t>(b,8);tintRGB(b,off);tintRGB(b,off+32);
        } else if(type=="BSPSysSimpleColorModifier"){
            if(b.size()<48)throw std::runtime_error("invalid particle color");
            for(int j=0;j<3;++j)tintRGB(b,b.size()-48+j*16);
        } else if(type=="NiTriShapeData" && version==83){
            // LE geometry stores floating point vertex colors after its bounds.
            // Match this exact layout and preserve alpha and all vector data.
            size_t verts=at<uint16_t>(b,4),p=9;
            if(at<uint8_t>(b,8))p+=verts*12;
            auto flags=at<uint16_t>(b,p);p+=6;
            auto normals=at<uint8_t>(b,p++);
            if(normals)p+=verts*((flags&0xf000)?36:12);
            p+=16;
            if(at<uint8_t>(b,p++)){
                if(p>b.size() || verts*16>b.size()-p)throw std::runtime_error("invalid LE vertex colors");
                for(size_t v=0;v<verts;++v)tintRGB(b,p+v*16);
            }
        } else if(type=="BSTriShape"){
            size_t base=100+4ull*at<uint32_t>(b,4);auto attrs=at<uint16_t>(b,base+5);
            int s=at<int32_t>(b,base-8);
            if((attrs&512) && !(s>=0 && blocks.at(s).type=="BSEffectShaderProperty" && usesPalette(blocks.at(s).data))){
                auto tris=at<uint16_t>(b,base+8),verts=at<uint16_t>(b,base+10);
                auto len=at<uint32_t>(b,base+12);unsigned stride=4*(at<uint8_t>(b,base)&15);
                size_t rgba=(attrs&16?16:0)+(attrs&32?4:0)+(attrs&128?4:0)+((attrs&128)&&(attrs&256)?4:0);
                if(len && verts){
                    if(stride*verts+6u*tris!=len || rgba+4>stride || base+16+len>b.size())throw std::runtime_error("unsupported vertex layout");
                    for(unsigned j=0;j<verts;++j){auto p=base+16+stride*j+rgba;
                        if(std::max({b[p],b[p+1],b[p+2]})-std::min({b[p],b[p+1],b[p+2]})>3){
                            auto v=pink(b[p],b[p+1],b[p+2]);for(int c=0;c<3;++c)b[p+c]=uint8_t(std::lround(v[c]));
                        }
                    }
                }
            }
        } else if(type=="NiPSysSphereEmitter"||type=="NiPSysCylinderEmitter"||type=="NiPSysBoxEmitter"||type=="NiPSysMeshEmitter"){
            tintRGB(b,37);
        }
        put(out,sizesAt+4*i,static_cast<uint32_t>(b.size()));out.insert(out.end(),b.begin(),b.end());
    }
    if(!shade)throw std::runtime_error("no supported shader");
    copy(out,src,r.pos,src.size());return out;
}
}

#include "SKSE/Impl/PCH.h"
#include "RE/Skyrim.h"
#include "SKSE/SKSE.h"
#include "tint.h"
#include "shaders.h"
#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <Windows.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <unordered_map>

namespace fs=std::filesystem;
namespace psq {
namespace {
constexpr auto meshPrefix="PSQ\\LocalElementFX\\";
constexpr auto layoutsVersion="PSQFX3-particles";
struct ModelPair {uint32_t donor, copy; uint64_t stock; const char* plugin;};
struct EffectPair {uint32_t donor,copy;};
struct StockTexture {const char* source;const char* relative;uint64_t stock;};
struct Baseline {const char* source;uint64_t stock;};
#include "formpairs.inc"
struct Handle {
    HANDLE value=INVALID_HANDLE_VALUE;
    ~Handle(){if(value!=INVALID_HANDLE_VALUE)CloseHandle(value);}
    Handle()=default;
    Handle(const Handle&)=delete;
};
Handle owner;
fs::path root;
std::map<std::string,std::string> cache;
std::map<std::string,std::optional<std::string>> textures;
std::map<std::string,bool> textureChanged;
std::map<std::string,unsigned> slots;
std::unordered_set<unsigned> taken;
std::map<uint32_t,RE::TESForm*> liveDonors;
size_t newlyWritten=0;
std::string status;
std::string lower(std::string s){for(auto& c:s){if(c=='/')c='\\';if(c>='A'&&c<='Z')c+=32;} return s;}
std::optional<std::string> normalized(std::string_view input,std::string prefix,std::string suffix){
    auto path=lower(std::string(input));
    if(path.starts_with(prefix+"\\"))path.erase(0,prefix.size()+1);
    if(path.empty()||!path.ends_with(suffix)||path.find(':')!=std::string::npos||path.find("..")!=std::string::npos||path.front()=='\\'||path.size()>235)return {};
    return prefix+"\\"+path;
}
fs::path handlePath(HANDLE h){
    std::wstring buf(32768,L'\0');auto size=GetFinalPathNameByHandleW(h,buf.data(),DWORD(buf.size()),FILE_NAME_NORMALIZED);
    if(!size||size>=buf.size())throw std::runtime_error("cannot resolve PSQ resource owner");
    buf.resize(size);return fs::path(buf).lexically_normal();
}
bool owns(HANDLE file,const fs::path& rel){
    if(file==INVALID_HANDLE_VALUE)return false;
    auto actual=handlePath(file).native(),want=(root/rel).lexically_normal().native();
    return CompareStringOrdinal(actual.c_str(),-1,want.c_str(),-1,TRUE)==CSTR_EQUAL;
}
uint64_t digest(const Bytes& data){uint64_t h=14695981039346656037ull;for(uint8_t v:data)h=(h^v)*1099511628211ull;return h;}
std::string signature(const Bytes& b){return std::format("{}-{:x}",layoutsVersion,digest(b));}
Bytes read(std::string_view path,size_t limit){
    RE::BSResourceNiBinaryStream raw{std::string(path)};
    if(!raw.good()||!raw.stream || !raw.stream->totalSize || raw.stream->totalSize>limit)throw std::runtime_error("missing or oversized resource");
    Bytes bytes(raw.stream->totalSize);if(!raw.read(bytes.data(),uint32_t(bytes.size())))throw std::runtime_error("resource read failed");
    return bytes;
}
bool openCache(){
    const fs::path marker="SKSE/Plugins/PSQElementFX.owner";
    // Exclusive marker ownership prevents two profiles from rewriting the same alias slots concurrently.
    owner.value=CreateFileW((fs::path("Data")/marker).c_str(),GENERIC_READ,0,nullptr,OPEN_EXISTING,0,nullptr);
    if(owner.value==INVALID_HANDLE_VALUE){status="Cannot open the PSQ owner marker exclusively (another game may be running).";return false;}
    root=handlePath(owner.value).parent_path().parent_path().parent_path();
    char mark[64]{};DWORD n=0;
    if(!ReadFile(owner.value,mark,63,&n,nullptr)||std::string_view(mark,n)!="PSQ Reburn local elemental VFX slots v1\n"){status="Invalid PSQ optional ownership marker.";return false;}
    auto idx=fs::path("SKSE/Plugins/PSQElementFX.cache");
    Handle fp;fp.value=CreateFileW((fs::path("Data")/idx).c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);
    if(!owns(fp.value,idx)){status="The cache index and the owner marker have different MO2 providers.";return false;}
    auto size=GetFileSize(fp.value,nullptr);if(size>128*1024)return true;
    std::string s(size,'\0');if(!ReadFile(fp.value,s.data(),size,&n,nullptr))return true;
    std::istringstream lines(s);
    for(std::string row;std::getline(lines,row);){auto p=row.find('\t');if(p!=std::string::npos&&p<250)cache[row.substr(0,p)]=row.substr(p+1);}
    return true;
}
std::string stamp(HANDLE f){BY_HANDLE_FILE_INFORMATION info{};
    if(!GetFileInformationByHandle(f,&info))throw std::runtime_error("cannot stat private alias");
    return std::format("{}:{}:{}",info.nFileSizeLow,info.ftLastWriteTime.dwHighDateTime,info.ftLastWriteTime.dwLowDateTime);
}
bool cacheHit(const std::string& rel,const std::string& sig){
    auto it=cache.find(rel);if(it==cache.end())return false;
    Handle fp;fp.value=CreateFileW((fs::path("Data")/rel).c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);
    return owns(fp.value,rel)&&it->second==sig+":"+stamp(fp.value);
}
bool save(const std::string& rel,const Bytes& bytes,const std::string& sig){
    Handle fp;fp.value=CreateFileW((fs::path("Data")/rel).c_str(),GENERIC_WRITE|GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);
    if(!owns(fp.value,rel))return false;
    if(newlyWritten+bytes.size()>384ull*1024*1024)return false;
    DWORD n=0;if(!WriteFile(fp.value,bytes.data(),DWORD(bytes.size()),&n,nullptr)||n!=bytes.size()||!SetEndOfFile(fp.value)||!FlushFileBuffers(fp.value))return false;
    // Set the timestamp before recording it; Windows otherwise finalizes it only after closing.
    FILETIME now;GetSystemTimeAsFileTime(&now);SetFileTime(fp.value,nullptr,nullptr,&now);
    if(!sig.empty())cache[rel]=sig+":"+stamp(fp.value);
    newlyWritten+=bytes.size();return true;
}
std::optional<std::string> tintTexture(const std::string& key){
    auto bytes=read(key,24*1024*1024);
    auto hashed=digest(bytes);
    for(const auto& stock:stockTextures)
        if(key==lower(stock.source) && hashed==stock.stock)return std::string(stock.relative);
    if(slots.size()>=128)return {};
    unsigned n=uint32_t(digest(Bytes(key.begin(),key.end()))%128);
    while(taken.contains(n))n=(n+1)%128;
    taken.insert(n);slots[key]=n;
    auto name=std::format("PSQ\\LocalElementFX\\t{:03}.dds",n);
    auto file="textures\\"+name,sig=std::format("{}-{:x}",layoutsVersion,hashed);
    if(cacheHit(file,sig))return name;
    auto updated=tintDDS(bytes);if(!save(file,updated,sig))return {};
    return name;
}
RE::TESModel* model(RE::TESForm* form){
    if(!form)return nullptr;
    switch(form->GetFormType()){
        case RE::FormType::Projectile:return form->As<RE::BGSProjectile>();
        case RE::FormType::ArtObject:return form->As<RE::BGSArtObject>();
        case RE::FormType::Impact:return form->As<RE::BGSImpactData>();
        case RE::FormType::Explosion:return form->As<RE::BGSExplosion>();
        case RE::FormType::Hazard:return form->As<RE::BGSHazard>();
        case RE::FormType::AddonNode:return form->As<RE::BGSAddonNode>();
        case RE::FormType::Static:return form->As<RE::TESObjectSTAT>();
        case RE::FormType::Light:return form->As<RE::TESObjectLIGH>();
        case RE::FormType::Activator:return form->As<RE::TESObjectACTI>();
        default:return nullptr;
    }
}
bool runePair(const ModelPair& pair){
    return std::string_view(pair.plugin)=="StrangeRunes.esp" && pair.copy>=0x850 && pair.copy<=0x858;
}
const char* destinationPlugin(const ModelPair& pair){
    return runePair(pair)?"PSQ - Strange Runes.esp":"PSQ PlayerSuccubusQuest.esm";
}
bool adapt(RE::TESDataHandler& forms,const ModelPair& pair){
    auto dest=model(forms.LookupForm(pair.copy,destinationPlugin(pair)));
    auto it=liveDonors.find(pair.copy);
    if(it!=liveDonors.end() && !it->second)return false;
    auto src=model(it!=liveDonors.end()?it->second:forms.LookupForm(pair.donor,pair.plugin));
    if(!src || !dest || src==dest || !src->GetModel() || !dest->GetModel())return false;
    auto dst=lower(dest->GetModel());
    if(runePair(pair)){
        static constexpr const char* allowed[]={"fireleft","frostleft","shockleft","fireright","frostright",
                                               "shockright","fireritual","frostritual","shockritual"};
        if(dst!=std::format("psq\\roserunes\\{}.nif",allowed[pair.copy-0x850]))return false;
    }else if(pair.copy==0xB722){
        if(dst!="psq\\rosestorm\\ritualhands.nif")return false;
    }else if(!dst.starts_with("psq\\pinkelements\\")&&!dst.starts_with("psq\\pinklightning\\")&&!dst.starts_with("psq\\pinkmysticism\\")&&!dst.starts_with("psq\\pinkparticles\\"))return false;
    auto input=normalized(src->GetModel(),"meshes",".nif");if(!input)return false;
    auto data=read(*input,16*1024*1024);
    // Use the winning BSResource stream for both loose and BSA texture-only replacements.
    if(digest(data)==pair.stock){
        bool replaced=false;
        tintNif(data,[&](std::string_view field)->std::optional<std::string>{
            auto name=normalized(field,"textures",".dds");if(!name)return {};
            auto [it,first]=textureChanged.try_emplace(*name,true);
            if(first){
                for(auto& entry:textureDefaults)if(*name==lower(entry.source)){
                    it->second=digest(read(*name,24*1024*1024))!=entry.stock;break;
                }
            }
            replaced|=it->second;
            return name->substr(9);
        });
        if(!replaced)return false;
    }
    auto result=tintNif(data,localPinkTexture);
    auto name=std::format("PSQ\\LocalElementFX\\{}{:06x}.nif",runePair(pair)?"r":"m",pair.copy);
    auto output="meshes\\"+name,sig=signature(result);
    if(!cacheHit(output,sig)&&!save(output,result,sig))return false;
    if(read(output,16*1024*1024)!=result)return false;
    dest->SetModel(name.c_str());return true;
}
void followEffectArt(RE::TESDataHandler& forms){
    // A mod may swap the casting or impact art pointer even when the original art form is untouched.
    std::map<RE::TESForm*,uint32_t> allow;
    for(auto& pair:pairs)if(auto* f=forms.LookupForm(pair.copy,destinationPlugin(pair)))allow[f]=pair.copy;
    for(auto& pair:hitShader::pairs)if(auto* f=forms.LookupForm(pair.copy,"PSQ PlayerSuccubusQuest.esm"))allow[f]=pair.copy;
    auto follow=[&](RE::TESForm* dest, RE::TESForm* donor){
        if(!dest || !allow.contains(dest))return;
        if(donor && dest->GetFormType()!=donor->GetFormType())donor=nullptr;
        auto [it,added]=liveDonors.try_emplace(allow.at(dest),donor);
        if(!added && it->second!=donor)it->second=nullptr; // conflicting routes keep the shipped PSQ copy
    };
    for(auto& pair:effects){
        auto* d=forms.LookupForm<RE::EffectSetting>(pair.donor,"Skyrim.esm");
        auto* p=forms.LookupForm<RE::EffectSetting>(pair.copy,"PSQ PlayerSuccubusQuest.esm");
        if(!d||!p)continue;
        follow(p->data.castingArt,d->data.castingArt);follow(p->data.hitEffectArt,d->data.hitEffectArt);
        follow(p->data.projectileBase,d->data.projectileBase);follow(p->data.explosion,d->data.explosion);
        follow(p->data.enchantEffectArt,d->data.enchantEffectArt);
        follow(p->data.effectShader,d->data.effectShader);follow(p->data.enchantShader,d->data.enchantShader);
    }
}
}
std::optional<std::string> localPinkTexture(std::string_view source){
    auto k=normalized(source,"textures",".dds");if(!k)return {};
    auto it=textures.find(*k);if(it!=textures.end())return it->second;
    std::optional<std::string> v;
    try{v=tintTexture(*k);}catch(const std::exception&){}
    textures.emplace(*k,v);return v;
}
void run(){
    auto* forms=RE::TESDataHandler::GetSingleton();
    unsigned linked=0;
    unsigned shaders=0, unsupported=0;
    std::ostringstream skipped;
    try{
        if(!forms||!forms->LookupLoadedModByName("PSQ PlayerSuccubusQuest.esm"))status="PSQ master is not active.";
        else if(openCache()){
            followEffectArt(*forms);
            for(auto& pair:pairs){
                try{linked+=adapt(*forms,pair);}catch(const std::exception& e){++unsupported; skipped << std::format("{}:{:06X} -> PSQ:{:06X}: {}\n",pair.plugin,pair.donor,pair.copy,e.what());}
            }
            shaders=applyLocalEffectShaders(liveDonors);
            std::string index;for(auto& [key,value]:cache)index+=key+"\t"+value+"\n";
            if(!save("SKSE/Plugins/PSQElementFX.cache",Bytes(index.begin(),index.end()),""))status="Could not persist cache metadata.";
        }
    }catch(const std::exception& e){status=e.what();}
    if(auto dir=SKSE::log::log_directory()){
        std::ofstream log(*dir/"PSQElementFX.log",std::ios::trunc);
        log<<"PSQ local element FX: "<<(status.empty()?"ready":status)<<"\nPrivate PSQ models: "<<linked
           <<"\nHit shaders: "<<shaders<<"\nUnrecognized models: "<<unsupported<<"\nNew cached bytes: "<<newlyWritten<<"\n"<<skipped.str();
    }
}
}
extern "C" __declspec(dllexport) constinit auto SKSEPlugin_Version=[]{
    SKSE::PluginVersionData v;v.PluginVersion({1,0,0,0});v.PluginName("PSQ Element FX");v.AuthorName("PSQ Reburn");
    v.UsesAddressLibrary();v.UsesUpdatedStructs();return v;
}();
extern "C" __declspec(dllexport) bool SKSEPlugin_Query(const SKSE::QueryInterface* skse,SKSE::PluginInfo* info){
    info->infoVersion=SKSE::PluginInfo::kVersion;info->name="PSQElementFX";info->version=1;
    return !skse->IsEditor() && skse->RuntimeVersion()==SKSE::RUNTIME_SSE_1_5_97;
}
extern "C" __declspec(dllexport) bool SKSEPlugin_Load(const SKSE::LoadInterface* skse){
    SKSE::Init(skse);
    return SKSE::GetMessagingInterface()->RegisterListener([](SKSE::MessagingInterface::Message* msg){
        if(msg->type==SKSE::MessagingInterface::kDataLoaded)try{psq::run();}catch(const std::exception&){}
    });
}


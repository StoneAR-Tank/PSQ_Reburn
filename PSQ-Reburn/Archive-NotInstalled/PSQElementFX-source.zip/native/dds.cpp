#include "tint.h"
#define BCDEC_STATIC
#define BCDEC_IMPLEMENTATION
#include "bcdec.h"

namespace psq {
using Decoder=void (*)(const void*,void*,int);
Bytes tintDDS(const Bytes& src) {
    if(src.size()<128 || at<uint32_t>(src,0)!=0x20534444 || at<uint32_t>(src,4)!=124 ||
       at<uint32_t>(src,76)!=32 || at<uint32_t>(src,112)!=0) throw std::runtime_error("not a 2D DDS");
    uint32_t w=at<uint32_t>(src,16),h=at<uint32_t>(src,12),levels=std::max(1u,at<uint32_t>(src,28));
    if(!w || !h || w>8192 || h>8192 || uint64_t(w)*h>4096ull*4096 || levels>1+std::bit_width(std::max(w,h))-1) throw std::runtime_error("texture dimensions");
    uint32_t four=at<uint32_t>(src,84),fmt=0;
    size_t pos=128;
    if(four==0x30315844) {
        fmt=at<uint32_t>(src,128); pos=148;
        if(at<uint32_t>(src,132)!=3 || at<uint32_t>(src,136)!=0 || at<uint32_t>(src,140)!=1)
            throw std::runtime_error("DDS array/volume");
    }
    Decoder decode=nullptr;
    size_t block=16;
    if(four==0x31545844 || fmt==71 || fmt==72) {decode=bcdec_bc1; block=8;}
    else if(four==0x33545844 || fmt==74 || fmt==75) decode=bcdec_bc2;
    else if(four==0x35545844 || fmt==77 || fmt==78) decode=bcdec_bc3;
    else if(fmt==98 || fmt==99) decode=bcdec_bc7;
    std::array<uint32_t,4> masks{};
    if(!decode) {
        if(four==0 && at<uint32_t>(src,88)==32) for(int c=0;c<4;++c) masks[c]=at<uint32_t>(src,92+c*4);
        else if(fmt==28||fmt==29) masks={255u,65280u,16711680u,4278190080u};
        else if(fmt==87||fmt==91) masks={16711680u,65280u,255u,4278190080u};
        else throw std::runtime_error("unsupported DDS format");
        for(int i=0;i<4;++i) if((masks[i] || i<3) && std::popcount(masks[i])!=8) throw std::runtime_error("Unsupported color mask");
    }
    // Preserve sRGB tagging when decoding DX10 inputs. Keep every alpha value and mip level.
    bool srgb=fmt==72||fmt==75||fmt==78||fmt==99||fmt==29||fmt==91;
    Bytes out(src.begin(),src.begin()+128);
    put(out,8,(at<uint32_t>(out,8)&~0x80000u)|8u); put(out,20,w*4); put(out,80,0x41u);
    put(out,84,0u); put(out,88,32u);
    for(int c=0;c<4;++c) put(out,92+c*4,255u<<(c*8));
    if(srgb){ put(out,80,4u);put(out,84,0x30315844u); for(int i=88;i<=104;i+=4) put(out,i,0u);
              out.resize(148);put(out,128,29u);put(out,132,3u);put(out,140,1u);}
    for(uint32_t level=0;level<levels;++level,w=std::max(1u,w/2),h=std::max(1u,h/2)){
        auto start=out.size(); out.resize(start+size_t(w)*h*4);
        auto pixel=[&](uint32_t x,uint32_t y,const uint8_t* rgba){
            auto c=pink(rgba[0],rgba[1],rgba[2]);
            auto dest=out.data()+start+4*(x+size_t(y)*w);
            for(int i=0;i<3;++i) dest[i]=static_cast<uint8_t>(std::lround(c[i]));
            dest[3]=rgba[3];
        };
        if(decode) {
            for(uint32_t y=0;y<h;y+=4)for(uint32_t x=0;x<w;x+=4){
                if(pos+block>src.size()) throw std::runtime_error("truncated DDS mip");
                alignas(16) uint8_t pixels[64]; decode(src.data()+pos,pixels,16);pos+=block;
                for(uint32_t j=0;j<4 && y+j<h;++j)for(uint32_t i=0;i<4 && x+i<w;++i)pixel(x+i,y+j,pixels+(i+j*4)*4);
            }
        } else for(uint32_t y=0;y<h;++y)for(uint32_t x=0;x<w;++x){
            uint32_t c=at<uint32_t>(src,pos);pos+=4;
            uint8_t rgba[4];
            for(int i=0;i<4;++i) rgba[i]=masks[i]?(c&masks[i])>>std::countr_zero(masks[i]):255;
            pixel(x,y,rgba);
        }
    }
    if(pos!=src.size()) throw std::runtime_error("unexpected DDS data");
    return out;
}
}

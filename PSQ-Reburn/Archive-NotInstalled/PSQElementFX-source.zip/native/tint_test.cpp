#include "tint.h"
#include <fstream>
#include <iostream>
#include <iterator>
int main(int argc,char** argv){
    if(argc!=4)return 2;
    try {
        std::ifstream s(argv[2],std::ios::binary);psq::Bytes data((std::istreambuf_iterator<char>(s)),{});
        if(!s || data.empty())return 3;
        auto converted=std::string_view(argv[1])=="dds"?psq::tintDDS(data):psq::tintNif(data,[&](std::string_view path){if(std::string_view(argv[1])=="probe")std::cout<<path<<"\n";return std::optional<std::string>(std::string("PSQ\\Test\\")+std::string(path.substr(path.find_last_of("/\\")+1)));});
        std::ofstream out(argv[3],std::ios::binary);out.write(reinterpret_cast<const char*>(converted.data()),converted.size());
        return !out;
    }catch(const std::exception& e){std::cerr<<e.what();return 4;}
}

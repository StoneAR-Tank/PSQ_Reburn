#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <map>
#include <optional>
#include <string>
#include <string_view>

#include "RE/Skyrim.h"

namespace psq
{
    // Returns a shader texture path relative to Data/textures, or nullopt if
    // this installed DDS could not be converted to a PSQ-private resource.
    std::optional<std::string> localPinkTexture(std::string_view path);
}

namespace psq::hitShader
{
    inline void tint(RE::Color& c, bool paletteInput = false)
    {
        const auto high = std::max({ c.red, c.blue, c.green });
        const auto low = std::min({ c.red, c.blue, c.green });
        if (paletteInput && high == low)
            return;
        c.red = high;
        c.green = static_cast<std::uint8_t>(std::lround(.13 * high + .66 * low));
        c.blue = static_cast<std::uint8_t>(std::lround(.53 * high + .39 * low));
    }

    inline std::optional<std::string> texture(const RE::TESTexture& entry, bool isLookupInput)
    {
        std::string path(entry.textureName.c_str() ? entry.textureName.c_str() : "");
        if (path.empty() || isLookupInput)
            return path;
        return localPinkTexture(path);
    }

    inline bool import(const RE::TESEffectShader& donor, RE::TESEffectShader& dest)
    {
        using Flags = RE::EffectShaderData::Flags;
        if (donor.data.addonModels != dest.data.addonModels)
            return false;  // A distinct debris model needs its own isolated art path.
        const bool membranePalette = donor.data.flags.any(Flags::kGreyscaleToColor) &&
            !donor.membranePaletteTexture.textureName.empty();
        const bool particlePalette = donor.data.flags.any(Flags::kParticleGreyscaleColor) &&
            !donor.particlePaletteTexture.textureName.empty();
        // Grayscale inputs drive a palette lookup. Only the palette receives color.
        const std::array<std::optional<std::string>, 4> mapped = {
            texture(donor.fillTexture, membranePalette), texture(donor.particleShaderTexture, particlePalette),
            texture(donor.membranePaletteTexture, false), texture(donor.particlePaletteTexture, false)
        };
        if (std::any_of(mapped.begin(), mapped.end(), [](const auto& item) { return !item; }))
            return false;
        auto data = donor.data;
        tint(data.fillTextureEffectColorKey1, membranePalette);
        tint(data.fillTextureEffectColorKey2, membranePalette);
        tint(data.fillTextureEffectColorKey3, membranePalette);
        tint(data.edgeEffectColor);
        tint(data.edgeColor);
        tint(data.colorKey1, particlePalette);
        tint(data.colorKey2, particlePalette);
        tint(data.colorKey3, particlePalette);
        dest.data = data;
        dest.fillTexture.textureName = mapped[0]->c_str();
        dest.particleShaderTexture.textureName = mapped[1]->c_str();
        dest.membranePaletteTexture.textureName = mapped[2]->c_str();
        dest.particlePaletteTexture.textureName = mapped[3]->c_str();
        dest.holesTexture.textureName = donor.holesTexture.textureName;
        return true;
    }
}

namespace psq::hitShader {
    struct Pair { RE::FormID donor; RE::FormID copy; };
    inline constexpr std::array<Pair, 4> pairs = {{
        {0x01B212, 0xB108}, {0x01F03A, 0xB10F}, {0x0647B9, 0xB132}, {0x057C67, 0xB02A}
    }};
}

inline unsigned applyLocalEffectShaders(const std::map<RE::FormID,RE::TESForm*>& redirected)
{
    auto* forms = RE::TESDataHandler::GetSingleton();
    if (!forms)
        return 0;
    unsigned imported = 0;
    for (const auto& item : psq::hitShader::pairs) {
        const auto found = redirected.find(item.copy);
        if(found!=redirected.end() && !found->second)continue;
        const auto* donor = found==redirected.end() ? forms->LookupForm<RE::TESEffectShader>(item.donor,"Skyrim.esm")
                                                    : found->second->As<RE::TESEffectShader>();
        auto* copy = forms->LookupForm<RE::TESEffectShader>(item.copy, "PSQ PlayerSuccubusQuest.esm");
        if (donor && copy && donor != copy && psq::hitShader::import(*donor, *copy))
            ++imported;
    }
    return imported;
}

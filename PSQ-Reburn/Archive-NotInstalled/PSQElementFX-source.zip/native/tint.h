#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace psq {
using Bytes = std::vector<std::uint8_t>;
using TextureLookup = std::function<std::optional<std::string>(std::string_view)>;
Bytes tintDDS(const Bytes& source);
Bytes tintNif(const Bytes& source, const TextureLookup& texture);
std::optional<std::string> localPinkTexture(std::string_view source);

template<class T> T at(const Bytes& bytes, std::size_t pos) {
    if(pos > bytes.size() || sizeof(T) > bytes.size()-pos) throw std::runtime_error("truncated resource");
    T result; std::memcpy(&result,bytes.data()+pos,sizeof(T)); return result;
}
template<class T> void put(Bytes& bytes, std::size_t pos, T value) {
    if(pos > bytes.size() || sizeof(T)>bytes.size()-pos) throw std::runtime_error("invalid field");
    std::memcpy(bytes.data()+pos,&value,sizeof(T));
}
inline std::array<float,3> pink(float r,float g,float b) {
    auto hi=std::max({r,g,b}),lo=std::min({r,g,b});
    return {hi, .13f*hi+.66f*lo, .53f*hi+.39f*lo};
}
}
